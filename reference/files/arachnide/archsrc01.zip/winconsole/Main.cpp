#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <io.h>
#include <conio.h>
#include <windows.h>

#include "../Source/system/Win32/messages.h"
#include "../Source/system/Win32/MsgReceptionist.h"

//*
#define DEBUG_MESSAGES
//*/

void called_directly() 
{
  puts("Error:");
  puts("You cannot call the console directly, it's an arachnide subprocess.");
}

int hpipe_in;
int hpipe_out;
int hpipe_inback;

void sendmsg(unsigned char msgid) {
  write(hpipe_out, &msgid, 1);
}

int main(int argc, char *argv[]) 
{
  if (argc != 5) {
    called_directly();
    return -1;
  }
  if (strcmp(argv[1], CALL_ID)) {
    called_directly();
    return -1;
  }
  char *hstr_in      = argv[2];
  char *hstr_out     = argv[3];
  char *hstr_inback  = argv[4];

  hpipe_in     = atoi(hstr_in);
  hpipe_out    = atoi(hstr_out);
  hpipe_inback = atoi(hstr_inback);

//  printf("[hpipe-in: %d]\n", hpipe_in);
//  printf("[hpipe-out: %d]\n", hpipe_out);

  MsgReceptionist recept;
  recept.start(hpipe_in);

  char text[256];
  char line[256];
  line[0] = 0;
  unsigned int linepos = 0;
  unsigned char msgid = recept.receive(NULL);

  if (msgid != MSG_HELLO_CONSOLE) {
    printf("[Handshake-fault: Bad welcome request.]");
    //return false;
  }
  sendmsg(MSG_HELLO_MASTER);

  printf("Arachnide 0.1 console\n");
  bool running = true;
  printf(">");
  while(running) {

    if (recept.aviable()) {
      msgid = recept.receive(text);
    
      switch (msgid) {
        case MSG_GOODBYE_CONSOLE :
            running = false;
            break;
        case MSG_POST :
            sendmsg(MSG_POST_CONFIRM);
            putchar('\r');
            for(unsigned int i = 0; i < linepos + 1; i++) {
              putchar(' ');
            }
            printf("\r%s\n", text);
            printf(">%s", line);
            break;
      }
    }

    if (kbhit()) {
      int ch = getch();
      switch (ch) {
        case '\n' :
        case '\r' :
            line[0] = 0;
            linepos = 0;
            printf("\n>");
            break;
        case 8 :
            if (linepos == 0)
              break;
            linepos--;
            line[linepos]   = 0;
            putch(8);
            putch(' ');
            putch(8);
            break;
        default :
            line[linepos++] = ch;
            line[linepos]   = 0;
            putch(ch);
            break;
      }
    } else {
      Sleep(100);
    }    
  }

  recept.stop(hpipe_inback);
  return 0;
}