//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// memguard.cpp
//
// This one `guards� memory, tracking of all allocated and freed memory
// if enabled. This is very, very usefull to track down memory leaks.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#include <stddef.h>
#include <stdio.h>
#include <malloc.h>
#include "config.h"

#include "system/system.h"
#include "system/console.h"

int32 alloc_count = 0;

#if MEM_GUARD_LEVEL == 2

#define MAX_MEMORY 65000

long tablePos    = 0;
typedef struct {
  void *point;
  byte *name;
} MEM_ENTRY;
MEM_ENTRY memtable[MAX_MEMORY] = {0,};

void *gmalloc(size_t size, byte *name) 
{
  void *point = malloc(size);
  if (tablePos + 1 >= MAX_MEMORY) {
    System::panic("MEMGUARD: Memory guard table exceded!\n");
    return point;
  }    
  memtable[tablePos].name = name;
  memtable[tablePos].point = point;
  tablePos++;

  return point; 
}

void gfree(void *memblock)
{
  if (memblock == NULL) {
    System::panic("MEMGUARD: Freeing null pointer!\n");
    return;
  }
  for (long p = 0; p < tablePos; p++) {
    if (memtable[p].point == memblock) {
      memtable[p].point = NULL;
      memtable[p].name  = NULL;
      break;
    }
  }
  if (p >= tablePos)
    System::panic("MEMGUARD: Freeing unallocated memory!");
  else 
    free(memblock);
}

void *grealloc(void *memblock, size_t size) 
{
  if (memblock == NULL)
    System::panic("MEMGUARD: Reallocating null pointer!");
  void *point = realloc(memblock, size);
  for (long p = 0; p < tablePos; p++) {
    if (memtable[p].point == memblock) {
      memtable[p].point = point;
      memtable[p].name;
      break;
    }
  }
  if (p >= tablePos)
    System::panic("MEMGUARD: Reallocating unallocated memory!");
  return point;
}


void *memmark(void *point, byte *name)
{
 if (tablePos + 1 >= MAX_MEMORY) {
    System::panic("MEMGUARD: Memory guard table exceded!");
    return point;
  }    
  memtable[tablePos].name = name;
  memtable[tablePos].point = point;
  tablePos++;
  return point;
}

void memunmark(void *point)
{
  if (point == NULL)
    System::panic("MEMGUARD: Unmarking null pointer!");
  for (long p = 0; p < tablePos; p++) {
    if (memtable[p].point == point) {
      memtable[p].point = NULL;
      memtable[p].name  = NULL;
      break;
    }
  }
  if (p >= tablePos)
    System::panic("MEMGUARD: Unmarking unmarked memory.");
}

void showMemory()
{
  for (long p = 0; p < tablePos; p++) {
    if (memtable[p].point != NULL) {
      Console::printf("MEMGUARD: unfreed pointer: %p,  name: %s", memtable[p].point, memtable[p].name);
    }
  }
}

void *operator new(size_t size, byte *text)
{
#if MEM_GUARD_LEVEL == 2
  void *mem = malloc(size);
  memmark(mem, text);
  return mem;
#else
  return malloc(size);
#endif
}

void *operator new(size_t size)
{
  void *mem = malloc(size);
  memmark(mem, "(null)");
  return mem;
}

void operator delete(void *mem)
{
  memunmark(mem);
  free(mem);
}

void operator delete(void *mem, byte *text)
{
  memunmark(mem);
  free(mem);
}

#endif
