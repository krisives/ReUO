//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  config.h
//
//  In this file all compiling switches and "stratagy parameters" are collected.
//
//  config.h has to be included before any other project headers, so they
//  are aware of the switches.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __CONFIG_H__
#define __CONFIG_H__

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ~~~ DEBUG ~~~
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Turns on sanety checks, disabling improves performance
// but arachnide may go `insane� without notice.
//*
#define SANE
//*/

// Turns on extreme processor eating checks.
// Usefull for debugging
/*
#define PARANOID
//*/

/*
#define DEBUG_CACHE
//*/

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ~~~ SYSTEM ~~~
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

//*
#define _WIN32_
//*/

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ~~~ SETTINGS ~~~
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

// Hashtable 
//   Modifing these values can have significant impace on 
//   performance and memory usage of the hastable
#define HASH_DEFAULT_SIZE    11        // Starting size of a hash table
#define HASH_LOAD_FACTOR     0.5f      // Factor of load where rehashing occurs

// Vector 
#define VECTOR_DEFAULT_SIZE    11      // Starting size of a vector

// Filreader 
#define FILE_READER_BUFFER   2         // default buffer size
                                       // This value isn't too important, since 
                                       // the filereader is capable of extending it's buffer

// Vision
#define FRACT_POOL_START     10        // how big start vission's fracture pool.

// Console/System printf buffers
#define PRINTF_MAX_BUFFER 256

// ObjectMan 
#define MAX_FONT_SETS       10         // how many font sets are allowed to exist?

// Mul Reader, max heights
#define MART_MAX_HEIGHT   2048
#define MGUMP_MAX_HEIGHT  2048

// Hue buffer
#define MAX_HUES  3010

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ~~~ SWITCHES ~~~
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

// Receive hashtable performance profiles
// regarding collision and rehashing statistics  
//*
#define PROFILE_HASHTABLE    
//*/

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Mem-guard level
//
// 0 ... memory guard disabled
// 1 ... count allocs/frees
// 2 ... track memory
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifdef SANE
#  define MEM_GUARD_LEVEL 0
#else
#  define MEM_GUARD_LEVEL 0
#endif

#if MEM_GUARD_LEVEL == 0
#include <malloc.h>       // include standard malloc if no memrory guard, and before the.
                          // standard primitives are destroyed
#endif

#ifdef __MEM_GUARD_H__
#error wrong include sequence (config.h comes before memguard.h)
#endif

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ~~~ ABSTRACT DATA TYPES ~~~
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#if defined(WIN32) && !defined(MINGW)

#  define int8   __int8
#  define int16  __int16
#  define int32  __int32
#  define byte   char
// destroy other data types, just to get compiler errors, if they are accidently used.
#  define int    ERROR
#  define short  ERROR
#  define long   ERROR

#else

#  define int8   char
#  define int16  short
#  define int32  int

#endif

#endif
