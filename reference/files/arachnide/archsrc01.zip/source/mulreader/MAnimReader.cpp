//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  MAnimReader.cpp
//
//  Reader for Anim.mul
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "MAnimReader.h"
#include "../util/FileReader.h"
#include "../system/system.h"
#include "../skin/AnimGroup.h"
#include "../skin/AnimSprite.h"

#define STATIC_OFFSET  16384
#define MAX_FRAMES        20

bool              MAnimReader::upandrun = false;
bool              MAnimReader::isopen;
FileReader *      MAnimReader::data;
FileReader *      MAnimReader::index;
SDL_PixelFormat * MAnimReader::pixelformat;

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MStaticReader::MStaticReader
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#ifdef SANE
MAnimReader::MAnimReader()
{
  System::panic("Initialization of static class");
}
#endif

bool MAnimReader::initialize(IniFile *config)
{
  isopen = false;
  data   = NULL;
  index  = NULL;
  upandrun = true;
  return true;
}

void MAnimReader::finalize()
{
  if (isopen) {
    close();
  }
  upandrun = false;
}

bool MAnimReader::open(const byte *mul_filename, const byte *idx_filename, SDL_PixelFormat *s_pixelformat)
{
  pixelformat = s_pixelformat;
  if (isopen) {
    return false;
  }
  data = new FileReader(mul_filename, FileReader::BINARY);

  if (!data->open()) {
    delete data;
    return false;
  }

  index = new FileReader(idx_filename, FileReader::BINARY);
  if (!index->open()) {
    data->close();
    delete data;
    return false;
  }

  isopen = true;
  return true;
}

AnimGroup *MAnimReader::readAnimGroup(unsigned int32 id) 
{
  AnimGroup *animGroup = new AnimGroup;
  index->seek(12 * id);
  unsigned int32 offset = index->read_uint32_little();
  unsigned int32 size   = index->read_uint32_little();
#ifdef SANE
  if (offset == 0xffffffff) {
    System::panic("Invalid animation offset read for tile %d", id);
  }
#endif
  data->seek(offset);
  unsigned int16 palette[256];
  unsigned int32   offsets[MAX_FRAMES];
  for (unsigned int32 i = 0; i < 256; i++) {
    palette[i] = data->read_uint16_little();
  }
  unsigned int32 framecount = data->read_uint32_little();
#ifdef SANE
  if (framecount > MAX_FRAMES) {
    System::panic("Too much frames in animation group %d. (%d frames)", id, framecount);
  }
#endif
  for (i = 0; i < framecount; i++) {
    offsets[i] = data->read_uint32_little();
  }
  animGroup->frames = (AnimSprite **) malloc(framecount * sizeof (AnimSprite *), "AnimGroup.frames");
  animGroup->framecount = framecount;
  // now actually read the sprites)
  for(unsigned int32 frame = 0; frame < framecount; frame++) {
    data->seek(offset + 512 + offsets[frame]);
    signed int32 centerx = data->read_sint16_little();
    signed int32 centery = data->read_sint16_little();
    unsigned int32 width   = data->read_uint16_little();
    unsigned int32 height  = data->read_uint16_little();
    AnimSprite *sprite = new AnimSprite(width, height);
    
    unsigned int32 mask_line = (width >> 3) + 1;
    unsigned int32 mask_size = height * mask_line;
    unsigned byte *mask = (unsigned byte *) malloc(mask_size, "AnimSprite.mask");
    memset(mask, 0x00, mask_size);
    memset(sprite->data, 0x1f, width * 2 * height);
    sprite->mask = mask;
    sprite->stretched = true;
    sprite->offsetx = centerx;
    sprite->offsety = centery;

    unsigned int32 y = 0;
    unsigned int32 dpos = 0;
    unsigned int32 mpos = 0;
    unsigned int32 prevLinenum = 0xffffffff;

    while (y < height) {
      int32 rowHeader = data->read_uint16_little();
      int32 rowOffset = data->read_uint16_little();

      if ((rowHeader == 0x7FFF) || (rowOffset == 0x7FFF)) {
         break;
      }
      int32 runby   = rowHeader & 0xfff;
      int32 linenum = rowHeader >> 12;
      if ((linenum != prevLinenum) && (prevLinenum != 0xffffffff)) {
        y++;
        dpos += width << 1;
        mpos += mask_line;
#ifdef SANE
        if (y >= height) {
          System::panic("To high animation sprite");
        }
#endif
      }
      prevLinenum = linenum;
      int32 xoffs   = (rowOffset) >> 6;
      if (rowOffset & 0x8000) {
        xoffs += centerx - 1024;
      } else {
        xoffs += centerx;
      } 
      unsigned int8 mmask = 1 << (xoffs & 0x07);
      unsigned byte *m  = mask + mpos + (xoffs >> 3);
      for (unsigned int32 x = xoffs; x < xoffs + runby; x++) {
        *((unsigned int16 *) ((byte *) sprite->data + dpos + x*2)) = palette[data->read_byte()];
        *m |= mmask;
        if ((mmask <<= 1) == 0) {
          mmask = 0x01;
          m++;
        }
      }
    }
    animGroup->frames[frame] = sprite;
  }
  return animGroup;
}


void MAnimReader::close()
{
  isopen = false;  
  data->close();
  index->close();
  delete data;
  delete index;
}
