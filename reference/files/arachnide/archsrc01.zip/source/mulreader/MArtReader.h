//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  MArtReader
//
//  Reader for Art.mul
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __M_ART_READER_H__
#define __M_ART_READER_H__

class FileReader;
class IniFile;
class Sprite;
typedef struct SDL_PixelFormat SDL_PixelFormat;

class MArtReader {
  private :
    static bool isopen;
    static FileReader *data;
    static FileReader *index;

    static SDL_PixelFormat *pixelformat;

    static unsigned int32 linebuf[MART_MAX_HEIGHT];
    
  public :
    static bool initialize(IniFile *config);
    static void finalize();
    static bool upandrun;
    
    static Sprite *readMapSprite(unsigned int32 id);
    static Sprite *readStaticSprite(unsigned int32 id);

    static bool open(const byte *mul_filename, const byte *idx_filename, SDL_PixelFormat *pixelformat);
    static void close();

#ifdef SANE
    MArtReader();
#endif
};

#endif