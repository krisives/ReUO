//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  MVerdataReader.cpp
//
//  Reader for verdata.mul
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "MVerdataReader.h"
#include "../util/FileReader.h"
#include "../util/LongHashtable.h"
#include "../util/LongHashtable.h"
#include "../objects/cache.h"
#include "../system/system.h"

bool              MVerdataReader::upandrun = false;
bool              MVerdataReader::isopen;
FileReader *      MVerdataReader::data;
LongHashtable     MVerdataReader::entries;

class VerdataEntry {
  public :
    unsigned int32 id;
    unsigned int32 pos;
    unsigned int32 param;
    unsigned int32 size;
};

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MVerdataReader::MVerdataReader
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#ifdef SANE
MVerdataReader::MVerdataReader()
{
  System::panic("Initialization of static class");
}
#endif

bool MVerdataReader::initialize(IniFile *config)
{
  isopen = false;
  data   = NULL;
  upandrun = true;
  return true;
}

void MVerdataReader::finalize()
{
  if (isopen) {
    close();
  }
  upandrun = false;
}

bool MVerdataReader::open(const byte *mul_filename)
{
  if (isopen) {
    return false;
  }
  data = new FileReader(mul_filename, FileReader::BINARY);

  if (!data->open()) {
    delete data;
    return false;
  }

  unsigned int32 index_count = data->read_uint32_little();
  for(unsigned int32 i = 0; i < index_count; i++) {
    unsigned int32 kind  = data->read_uint32_little();
    unsigned int32 id    = data->read_uint32_little();
    unsigned int32 pos   = data->read_uint32_little();
    unsigned int32 size  = data->read_uint32_little();
    unsigned int32 param = data->read_uint32_little();
#ifdef SANE
    if (id & 0xFF000000) {
      System::panic("Cannot handle verdata id.");
    }
#endif
    if (kind == 0x0C) { // gumpart
      VerdataEntry *entry = new VerdataEntry;
      entry->id    = id;
      entry->pos   = pos;
      entry->param = param;
      entry->size  = size;
      entries.put((GUMP << 24) | id, (void *) entry);
    }   
  }

  isopen = true;
  return true;
}

FileReader *MVerdataReader::check_object(unsigned int32 kind, unsigned int32 id, unsigned int32 *size, unsigned int32 *param)
{
  if (kind == GUMP) {
    VerdataEntry *entry = (VerdataEntry *) entries.get((GUMP << 24) | id);
    if (entry != NULL) {
      data->seek(entry->pos);
      *param = entry->param;
      *size  = entry->size;
      return data;
    }
  }
  return NULL;
}

void MVerdataReader::close()
{
  isopen = false;  
  data->close();
  delete data;
}
