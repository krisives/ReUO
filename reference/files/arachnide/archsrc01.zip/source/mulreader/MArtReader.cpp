//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  MArtReader.cpp
//
//  Reader for Art.mul
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "../util/FileReader.h"
#include "../system/system.h"
#include "../display/Sprite.h"
#include "MArtReader.h"

#define STATIC_OFFSET  16384

bool              MArtReader::upandrun = false;
bool              MArtReader::isopen;
FileReader *      MArtReader::data;
FileReader *      MArtReader::index;
SDL_PixelFormat * MArtReader::pixelformat;
unsigned int32    MArtReader::linebuf[MART_MAX_HEIGHT];


const unsigned int32 mapSpriteOffsets[] = 
{
   21,20,19,18,17,16,15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,
   0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,20,21
};

const unsigned int32 mapSpriteLen[] = 
{ 
   2, 4, 6, 8 ,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,
   44,42,40,38,36,34,32,30,28,26,24,22,20,18,16,14,12,10, 8, 6, 4, 2
};


unsigned byte mapSpriteMask[] = 
{
  0x00,  0x00,  0x60,  0x00,  0x00,  0x00,
  0x00,  0x00,  0xf0,  0x00,  0x00,  0x00,
  0x00,  0x00,  0xf8,  0x01,  0x00,  0x00,
  0x00,  0x00,  0xfc,  0x03,  0x00,  0x00,
  0x00,  0x00,  0xfe,  0x07,  0x00,  0x00,
  0x00,  0x00,  0xff,  0x0f,  0x00,  0x00,
  0x00,  0x80,  0xff,  0x1f,  0x00,  0x00,
  0x00,  0xc0,  0xff,  0x3f,  0x00,  0x00,
  0x00,  0xe0,  0xff,  0x7f,  0x00,  0x00,
  0x00,  0xf0,  0xff,  0xff,  0x00,  0x00,
  0x00,  0xf8,  0xff,  0xff,  0x01,  0x00,
  0x00,  0xfc,  0xff,  0xff,  0x03,  0x00,
  0x00,  0xfe,  0xff,  0xff,  0x07,  0x00,
  0x00,  0xff,  0xff,  0xff,  0x0f,  0x00,
  0x80,  0xff,  0xff,  0xff,  0x1f,  0x00,
  0xc0,  0xff,  0xff,  0xff,  0x3f,  0x00,
  0xe0,  0xff,  0xff,  0xff,  0x7f,  0x00,
  0xf0,  0xff,  0xff,  0xff,  0xff,  0x00,
  0xf8,  0xff,  0xff,  0xff,  0xff,  0x01,
  0xfc,  0xff,  0xff,  0xff,  0xff,  0x03,
  0xfe,  0xff,  0xff,  0xff,  0xff,  0x07,
  0xff,  0xff,  0xff,  0xff,  0xff,  0x0f,
  0xff,  0xff,  0xff,  0xff,  0xff,  0x0f,
  0xfe,  0xff,  0xff,  0xff,  0xff,  0x07,
  0xfc,  0xff,  0xff,  0xff,  0xff,  0x03,
  0xf8,  0xff,  0xff,  0xff,  0xff,  0x01,
  0xf0,  0xff,  0xff,  0xff,  0xff,  0x00,
  0xe0,  0xff,  0xff,  0xff,  0x7f,  0x00,
  0xc0,  0xff,  0xff,  0xff,  0x3f,  0x00,
  0x80,  0xff,  0xff,  0xff,  0x1f,  0x00,
  0x00,  0xff,  0xff,  0xff,  0x0f,  0x00,
  0x00,  0xfe,  0xff,  0xff,  0x07,  0x00,
  0x00,  0xfc,  0xff,  0xff,  0x03,  0x00,
  0x00,  0xf8,  0xff,  0xff,  0x01,  0x00,
  0x00,  0xf0,  0xff,  0xff,  0x00,  0x00,
  0x00,  0xe0,  0xff,  0x7f,  0x00,  0x00,
  0x00,  0xc0,  0xff,  0x3f,  0x00,  0x00,
  0x00,  0x80,  0xff,  0x1f,  0x00,  0x00,
  0x00,  0x00,  0xff,  0x0f,  0x00,  0x00,
  0x00,  0x00,  0xfe,  0x07,  0x00,  0x00,
  0x00,  0x00,  0xfc,  0x03,  0x00,  0x00,
  0x00,  0x00,  0xf8,  0x01,  0x00,  0x00,
  0x00,  0x00,  0xf0,  0x00,  0x00,  0x00,
  0x00,  0x00,  0x60,  0x00,  0x00,  0x00,
};

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MStaticReader::MStaticReader
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#ifdef SANE
MArtReader::MArtReader()
{
  System::panic("Initialization of static class");
}
#endif

bool MArtReader::initialize(IniFile *config)
{
  isopen = false;
  data   = NULL;
  index  = NULL;
  upandrun = true;
  return true;
}

void MArtReader::finalize()
{
  if (isopen) {
    close();
  }
  upandrun = false;
}

bool MArtReader::open(const byte *mul_filename, const byte *idx_filename, SDL_PixelFormat *s_pixelformat)
{
  pixelformat = s_pixelformat;
  if (isopen) {
    return false;
  }
  data = new FileReader(mul_filename, FileReader::BINARY);

  if (!data->open()) {
    delete data;
    return false;
  }

  index = new FileReader(idx_filename, FileReader::BINARY);
  if (!index->open()) {
    data->close();
    delete data;
    return false;
  }

  isopen = true;
  return true;
}

Sprite *MArtReader::readMapSprite(unsigned int32 id) 
{
  Sprite *sprite = new Sprite(44, 44);
  sprite->width  = 44;
  sprite->height = 44;
  index->seek(12 * id);
  unsigned int32 offset = index->read_uint32_little();
  if (offset == 0xFFFFFFFF) {
    offset = 12;
  }

  data->seek(offset);
  unsigned int32 rowpos = 21;
  unsigned int32 rowend = 23;
  unsigned int32 row    = 0;

  for(int32 i = 0; i < 1012; i++) {
    unsigned int32 pixel = data->read_uint16_little();
    sprite->setPixel(rowpos, row, pixel);
          
    if (++rowpos == rowend) {
      row++;
      rowpos = mapSpriteOffsets[row];
      rowend = rowpos + mapSpriteLen[row];
    }
  }

  sprite->mask = mapSpriteMask;
  sprite->stretched = false;
 
  return sprite;  
}

Sprite *MArtReader::readStaticSprite(unsigned int32 id)
{
  index->seek(12 * (id + STATIC_OFFSET));
  unsigned int32 offset = index->read_uint32_little();
  data->seek(offset + 4); // 4 to skip some header (size?)
  unsigned int32 width = data->read_uint16_little();
  unsigned int32 height = data->read_uint16_little();
#ifdef SANE 
  if ((width == 0)  || (width >= 1024) ||
      (height == 0) || (height >= 1024)) {
    System::panic("MArtReader::readStaticSprite, invalid dimension");
  }
#endif
  Sprite *sprite = new Sprite(width, height);
  for (unsigned int32 i= 0; i< height; i++) {
    linebuf[i] = data->read_uint16_little();
  }
  unsigned int32 mask_line = (width >> 3) + 1;
  unsigned int32 mask_size = height * mask_line;
  unsigned byte *mask = (unsigned byte *) malloc(mask_size, "Sprite.mask");
  memset(mask, 0, mask_size);
  sprite->mask = mask;
  sprite->stretched = true;
  unsigned int32 dstart = offset + 8 + height * 2;
  unsigned int32 y = 0;
  unsigned int32 x = 0;
  data->seek(dstart + (linebuf[y] << 1));
  unsigned int32 runs = 0;
  while(y < height) {
    unsigned int32 offset = data->read_uint16_little();
    unsigned int32 runby  = data->read_uint16_little();
    x += offset;
    if (offset + runby == 0) {
      y++;
      data->seek(dstart + (linebuf[y] << 1));
      x = 0;
      runs = 0;
      continue;
    }
#ifdef SANE
    if (x + runby > width) {
      System::panic("MArtReader::readStaticSprite, illegal data");
    }
#endif
    runs++;
    unsigned byte *mp = mask + (x >> 3) + y * mask_line;
    unsigned int8 m  = 1 << (x & 0x7);
    byte *dst = ((byte *) sprite->data) + (y * width * 2) + x * 2;
    for (unsigned int32 r = 0; r < runby; r++) {      
      *((unsigned int16 *) dst) = (unsigned int16) data->read_uint16_little();
      *mp |= m;
      dst += 2;
      if ((m <<= 1) == 0) {
        m = 0x01;
        mp++;
      }
    }
    x += runby;
  }
  return sprite;
}

void MArtReader::close()
{
  isopen = false;  
  data->close();
  index->close();
  delete data;
  delete index;
}
