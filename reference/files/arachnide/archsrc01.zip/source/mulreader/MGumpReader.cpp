//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  MGumpReader.cpp
//
//  Reader for gumpart.mul
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "MGumpReader.h"
#include "MVerdataReader.h"
#include "../util/FileReader.h"
#include "../system/system.h"
#include "../objects/cache.h"
#include "../display/Sprite.h"
#include "../skin/Fontset.h"

bool              MGumpReader::upandrun = false;
bool              MGumpReader::isopen;
FileReader *      MGumpReader::data;
FileReader *      MGumpReader::index;
SDL_PixelFormat * MGumpReader::pixelformat;
unsigned int32    MGumpReader::linebuf[MGUMP_MAX_HEIGHT];




//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MGumpReader::MGumpReader
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#ifdef SANE
MGumpReader::MGumpReader()
{
  System::panic("Initialization of static class");
}
#endif

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MGumpReader::MGumpReader
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool MGumpReader::initialize(IniFile *config)
{
  isopen = false;
  data   = NULL;
  upandrun = true;
  return true;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MGumpReader::MGumpReader
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void MGumpReader::finalize()
{
  if (isopen) {
    close();
  }
  upandrun = false;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MGumpReader::MGumpReader
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool MGumpReader::open(const byte *mul_filename, const byte *idx_filename, SDL_PixelFormat *s_pixelformat)
{
  pixelformat = s_pixelformat;
  if (isopen) {
    return false;
  }

  data = new FileReader(mul_filename, FileReader::BINARY);
  if (!data->open()) {
    delete data;
    return false;
  }

  index = new FileReader(idx_filename, FileReader::BINARY);
  if (!index->open()) {
    data->close();    
    delete data;
    delete index;
    return false;
  }

  isopen = true;
  return true;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MGumpReader::MGumpReader
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
Sprite *MGumpReader::read_gump(unsigned int32 id) 
{
  unsigned int32 param;
  unsigned int32 size;
  unsigned int32 h;
  unsigned int32 w;
  FileReader *vdata = MVerdataReader::check_object(GUMP, id, &size, &param);
  if (vdata != NULL) {
    w = param >> 16;
    h = param & 0xFFFF;
  } else {
    index->seek(12 * id);
    unsigned int32 offset = index->read_uint32_little();
    if (offset == 0xFFFFFFFF) {
      return NULL;
    }
    size   = index->read_uint32_little();
    h = index->read_uint16_little();
    w = index->read_uint16_little();
    vdata = data;
    vdata->seek(offset);
  }

#ifdef SANE 
  if ((w == 0)  || (w >= 1024) ||
      (h == 0) || (h >= 1024)) {
    System::panic("MGumpReader::readGumpSprite, invalid dimension");
  }
#endif
  Sprite *sprite = new Sprite(w, h);
  unsigned int32 maskline = (w >> 3) + 1;
  unsigned byte *mask = (unsigned byte *) malloc(maskline * h, "Fontsprite.mask");
  sprite->mask = mask;
  sprite->stretched = true;
  memset(mask, 0x00, maskline * h);
  memset(sprite->data, 0x1F, w * h * 2);
  unsigned byte  *mp = mask;
  unsigned int8   m  = 0x01;
  unsigned int16 *dp = (unsigned int16 *) sprite->data;
  
  for (unsigned int32 i = 0; i < h; i++) {
    linebuf[i] = vdata->read_uint32_little();
  }
  //offset += h * 4;
  for (unsigned int32 y = 0; y < h; y++) {
    unsigned int32 runcount;
    if (y < h - 1) {
      runcount = linebuf[y + 1] - linebuf[y];
    } else {
      runcount = size / 4 - linebuf[y];
    }

    for (unsigned int32 i = 0; i < runcount; i++) {
      unsigned int32 pixel = vdata->read_uint16_little();
      unsigned int32 run   = vdata->read_uint16_little();
      for (unsigned int32 r = 0; r < run; r++) {
        if (pixel != 0) {
          *dp = pixel; 
          *mp |= m;
        }
        dp++;              
        if ((m <<= 1) == 0) {
          m = 0x01;
          mp++;
        }
      }
    }
    mp = mask + (y + 1) * maskline;
    m = 0x01;
  }  
  return sprite;
}

void MGumpReader::close()
{
  isopen = false;  
  data->close();
  delete data;
}
