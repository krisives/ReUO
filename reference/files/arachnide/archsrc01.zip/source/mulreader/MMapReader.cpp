//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  MMapReader.cpp
//
//  Reader for map0.mul
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "MMapReader.h"
#include "../map/MapBlock.h"
#include "../map/MapCell.h"
#include "../system/System.h"
#include "../util/FileReader.h"

bool         MMapReader::upandrun = false;
bool         MMapReader::isopen;
FileReader * MMapReader::data;


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MMapReader::MMapReader
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#ifdef SANE
MMapReader::MMapReader()
{
  System::panic("Initialization of static class");
}
#endif


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MMapReader::initialize
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool MMapReader::initialize(IniFile *config)
{
  isopen = false;
  data   = NULL;
  upandrun = true;
  return true;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MMapReader::finalize
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void MMapReader::finalize()
{
  if (isopen) {
    close();
  }
  upandrun = false;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MMapReader::open
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool MMapReader::open(const byte *mul_filename)
{
  if (isopen) {
    return false;
  }
  data = new FileReader(mul_filename, FileReader::BINARY);

  if (!data->open()) {
    delete data;
    return false;
  }

  isopen = true;
  return true;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MMapReader::readMapBlock
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
MapBlock *MMapReader::readMapBlock(unsigned int32 id)
{
#ifdef SANE
  if (id >= 512 * 768) { 
    System::panic("MMapReader::readMapBlock, invalid id");
  }
#endif
  data->seek(id * 196 + 4);
  MapBlock *mapblock = new MapBlock();
  for (int32 y = 0; y < 8; y++) {
    for (int32 x = 0; x < 8; x++) {
      mapblock->cells[x][y].id = data->read_uint16_little();
      mapblock->cells[x][y].z  = data->read_sint8();
    }
  }
  mapblock->prepared  = false;
  return mapblock;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MMapReader::close
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void MMapReader::close()
{
  isopen = false;  
  data->close();
  delete data;
}
