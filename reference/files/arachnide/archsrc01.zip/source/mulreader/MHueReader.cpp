//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  MVerdataReader.cpp
//
//  Reader for verdata.mul
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "MHueReader.h"
#include "../util/FileReader.h"
#include "../util/LongHashtable.h"
#include "../util/LongHashtable.h"
#include "../objects/cache.h"
#include "../system/system.h"

bool           MHueReader::upandrun = false;
bool           MHueReader::isopen;
FileReader *   MHueReader::data;

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MHueReader::MHueReader
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#ifdef SANE
MHueReader::MHueReader()
{
  System::panic("Initialization of static class");
}
#endif

bool MHueReader::initialize(IniFile *config)
{
  isopen = false;
  data   = NULL;
  upandrun = true;
  return true;
}

void MHueReader::finalize()
{
  if (isopen) {
    close();
  }
  upandrun = false;
}

bool MHueReader::open(const byte *mul_filename)
{
  if (isopen) {
    return false;
  }
  data = new FileReader(mul_filename, FileReader::BINARY);

  if (!data->open()) {
    delete data;
    return false;
  }

  isopen = true;
  return true;
}

void MHueReader::readin(unsigned int16 hues[MAX_HUES][32])
{
  
}

void MHueReader::close()
{
  isopen = false;  
  data->close();
  delete data;
}
