//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  MTiledataReader.cpp
//
//  Reader for tiledata.mul
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "MulCentral.h"
#include "MArtReader.h"
#include "MFontReader.h"
#include "MGumpReader.h"
#include "MAnimReader.h"
#include "MMapReader.h"
#include "MStaticReader.h"
#include "MHueReader.h"
#include "MTiledataReader.h"
#include "MVerdataReader.h"
#include "../display/Box.h"
#include "../display/Display.h"
#include "../util/IniFile.h"
#include "../system/console.h"
#include "../system/system.h"

bool        MulCentral::upandrun = false;

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MulCentral::MulCentral
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#ifdef SANE
MulCentral::MulCentral()
{
  System::panic("Initialization of static class");
}
#endif


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MulCentral::initialize
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool MulCentral::initialize(IniFile *config)
{
  Box *front = Display::masterbox;
  const byte *c_UOPath = config->getString("UOPATH", NULL);
  if (c_UOPath == NULL) {
    System::message("Cannot find UOPATH in cfg file. Startup failed.");
    return false;
  } 

  std::string uoPath(c_UOPath);
  std::string mul_filename;
  std::string idx_filename;

  Console::printf("| Initializing MUL readers");  
  mul_filename = uoPath + "\\art.mul";
  idx_filename = uoPath + "\\artidx.mul";
    
  Console::printf("|    %s", mul_filename.c_str());
  Console::printf("|    %s", idx_filename.c_str());
      
  if (!MArtReader::open(mul_filename.c_str(), 
                      idx_filename.c_str(), 
                      front->pixelformat())) {
    std::string message;
    message = "Failure opening \"" + mul_filename + "\" , \"" + idx_filename + "\"";
    System::message(message.c_str());
    return false;
  }

  mul_filename = uoPath + "\\anim.mul";
  idx_filename = uoPath + "\\anim.idx";
    
  Console::printf("|    %s", mul_filename.c_str());
  Console::printf("|    %s", idx_filename.c_str());
      
  if (!MAnimReader::open(mul_filename.c_str(), 
                      idx_filename.c_str(), 
                      front->pixelformat())) {
    std::string message;
    message = "Failure opening \"" + mul_filename + "\" , \"" + idx_filename + "\"";
    System::message(message.c_str());
    return false;
  }

  mul_filename = uoPath + "\\map0.mul";
  Console::printf("|    %s", mul_filename.c_str());
  if (!MMapReader::open(mul_filename.c_str())) { 
    std::string message;
    message = "Failure opening \"" + mul_filename + "\"";
    System::message(message.c_str());
    return false;
  }  

  mul_filename = uoPath + "\\statics0.mul";
  idx_filename = uoPath + "\\staidx0.mul";
   
  Console::printf("|    %s", mul_filename.c_str());
  Console::printf("|    %s", idx_filename.c_str());
      
  if (!MStaticReader::open(mul_filename.c_str(), 
                        idx_filename.c_str())) {
    std::string message;
    message = "Failure opening \"" + mul_filename + "\" , \"" + idx_filename + "\"";
    System::message(message.c_str());
    return false;
  }
    
  mul_filename = uoPath + "\\tiledata.mul";
  Console::printf("|    %s", mul_filename.c_str());
  if (!MTiledataReader::open(mul_filename.c_str())) { 
    std::string message;
    message = "Failure opening \"" + mul_filename + "\"";
    System::message(message.c_str());
    return false;
  }  

  mul_filename = uoPath + "\\fonts.mul";
  Console::printf("|    %s", mul_filename.c_str());
  if (!MFontReader::open(mul_filename.c_str(), front->pixelformat())) { 
    std::string message;
    message = "Failure opening \"" + mul_filename + "\"";
    System::message(message.c_str());
    return false;
  }  

  mul_filename = uoPath + "\\gumpart.mul";
  idx_filename = uoPath + "\\gumpidx.mul";
  Console::printf("|    %s", mul_filename.c_str());
  if (!MGumpReader::open(mul_filename.c_str(), idx_filename.c_str(), front->pixelformat())) { 
    std::string message;
    message = "Failure opening \"" + mul_filename + "\"";
    System::message(message.c_str());
    return false;
  }  

  mul_filename = uoPath + "\\hues.mul";
  Console::printf("|    %s", mul_filename.c_str());
  if (!MHueReader::open(mul_filename.c_str())) { 
    std::string message;
    message = "Failure opening \"" + mul_filename + "\"";
    System::message(message.c_str());
    return false;
  }  

  mul_filename = uoPath + "\\verdata.mul";
  Console::printf("|    %s", mul_filename.c_str());
  if (!MVerdataReader::open(mul_filename.c_str())) { 
    std::string message;
    message = "Failure opening \"" + mul_filename + "\"";
    System::message(message.c_str());
    return false;
  }  

  Console::printf("|   ");
  Console::printf("|   ");

  upandrun = true;
  return true;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MulCentral::finalize
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void MulCentral::finalize()
{
  upandrun = false;
}

