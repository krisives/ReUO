//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  MStaticReader.cpp
//
//  Reader for statics0.mul
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "MStaticReader.h"
#include "../map/MapCell.h"
#include "../map/StaticBlock.h"
#include "../map/StaticCell.h"
#include "../system/System.h"
#include "../util/FileReader.h"

bool        MStaticReader::upandrun = false;
bool        MStaticReader::isopen;
FileReader *MStaticReader::data;
FileReader *MStaticReader::index;

// temporary buffer
struct Particle {
  unsigned int32 id;
  signed int8 x;
  signed int8 y;
  signed int8 z;
};

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MStaticReader::MStaticReader
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#ifdef SANE
MStaticReader::MStaticReader()
{
  System::panic("Initialization of static class");
}
#endif

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MStaticReader::initialize
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool MStaticReader::initialize(IniFile *config)
{
  isopen = false;
  data   = NULL;
  index  = NULL;
  upandrun = true;
  return true;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MStaticReader::finalize
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void MStaticReader::finalize()
{
  if (isopen) {
    close();
  }
  upandrun = false;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MStaticReader::open
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool MStaticReader::open(const byte *mul_filename, const byte *idx_filename)
{
  if (isopen) {
    return false;
  }
  data = new FileReader(mul_filename, FileReader::BINARY);
  if (!data->open()) {
    delete data;
    return false;
  }
  index = new FileReader(idx_filename, FileReader::BINARY);
  if (!index->open()) {
    data->close();
    delete data;
    delete index;
    return false;
  }

  isopen = true;
  return true;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MStaticReader::readStaticBlock
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
StaticBlock *MStaticReader::readStaticBlock(unsigned int32 id)
{
#ifdef SANE
  if (id >= 512 * 768) { 
    System::panic("MStaticReader::readStaticBlock, invalid id");
  }
#endif
  index->seek(12 * id);
  unsigned int32 start = index->read_uint32_little();
  unsigned int32  len  = index->read_uint32_little();
  if (start == 0xffffffff) {
    StaticBlock *block = new StaticBlock;
    for (unsigned int32 x = 0; x < 8; x++) {
      for (unsigned int32 y = 0; y < 8; y++) {
        block->cells[x][y] = NULL;
      }
    }
    return block;
  } 
  len = len / 7;
  data->seek(start);
  StaticBlock *block = new StaticBlock;
  Particle *part = (Particle *) malloc(len * sizeof(Particle), "MStaticReader::readStaticBlock.part");
#ifdef SANE
  if (part == NULL) {
    System::panic("Out of memory! (cannot allocate particles)");
  }
#endif
  unsigned int32 count[8][8] = {0, };
  unsigned int32 pos[8][8]   = {0, };
  signed int8 px = 0;
  signed int8 py = 0;
  // read tiles (particels) in, in any particular order
  unsigned int32 i;
  for (i = 0; i < len; i++) {
    part[i].id = data->read_uint16_little();
    part[i].x  = px = data->read_byte();
    part[i].y  = py = data->read_byte();
    part[i].z  = data->read_sint8();
#ifdef SANE
  if ((part[i].id == 0) || (part[i].x < 0) || (part[i].x > 7) ||
      (part[i].y < 0) || (part[i].y > 7)) {
    System::panic("Failure in statics0.mul. illegal data.");
  }
#endif
    count[px][py]++;
    data->read_uint16_little();
  }
  unsigned int32 x;
  unsigned int32 y;
  unsigned int32 c;
  // reserve and initialize memory
  for(x = 0; x < 8; x++) {
    for(y = 0; y < 8; y ++) {
      c = count[x][y];
      block->cells[x][y] = (StaticCell *) malloc((c + 1) * sizeof(StaticCell), "StaticBlock.cell");
#ifdef SANE
      if (block->cells[x][y] == NULL) {
        System::panic("Out of memory! (cannot allocate static block cell list)");
      }
#endif
      block->cells[x][y][c].id = 0xffffffff;
    }
  }
  // sort data into the cells
  for (i = 0; i < len; i++) {
    Particle   *p = &part[i];
    StaticCell *c = &block->cells[p->x][p->y][pos[p->x][p->y]++];
    c->z = p->z;
    c->id = p->id;
  }

  free(part);
  return block;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MStaticReader::close
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void MStaticReader::close()
{
  isopen = false;  
  data->close();
  delete data;
}
