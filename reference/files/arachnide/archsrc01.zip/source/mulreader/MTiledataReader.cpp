//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  MTiledataReader.cpp
//
//  Reader for tiledata.mul
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "MTiledataReader.h"
#include "../objects/Cache.h"
#include "../map/Tiledata.h"
#include "../map/TiledataGroup.h"
#include "../system/System.h"
#include "../util/FileReader.h"

bool        MTiledataReader::upandrun = false;
bool        MTiledataReader::isopen;
FileReader *MTiledataReader::data;


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MTiledataReader::MTiledataReader
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#ifdef SANE
MTiledataReader::MTiledataReader()
{
  System::panic("Initialization of static class");
}
#endif


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MTiledataReader::initialize
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool MTiledataReader::initialize(IniFile *config)
{
  isopen = false;
  data   = NULL;
  upandrun = true;
  return true;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MTiledataReader::finalize
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void MTiledataReader::finalize()
{
  if (isopen) {
    close();
  }
  upandrun = false;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MTiledataReader::open
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool MTiledataReader::open(const byte *mul_filename)
{
  if (isopen) {
    return false;
  }
  data = new FileReader(mul_filename, FileReader::BINARY);

  if (!data->open()) {
    delete data;
    return false;
  }

  isopen = true;
  return true;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MTiledataReader::read_static_tiledata
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
TiledataGroup *MTiledataReader::read_static_tiledata(unsigned int32 id)
{
  TiledataGroup *group = new TiledataGroup(TILEDATA_STATIC);
  unsigned int32 pos = 512*836 + id * 1188  + 4;   
  data->seek(pos);
  for(unsigned int32 i = 0; i <32; i++) {
    Tiledata *tiledata = new("static tiledata") Tiledata;
    group->data[i] = tiledata;
    tiledata->flags = data->read_uint32_big();
    data->seek(pos + 16);   
    tiledata->height = data->read_sint8();
    byte *name = (byte *) malloc(21, "Tiledata.name");
    tiledata->name = name;
    for(unsigned int32 i = 0; i < 20; i++) {
      *name++ = data->read_sint8();
    }
  }

  return group;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MTiledataReader::read_map_tiledata
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
TiledataGroup *MTiledataReader::read_map_tiledata(unsigned int32 id)
{
#ifdef SANE
  if (id > 512) {
    System::panic("Tried to read tiledata with illegal id");
  }
#endif
  TiledataGroup *group = new TiledataGroup(TILEDATA_MAP);
  unsigned int32 pos = id * 836 + 4;
           //             % 32         // for dword
  data->seek(pos);
  for(unsigned int32 i = 0; i <32; i++) {
    Tiledata *tiledata = new("map tiledata") Tiledata;
    group->data[i] = tiledata;

    tiledata->flags  = data->read_uint32_big();
    tiledata->transparent = data->read_uint16_big();

    tiledata->height = 0;
    byte *name = (byte *) malloc(21, "Tiledata.name");
    tiledata->name = name;
    for(unsigned int32 i = 0; i < 20; i++) {
      *name++ = data->read_byte();
    }
  }
  return group;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MTiledataReader::close
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void MTiledataReader::close()
{
  isopen = false;  
  data->close();
  delete data;
}
