//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  MArtReader.cpp
//
//  Reader for fonts.mul
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "MFontReader.h"
#include "../util/FileReader.h"
#include "../system/system.h"
#include "../display/Sprite.h"
#include "../skin/Fontset.h"

bool              MFontReader::upandrun = false;
bool              MFontReader::isopen;
FileReader *      MFontReader::data;
SDL_PixelFormat * MFontReader::pixelformat;


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// MFontReader::MFontReader
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#ifdef SANE
MFontReader::MFontReader()
{
  System::panic("Initialization of static class");
}
#endif

bool MFontReader::initialize(IniFile *config)
{
  isopen = false;
  data   = NULL;
  upandrun = true;
  return true;
}

void MFontReader::finalize()
{
  if (isopen) {
    close();
  }
  upandrun = false;
}

bool MFontReader::open(const byte *mul_filename, SDL_PixelFormat *s_pixelformat)
{
  pixelformat = s_pixelformat;
  if (isopen) {
    return false;
  }
  data = new FileReader(mul_filename, FileReader::BINARY);

  if (!data->open()) {
    delete data;
    return false;
  }

  isopen = true;
  return true;
}

Fontset *MFontReader::readFontset(unsigned int32 id) 
{
  Fontset *fset = new Fontset();
  //data->seek(0);
  data->read_byte(); // font set number
  //for(unsigned int i = 32; i < MAX_FONTSET_SIZE; i++) {
  for(unsigned int32 i = 32; i < MAX_FONTSET_SIZE; i++) {  
    unsigned int32 w = data->read_byte();
    unsigned int32 h = data->read_byte();
    data->read_byte(); // unknown
    Sprite *sprite = new Sprite(w,h);
    unsigned int32 maskline = (w >> 3) + 1;
    unsigned byte *mask = (unsigned byte *) malloc(maskline * h, "Fontsprite.mask");
    sprite->mask = mask;
    sprite->stretched = true;
    memset(mask, 0x0, maskline * h);
    unsigned byte  *mp = mask;
    unsigned int8   m  = 0x01;
    unsigned int16 *dp = (unsigned int16 *) sprite->data;
    for (unsigned int32 y = 0; y < h; y++) {
      for (unsigned int32 x = 0; x < w; x++) {
        unsigned int16 pixel = data->read_uint16_little();
        if (pixel != 0) {
          *mp |= m;
        }
        *dp = pixel;
        dp++;
        if ((m <<= 1) == 0) {
          mp++;
          m = 0x01;
        }
      } 
      mp = mask + y * maskline;
      m = 0x01;
    }
    fset->characters[i] = sprite;
  }
  
  return fset;
}

void MFontReader::close()
{
  isopen = false;  
  data->close();
  delete data;
}
