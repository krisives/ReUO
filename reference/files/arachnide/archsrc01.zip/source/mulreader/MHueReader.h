//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  MHueReader.h
//
//  Reader for hues.mul
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __M_HUEDATA_READER_H__
#define __M_HUEDATA_READER_H__

class FileReader;
class IniFile;

class MHueReader {
  private :
    static bool isopen;
    static FileReader *data;
    
  public :
    static bool initialize(IniFile *config);
    static void finalize();
    static bool upandrun;
    
    static bool open(const byte *mul_filename);
    static void readin(unsigned int16 hues[MAX_HUES][32]);

    static void close();

#ifdef SANE
    MHueReader();
#endif
};

#endif