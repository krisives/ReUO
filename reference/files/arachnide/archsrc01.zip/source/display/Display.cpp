//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Diplay.cpp
//
//  Master SDL-interface control. (Creates and manages screen and events)
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include <stdlib.h>
#include "../SDL/SDL.h"
#include "../config.h"
#include "../memguard.h"

#include "Box.h"
#include "Display.h"
#include "../system/system.h"
#include "../util/IniFile.h"

Box  *Display::masterbox;
bool  Display::upandrun = false;


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Display::Display
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
Display::Display()
{
#ifdef SANE
  System::panic("Initialization of static class");
}
#endif

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Display::initialize
//
// Initalizes display and video driver.
//
// returns true on success. false otherwise
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool Display::initialize(IniFile *config)
{
#ifdef SANE
  if (upandrun) {
    return false;
  }
#endif

  masterbox = NULL;
  unsigned int32 width  = config->getInteger("WIDTH",  640);
  unsigned int32 height = config->getInteger("HEIGHT", 480);
  bool fullscreen     = config->getBoolean("FULLSCREEN", false);

  if (SDL_Init(SDL_INIT_VIDEO) < 0 ) {
    std::string message;
    System::panic("Unable to init SDL: %s", SDL_GetError());
    return false;
  }

  SDL_Surface *screen;
  Sint32 flags = SDL_SWSURFACE | SDL_HWPALETTE;

  SDL_Rect **modes;
  modes = SDL_ListModes(NULL, SDL_FULLSCREEN | SDL_SWSURFACE | SDL_HWPALETTE);
  //const SDL_VideoInfo *videoinfo;
  //videoinfo = SDL_GetVideoInfo();


  if (fullscreen) {
    flags |= SDL_FULLSCREEN;    
    unsigned int32 i = 0;
    while (modes[i] != NULL) {
      if ((modes[i]->w == width) && (modes[i]->h == height)) {
        break;
      }
      i++;
    }
    if (modes[i] == NULL) {
      System::panic("Desired video mode %dx%d is not aviable for fullscreen.", width, height);
    }
  }

  screen = SDL_SetVideoMode(width, height, 15, flags);
  if ( screen == NULL ) {
    System::panic("Unable to set %dx%x 15bit color depth video mode (FullScreen): %s", width, height, SDL_GetError());
    return false;
  }

  masterbox = new Box(Box::ADOPT, screen);
  
  upandrun = true;
  return true;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Display::finalize
//
// Cleansup display.
//
// returns true on success. false otherwise
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void Display::finalize()
{
  delete masterbox;
  upandrun = false;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Display::width
//
// returns screen width
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
int32 Display::width()
{
  return masterbox->width();
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Display::height
//
// returns screen height
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
int32 Display::height()
{
  return masterbox->height();
}
