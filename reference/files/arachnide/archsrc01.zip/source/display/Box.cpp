//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Box.cpp
//
//  A rectangle screen part.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <stdlib.h>
#include <string.h>
#include "../SDL/SDL.h"
#include "../config.h"
#include "../memguard.h"

#include "../system/system.h"
#include "Box.h"
#include "Sprite.h"

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Box::Box
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
Box::Box(unsigned int32 s_mode, SDL_Surface *s_screen)
{
  mode = s_mode;
  scrollbuf = 0;
  switch (s_mode) {
    case ADOPT :
      screen = s_screen;
      break;
    case CLONE :
      screen = SDL_CreateRGBSurface(s_screen->flags, 
                                    s_screen->w,
                                    s_screen->h,
                                    s_screen->format->BitsPerPixel,
                                    s_screen->format->Rmask,
                                    s_screen->format->Gmask,
                                    s_screen->format->Bmask,
                                    s_screen->format->Amask
                                   );
      if (screen == NULL) {
        System::panic("Cannot initialize display");
      }
      break;
    default :
      System::panic("INTERNAL FAILURE, unkown BOX mode");
      break;
  }
  memsize = screen->h*screen->pitch;
  // Initialize clipping to full screen
  clip_u = 0;
  clip_l = 0;
  clip_r = screen->w - 1;
  clip_d = screen->h - 1;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Box::~Box
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
Box::~Box()
{  
  if (scrollbuf != NULL) {
    free(scrollbuf);
  }
  if (mode == CLONE) {
    SDL_FreeSurface(screen);
  }  
}

void Box::drawpixel(signed int32 x, signed int32 y, unsigned int8 red, unsigned int8 green, unsigned int8 blue)
{
  Uint32   pixel;
  //Uint8    *bits;

 /* Map the color yellow to this display (R=0xFF, G=0xFF, B=0x00)
    Note:  If the display is palettized, you must set the palette first.
  */
  //pixel = SDL_MapRGB(screen->format, red, green, blue);
  pixel = (((red >> 3)& 0x1f) << 10) | (((green >> 3) & 0x1f) << 5) | ((blue >> 3) & 0x1f);


  //bits = ((Uint8 *)screen->pixels)+y*screen->pitch+(x << 1);
   
  //*((Uint16 *)(pixels + y*screen->pitch + x*bpp)) = (Uint16)pixel;
  //*((Uint16 *)(pixels + y*screen->pitch + x*bpp)) = (Uint16)pixel;

  /* Set the pixel */
  //switch(bpp) {
  //      case 1:
  //        *((Uint8 *)(bits)) = (Uint8)pixel;
  //        break;
  //    case 2:
  //          *((Uint16 *)(bits)) = (Uint16)pixel;
  *((Uint16 *)(((Uint8 *)screen->pixels)+y*screen->pitch+(x << 1))) = (Uint16)pixel;
  //          break;
  //      case 3: { // Format/endian independent 
  //          Uint8 r, g, b;
  //          r = (pixel>>screen->format->Rshift)&0xFF;
  //          g = (pixel>>screen->format->Gshift)&0xFF;
  //          b = (pixel>>screen->format->Bshift)&0xFF;
  //          *((bits)+screen->format->Rshift/8) = r; 
  //          *((bits)+screen->format->Gshift/8) = g;
  //          *((bits)+screen->format->Bshift/8) = b;
  //          }
  //          break;
  //     case 4:
  //          *((Uint32 *)(bits)) = (Uint32)pixel;
  //          break;
  //}
}

bool Box::lock()
{
  if ( SDL_MUSTLOCK(screen) ) {
    if ( SDL_LockSurface(screen) < 0 )
      return false;
  }
  return true;
}

void Box::unlock()
{
  if ( SDL_MUSTLOCK(screen) ) {
     SDL_UnlockSurface(screen);
  }
}

void Box::update()
{
  SDL_UpdateRect(screen, 0, 0, screen->w, screen->h);
}


int32 Box::width()
{
  return screen->w;
}


int32 Box::height()
{
  return screen->h;
}

void Box::scroll(int32 x, int32 y)
{
  //if (scrollbuf == NULL) {
  //  scrollsize   = memsize + 1;
  //  if (scrollbuf == NULL) {
  //    // PANIC
  //  }
  //}
  //memcpy(scrollbuf, screen->pixels, x);
  //memcpy(screen->pixels, (void *)((size_t) screen->pixels + x), memsize - x);
  //memcpy((void *)((size_t) screen->pixels + memsize - x), scrollbuf, x); 
  int32 w = y * (screen->pitch) + (x << 1);
  if (w > 0) {
    memmove(screen->pixels, ((byte *) screen->pixels) + w, memsize - w);
  } else {
    memmove(((byte *) screen->pixels) - w, screen->pixels, memsize + w);
  }
}


SDL_PixelFormat *Box::pixelformat()
{
  return screen->format;
}


void Box::drawSprite(int32 x, int32 y, Sprite *sprite)
{
  int32 h   = y + sprite->height;
  int32 w   = x + sprite->width;
 
  unsigned byte *m   = sprite->mask;

  byte *src = (byte *) sprite->data;
  unsigned int32 lf = (screen->pitch - ((sprite->width) * 2)); // destination line feed
  unsigned int32 mf = (sprite->width >> 3) + 1;                // mask feed
  unsigned int32 sf = 0;                                       // source feed
  unsigned int8  mo = 0x01;           // mask start value per line, (can differ through clipping)

  if (x < clip_l) {
    lf = (screen->pitch - (sprite->width * 2) + (clip_l - x) * 2);
    m += ((clip_l - x) >> 3);
    sf =  (clip_l - x) * 2;
    src += sf;
    mo = 1 << ((clip_l - x) & 0x7);
    x  = clip_l;
  } 
  if (w > clip_r) {
    lf  = (screen->pitch - (clip_r + 1- x) * 2);
    sf  = (w - clip_r - 1) * 2;
    w   = clip_r + 1;
  }
  if (y < clip_u) {
    m   += mf * (clip_u - y);
    src += (sprite->width * 2) * (clip_u - y);
    y = clip_u;
  }
  if (h > clip_d) {
    h = clip_d + 1;
  }

  byte *dst = (byte *) screen->pixels + y * screen->pitch + (x * 2);
  unsigned byte *ms = m;
  unsigned int8 mask = mo;

  for(int32 i = y; i < h; i++) {
    for(int32 j = x; j < w; j++) {
      if ((*m & mask) != 0)  {
        *((Uint16 *) dst) = *((Uint16 *) src);
      }
      src += 2;
      dst += 2;
      if ((mask <<=1) == 0) {
        mask = 0x01;
        m++;
      }
    }
    mask = mo;
    ms += mf;
    m   = ms;
    dst += lf;
    src += sf;
  }
}

void Box::drawSprite(int32 x, int32 y, Sprite *sprite, int32 clip_l, int32 clip_u, int32 clip_r, int32 clip_d)
{
  int32 h   = y + sprite->height;
  int32 w   = x + sprite->width;
 
  unsigned byte *m   = sprite->mask;

  byte *src = (byte *) sprite->data;
  unsigned int32 lf = (screen->pitch - ((sprite->width) * 2)); // destination line feed
  unsigned int32 mf = (sprite->width >> 3) + 1;                // mask feed
  unsigned int32 sf = 0;                                       // source feed
  unsigned int8 mo  = 0x01;           // mask start value per line, (can differ through clipping)

#ifdef SANE
  if ((clip_l < 0) || (clip_r < 0) || (clip_u < 0) || (clip_d < 0) || 
      (clip_l >= screen->w) || (clip_r >= screen->w) || (clip_u >= screen->h) || (clip_d >= screen->h)) {
    System::panic("Errorneous clipping rectangle");
  }
#endif

  if (x < clip_l) {
    lf = (screen->pitch - (sprite->width * 2) + (clip_l - x) * 2);
    m += ((clip_l - x) >> 3);
    sf =  (clip_l - x) * 2;
    src += sf;
    mo = 1 << ((clip_l - x) & 0x7);
    x  = clip_l;
    if (w > clip_r) {
      // it's clipped left and right, now starts to be really complicated....
      sf += (w - clip_r - 1) * 2;
      lf += (w - clip_r - 1) * 2;
      w   = clip_r + 1;
    }
  } else if (w > clip_r) {
    lf  = (screen->pitch - (clip_r + 1- x) * 2);
    sf  = (w - clip_r - 1) * 2;
    w   = clip_r + 1;
  }
  if (y < clip_u) {
    m   += mf * (clip_u - y);
    src += (sprite->width * 2) * (clip_u - y);
    y = clip_u;
  }
  if (h > clip_d) {
    h = clip_d + 1;
  }

  byte *dst = (byte *) screen->pixels + y * screen->pitch + (x * 2);
  unsigned byte *ms = m;
  unsigned int8 mask = mo;

  for(int32 i = y; i < h; i++) {
    for(int32 j = x; j < w; j++) {
      if ((*m & mask) != 0)  {
        *((Uint16 *) dst) = *((Uint16 *) src);
      }
      src += 2;
      dst += 2;
      if ((mask <<=1) == 0) {
        mask = 0x01;
        m++;
      }
    }
    mask = mo;
    ms += mf;
    m   = ms;
    dst += lf;
    src += sf;
  }
}
