//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Sprite.cpp
//
//  Well what the name says :o), a Sprite
//
//  Holds grafic data, size information and a visible bit mask.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include "../Sdl/SDL.h"
#include "../config.h"
#include "../memguard.h"

#include "../objects/Cache.h"
#include "Sprite.h"

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Sprite::Sprite
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
Sprite::Sprite(unsigned int32 s_width, unsigned int32 s_height)
{
  width  = s_width;
  height = s_height;
  data   = malloc(height * width * 2 + 1, "Sprite.data");
  mask   = NULL;
  type   = SPRITE_MAP;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Sprite::~Sprite
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
Sprite::~Sprite()
{  
  free(data);
  if (stretched) {
    free(mask);
  } 
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Sprite::setPixel
//
// Set's a pixel in the sprite, respecting current data format.
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void Sprite::setPixel(unsigned int32 x, unsigned int32 y, unsigned int16 pixel) 
{
  Uint8    *bits;
  bits = ((Uint8 *) data) + y * width * 2 + x * 2;
  *((Uint16 *)(bits)) = (Uint16) pixel;
}