//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Diplay.cpp
//
//  Master SDL-interface control. (Creates and manages screen and events)
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __DISPLAY_H__
#define __DISPLAY_H__

struct SDL_Surface;
class Box;
class IniFile;

class Display {
  public :
    static bool initialize(IniFile *config);
    static void finalize();
    static bool upandrun;

    static Box  *masterbox;

    static int32 width();
    static int32 height();

#ifdef SANE
    Display(); // Panic if initialized (static class maynot be instanced)
#endif
};

#endif