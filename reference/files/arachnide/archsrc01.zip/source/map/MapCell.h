//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  MapCell
//
//  A mapCell
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __MAP_CELL_H__
#define __MAP_CELL_H__

class MapCell {
  public :
    unsigned int32 id;
    signed   int8 z;
    bool stretched;

    unsigned int32 hl;       // height of tile on the left side
    unsigned int32 hr;       // height of tile on the right side 
    unsigned int32 stl;      // stretch the corner to this height on the left side 
    unsigned int32 str;      // stretch the corner to this height on the left side 

    unsigned int32 bright;
};

#endif