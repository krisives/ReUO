//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Tiledata.cpp
//
//  static tiledata.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __TILEDATA_H__
#define __TILEDATA_H__

// TILE FLAGS

  #define FLAG_WATER          0x80000000    
  #define FLAG_BLOCKING       0x40000000
//#define FLAG_DAMAGE         0x20000000
  #define FLAG_WALL           0x10000000
//#define FLAG_LIQUID         0x08000000
//#define FLAG_NON_BLOCKING   0x04000000
//#define FLAG_EQUIP          0x02000000
  #define FLAG_FLOOR          0x01000000

//#define FLAG_AN             0x00800000
//#define FLAG_A              0x00400000
//#define FLAG_WALL2          0x00200000
//#define FLAG_WINDOW         0x00100000
//#define FLAG_STACKABLE      0x00080000
//#define FLAG_CLIMBABLE      0x00040000
  #define FLAG_WALKABLE       0x00020000
//#       UNUSED              0x00010000

//#define FLAG_LIGHT_SOURCE   0x00008000
//#define FLAG_EQUIP2         0x00004000
//#define FLAG_CONTAINER      0x00002000
//#define FLAG_MAP            0x00001000
//        UNUSED              0x00000800
//        UNUSED              0x00000400
//#define FLAG_TRANSPARENT    0x00000200
//#define FLAG_DESCRIPTION    0x00000100

//#define FLAG_WALKABLE???    0x00000080
//#define FLAG_STAIRS         0x00000040
//#define FLAG_DOOR           0x00000020
//#define FLAG_ROOF           0x00000010
//#define FLAG_WHOLE_BODYITEM 0x00000008
//        FLAG_UNKOWN         0x00000004
//        FLAG_UNKOWN         0x00000002
//#define FLAG_ANIMATED       0x00000001

  #define MAP_WALK            0x00000004

class Tiledata {
  public :
    unsigned int32 id;
    unsigned int32 flags;
    unsigned int32 height;
    byte *name;
    unsigned int16 transparent;
    
    Tiledata();
    ~Tiledata();

    unsigned int32 iswater();
    unsigned int32 isfloor();
    unsigned int32 iswall();
    unsigned int32 isroof();
};

#endif