//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Welcome.cpp
//
//  The welcome screen.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "../Sdl/SDL.h"
#include "../config.h"
#include "../memguard.h"

#include "Welcome.h"
#include "../display/Box.h"
#include "../display/Display.h"
#include "../display/Sprite.h"
#include "../fission/AnimFission.h"
#include "../graphics/GumpArt.h"
#include "../graphics/TextArt.h"
#include "../objects/ObjectMan.h"
#include "../mulreader/MAnimReader.h"
//#include "../skin/AnimGroup.h"
#include "../skin/AnimSprite.h"
#include "../system/system.h"
#include "../system/Console.h"
#include "../world/World.h"

#define MAX(x,y) (x < y ? y : x)
#define MIN(x,y) (x < y ? x : y)

bool  Welcome::upandrun = false;

#ifdef SANE
Welcome::Welcome()
{
  System::panic("Initialization of static class");
}
#endif

bool Welcome::initialize(IniFile *config)
{

  upandrun = true;
  return true;
}

void Welcome::finalize()
{
  upandrun = false;
}


int32 lighting = 0;
int32 x_lighting = 0;

int32 Welcome::run()
{
  int32 scroll = 0;
  int32 x = 0;
  //Sprite *sp = artReader.readMapSprite(0x3FF0);
  //front->drawSprite(-10, -10, sp);
  bool leftdown = false;
  bool rightdown = false;
  bool leftclick = false;
  bool rightclick = false;
  unsigned int32 mousex = 0;
  unsigned int32 mousey = 0;
  int32 dir = 0;
  
  time_t start, now;
  time(&start);
  unsigned int32 frame = 0;
  unsigned int32 cycle = 0;

  unsigned int32 w = Display::width();
  unsigned int32 h = Display::height();
  Box *screen = Display::masterbox;
    
  for(;;) {
    frame++;
    cycle++;
    SDL_Event event;    
    SDL_PollEvent(&event);

    switch (event.type) {
        case SDL_KEYDOWN:
            if (event.key.keysym.scancode != 1) {
              // Quit on ESC
              break;
            }
            // !!! FALL_THROUGH !!!
        case SDL_QUIT:
            return -1;
            break;
        case SDL_MOUSEBUTTONDOWN :
            if (event.button.button == SDL_BUTTON_LEFT) {
               if (!leftdown) {
                 leftclick = true;
               }
              leftdown = true;
            }
            if (event.button.button == SDL_BUTTON_RIGHT) {
              if (!rightdown) {
                rightclick = true;
              }
              rightdown = true;
            }

            break;
        case SDL_MOUSEBUTTONUP :
            if (event.button.button == SDL_BUTTON_LEFT) {
              leftdown = false;
            }
            if (event.button.button == SDL_BUTTON_RIGHT) {
              rightdown = false;
            }
            break;
        case SDL_MOUSEMOTION:
            mousex = event.motion.x;
            mousey = event.motion.y;
    }
    if (rightdown || leftdown) {
      //World::walk_creature(0, dir);           
      return 0;
    }

    screen->lock();
    Sprite *sprite;

    sprite = ObjectMan::get_gump(0xe14);
    if (sprite != NULL) {
      for (unsigned int32 x = 0; x < w; x += sprite->width) {
        for (unsigned int32 y = 0; y < h; y += sprite->height) {
          screen->drawSprite(x, y, sprite);        
        }
      }
      sprite->release();
    }

    // a lighting    
    if ((lighting >> 4) % 16 == 0) {
      if (x_lighting == 0) {
        x_lighting = 380 + rand() % 150;
      }
      sprite = ObjectMan::get_gump(0x4e20 + (lighting >> 9));
      screen->drawSprite(x_lighting, 0, sprite, 0, 0, w - 1, (h - 1) / 2);
      sprite->release();
    } else {
      x_lighting = 0;
    }
    if (++lighting == (10 << 9)) {
      lighting = 0;
    }

    // the net
    sprite = ObjectMan::get_static_sprite(0x10bc);
    screen->drawSprite(-50 + 0 * 44, 126 - 75, sprite);
    sprite->release();
    
    sprite = ObjectMan::get_static_sprite(0x10bb);
    screen->drawSprite(-50 + 1 * 44,  48 - 75, sprite);
    sprite->release();

    sprite = ObjectMan::get_static_sprite(0x10ba);
    screen->drawSprite(-50 + 2 * 44,  20 - 75, sprite);
    sprite->release();

    sprite = ObjectMan::get_static_sprite(0x10b9);
    screen->drawSprite(-50 + 3 * 44,  18 - 75, sprite);
    sprite->release();

    sprite = ObjectMan::get_static_sprite(0x10b8);
    screen->drawSprite(-50 + 4 * 44, 150 - 75, sprite);
    sprite->release();
     
    // the spider
    AnimSprite *animSprite = AnimFission::getFrame(0x1c, AnimFission::WALK, 7, 0);
    sprite = (Sprite *) animSprite;
    screen->drawSprite(150 - animSprite->offsetx, 150 - animSprite->offsety, sprite);
    AnimFission::release();  

    TextArt::draw_text(165, 70, 0, "A r a c h n i d e    0 . 1");

/*    sprite = ObjectMan::get_gump(0x67);
    screen->drawSprite(515 - 40, 30, sprite);
    sprite->release();
#ifdef SANE
    draw_text(558 - 40, 45 + 30, 3, "S A N E");
#else
    draw_text(558 - 40, 45 + 30, 3, "F R E E");
#endif
    draw_text(558 - 40, 70 + 30, 3, "Build");
*/    
#ifdef SANE
    TextArt::draw_text(330, 105, 3, "SANE Build");
#else
    TextArt::draw_text(330, 105, 3, "FREE Build");
#endif
    //draw_text(558 - 40, 70 + 30, 3, "Build");

    unsigned int32 rectx = 130;
    unsigned int32 recty = 250;
    unsigned int32 rectw = 460;
    unsigned int32 recth = 150;

    GumpArt::draw_gump_rect(rectx, recty, rectw, recth, GumpArt::GUMPRECT_FRONT_GRAY);    
    // the castle
    sprite = ObjectMan::get_gump(0x58a);
    screen->drawSprite(rectx + rectw - sprite->width, recty - sprite->height + 12, sprite);
    sprite->release();

    GumpArt::draw_gump_rect(rectx + 200, recty +  30, 235, 15, GumpArt::GUMPRECT_BRIGHT_GRAY);
    GumpArt::draw_gump_rect(rectx + 200, recty +  75, 235, 15, GumpArt::GUMPRECT_BRIGHT_GRAY);
    GumpArt::draw_gump_rect(rectx + 200, recty + 120, 235, 15, GumpArt::GUMPRECT_BRIGHT_GRAY);

    TextArt::draw_text(rectx + 20, recty +  55, 2, "Server Address");
    TextArt::draw_text(rectx + 20, recty + 100, 2, "Account Name");
    TextArt::draw_text(rectx + 20, recty + 145, 2, "Password");
    
    screen->unlock();
    screen->update();
    time(&now);

    double elapsed_time = difftime(now, start );
    /*
    if (elapsed_time > 5) {
      Console::printf("+ frames/sec: %2.1f", (frame / elapsed_time));
      frame = 0;
      time(&start);
    } 
    */
    if ((cycle & 0x7) == 0) {
      System::cycle();
      if ((cycle & 0xFF) == 0) {
      }
    }
    leftclick = false;
    rightclick = false;
  }
  // never recached
}