//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Heart.cpp
//
//  Handles global system management.
// 
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string.h>
#include "../config.h"
#include "../memguard.h"

#include "Heart.h"
#include "SubSystem.h"
#include "../display/display.h"
#include "../fission/AnimFission.h"
#include "../fission/MapPrepare.h"
#include "../fission/TiledataFission.h"
#include "../fission/WorldFission.h"
#include "../graphics/Stretch.h"
#include "../mulreader/MMapReader.h"
#include "../mulreader/MStaticReader.h"
#include "../mulreader/MTiledataReader.h"
#include "../mulreader/MAnimReader.h"
#include "../mulreader/MArtReader.h"
#include "../mulreader/MFontReader.h"
#include "../mulreader/MGumpReader.h"
#include "../mulreader/MHueReader.h"
#include "../mulreader/MVerdataReader.h"
#include "../mulreader/MulCentral.h"
#include "../objects/cache.h"
#include "../objects/ObjectMan.h"
#include "../screens/Welcome.h"
#include "../system/Console.h"
#include "../system/system.h"
#include "../util/IniFile.h"
#include "../vision/ScreenRenderer.h"
#include "../vision/Vision.h"
#include "../world/Walking.h"
#include "../world/World.h"

#define SUBSYS_ENTRY(system, runlevel, desc) {system::initialize, system::finalize, &system::upandrun, runlevel, desc}

unsigned int32 Heart::level   = 0; // current run level
IniFile *      Heart::config  = NULL;
bool           Heart::verbose;

const SubSystem subsystems[] = {
  SUBSYS_ENTRY( System,          mSYSTEM,  "System"             ),
  SUBSYS_ENTRY( Console,         mCONSOLE, "Console"            ),

  SUBSYS_ENTRY( Display,         mDISPLAY, "Display"            ),

  SUBSYS_ENTRY( MAnimReader,     mREADERS, "Animation reader"   ),
  SUBSYS_ENTRY( MArtReader,      mREADERS, "Art reader"         ),
  SUBSYS_ENTRY( MMapReader,      mREADERS, "Map reader"         ),
  SUBSYS_ENTRY( MStaticReader,   mREADERS, "Static reader"      ),
  SUBSYS_ENTRY( MTiledataReader, mREADERS, "Tiledata reader"    ),
  SUBSYS_ENTRY( MFontReader,     mREADERS, "Font reader"        ),
  SUBSYS_ENTRY( MGumpReader,     mREADERS, "Gump reader"        ),
  SUBSYS_ENTRY( MHueReader,      mREADERS, "Hue reader"         ),
  SUBSYS_ENTRY( MVerdataReader,  mREADERS, "Verdata reader"     ),
  SUBSYS_ENTRY( MulCentral,      mREADERS, "MulCentral"         ),

  SUBSYS_ENTRY( Cache,           mOBJECTS, "Cache"              ),
  SUBSYS_ENTRY( ObjectMan,       mOBJECTS, "Object manager"     ),

  SUBSYS_ENTRY( AnimFission,     mFISSION, "Animation fission"  ),
  SUBSYS_ENTRY( MapPrepare,      mFISSION, "Map preperation"    ),
  SUBSYS_ENTRY( Stretch,         mFISSION, "Map stretching"     ),
  SUBSYS_ENTRY( TiledataFission, mFISSION, "TiledataFission"    ),

  SUBSYS_ENTRY( Welcome,         mWELCOME, "Welcome screen"     ),

  SUBSYS_ENTRY( Walking,         mIN_GAME, "Walking"            ),
  SUBSYS_ENTRY( World,           mIN_GAME, "World reflection"   ),
  SUBSYS_ENTRY( ScreenRenderer,  mIN_GAME, "ScreenRenderer"     ),
  SUBSYS_ENTRY( Vision,          mIN_GAME, "Vision"             ),
  SUBSYS_ENTRY( WorldFission,    mIN_GAME, "World fission"      ),

  {NULL, NULL, NULL, 0}
};

#define ________ 0
const unsigned int32 level_mask[][2] = {
  {LEVEL_SHUTDWN, mSHUTDWN                                                                                         },
  {LEVEL_SYSTEM , mSYSTEM                                                                                           },
  {LEVEL_CONSOLE, ________  + mCONSOLE                                                                              },
  {LEVEL_DISPLAY, mSYSTEM   + mCONSOLE + mDISPLAY                                                                   },
  {LEVEL_READERS, mSYSTEM   + mCONSOLE + mDISPLAY + mREADERS                                                        },
  {LEVEL_OBJECTS, mSYSTEM   + mCONSOLE + mDISPLAY + mREADERS + mOBJECTS                                             },
  {LEVEL_FISSION, mSYSTEM   + mCONSOLE + mDISPLAY + mREADERS + mOBJECTS + mFISSION                                  },
  {LEVEL_WELCOME, mSYSTEM   + mCONSOLE + mDISPLAY + mREADERS + mOBJECTS + mFISSION + mWELCOME                       },
  {LEVEL_WELCNET, mSYSTEM   + mCONSOLE + mDISPLAY + mREADERS + mOBJECTS + mFISSION + mWELCOME + mNETWORK            },
  {LEVEL_OFFGAME, mSYSTEM   + mCONSOLE + mDISPLAY + mREADERS + mOBJECTS + mFISSION + ________ + ________ + mIN_GAME },
  {LEVEL_NETGAME, mSYSTEM   + mCONSOLE + mDISPLAY + mREADERS + mOBJECTS + mFISSION + ________ + mNETWORK + mIN_GAME },
};
#undef ________

#ifdef SANE
// Panic of initialization (static class maynot be instanced)
Heart::Heart()
{
  System::panic("Initialization of static class");
}
#endif

void Heart::startup(IniFile *s_config)
{
  config  = s_config;
  verbose = config->getBoolean("VERBOSE HEART", true);
}


bool Heart::enter_level(unsigned int32 nlevel)
{ 
  bool do_verbose = verbose & (level > 0); // don't verbose if in runlevel 0
  if (level == nlevel) {
    if (do_verbose) {    
      Console::printf("HRT: already in level %d", nlevel);
    }
    return true;
  }
  if (do_verbose) {    
    Console::printf("HRT: entering runlevel %d", nlevel);
  }
#ifdef SANE
  if (level_mask[level][0] != level) {
    System::panic("System level table inconsistent");
  }
  if (level_mask[nlevel][0] != nlevel) {
    System::panic("System level table inconsistent");
  }
#endif  
  unsigned int32 omask  = level_mask[ level][1]; // old system mask
  unsigned int32 nmask  = level_mask[nlevel][1]; // new system mask
  
  unsigned int32 differ   = omask ^ nmask;  // difference of both masks
  unsigned int32 initmask = differ & nmask; // levels to be initalized 
  unsigned int32 finmask  = differ & omask; // levels to finalize

  // walk to end to the table
  const SubSystem *entry = subsystems;
  while (entry->initialize != NULL) {
    entry++;
  }
  // first finalize systems not to be needed
  // start from table top running backward.
  while (entry >= subsystems) {
    if ((entry->runlevel & finmask) != 0) {
      // this system hits the mask.
      if (do_verbose) {
        Console::printf("HRT:   - finalizing  %s", entry->desc);
      }
      if (entry->runlevel == LEVEL_SYSTEM) {
        // do no longer verbose after shutting down the system,
        Console::printf("HRT: Shutting down system now - goodbye, have a nive day", entry->desc);
        do_verbose = false;
      }
      entry->finalize();
    }    
    entry--;
  }
  // now initalize the new systems
  // this time walk normally from begin of table downward.
  entry = subsystems;
  while (entry->initialize != NULL) {
    if ((entry->runlevel & initmask) != 0) {
      // this system hits the mask.
      if (do_verbose) {
        Console::printf("HRT:   + initializing %s", entry->desc);
      }
      bool asw = entry->initialize(config);
      if (asw == false) {
        Console::printf("HRT:   FAILED!");
        enter_level(LEVEL_SHUTDWN);
        return false;
      }
    }    
    entry++;
  }
  if (do_verbose) {
    Console::printf("HRT: runlevel %d reached", nlevel);
  }
  level = nlevel;
  return true;
}
