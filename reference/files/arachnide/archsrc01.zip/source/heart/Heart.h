//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Heart.h
//
//  Handles global system management.
//
// 
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __HEART_H__
#define __HEART_H__

#define mSHUTDWN  0x00000000
#define mSYSTEM   0x00000001
#define mCONSOLE  0x00000002
#define mDISPLAY  0x00000004
#define mREADERS  0x00000008
#define mOBJECTS  0x00000010
#define mFISSION  0x00000020
#define mWELCOME  0x00000040
#define mNETWORK  0x00000080
#define mIN_GAME  0x00000100

#define LEVEL_SHUTDWN    0
#define LEVEL_SYSTEM     1
#define LEVEL_CONSOLE    2
#define LEVEL_DISPLAY    3
#define LEVEL_READERS    4
#define LEVEL_OBJECTS    5
#define LEVEL_FISSION    6
#define LEVEL_WELCOME    7
#define LEVEL_WELCNET    8
#define LEVEL_OFFGAME    9
#define LEVEL_NETGAME   10

class IniFile;

class Heart {
  private :
    static bool init;
    static bool verbose;
    static unsigned int32 level; // current run level
    static IniFile *config;

  public :
    static void startup(IniFile *config);
    static bool enter_level(unsigned int32 level);

#ifdef SANE
    Heart(); // Panic if initialized (static class maynot be instanced)
#endif
};

#endif