//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  TextArt.cpp
//
//  Draws text onto the screen.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "TextArt.h"
#include "../display/Box.h"
#include "../display/Display.h"
#include "../display/Sprite.h"
#include "../objects/ObjectMan.h"
#include "../system/system.h"

#ifdef SANE
TextArt::TextArt()
{
  System::panic("Initialization of static class");
}
#endif

void TextArt::draw_text(int32 x, int32 y, unsigned int32 set, const byte *text) 
{
  Box *screen = Display::masterbox;
  while (*text != 0) {
    Sprite *sprite = ObjectMan::get_font_sprite(set, *text);
    if (sprite != NULL) {
      screen->drawSprite(x, y - sprite->height, sprite);
      x += sprite->width + 1;     
    }
    // no need to release font sprites.
    text++;
  }
}
