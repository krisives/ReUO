//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Flipper.cpp
//
//  Flips sprites.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "Flipper.h"
#include "../objects/ObjectMan.h"
#include "../skin/AnimSprite.h"
#include "../skin/AnimGroup.h"
#include "../system/system.h"
#include "../util/IniFile.h"

#ifdef SANE
Flipper::Flipper()
{
  System::panic("Initialization of static class");
}
#endif

AnimSprite *Flipper::fliphorz(AnimSprite *sprite)
{
  unsigned int32 width  = sprite->width;
  unsigned int32 height = sprite->height;
  AnimSprite *nsprite = new AnimSprite(width, height);
  nsprite->offsetx = width - sprite->offsetx;
  nsprite->offsety = sprite->offsety;
  nsprite->stretched = true;
  unsigned int32 maskline = (width >> 3) + 1;
  unsigned byte *omask = sprite->mask;
  unsigned byte *nmask  = (unsigned byte *) malloc(maskline * height, "AnimSprite.mask");
  nsprite->mask = nmask;
  memset(nmask, 0x00, maskline * height);
  unsigned byte *nmp = nmask;
  unsigned byte *omp = omask;
  unsigned byte *ndt = (unsigned byte *) nsprite->data;
  unsigned int8  m  =  0x01;
  for (unsigned int32 y = 0; y < height; y++) {
    for (unsigned int32 x = 0, ox = width - 1; x < width; x++, ox--) {
      //*(unsigned short *) ((byte *) nsprite->data + ((y * width + x) << 1)) = *(unsigned short *) ((byte *) sprite->data + ((y * width + ox) << 1));
      *(unsigned int16 *) (ndt) = *((unsigned int16 *) ((byte *) sprite->data + ((y * width + ox) << 1)));
      if (*((omp + (ox >> 3))) & (1 << (ox & 0x07)) ) {
        *nmp |= m;
      }
      if ((m <<= 1) == 0) {
        m = 0x01;
        nmp++;
      }
      ndt += 2;
    }
    m = 0x01;
    nmp = nmask + y * maskline;
    omp = omask + y * maskline;
  } 
  return nsprite;
}


AnimGroup *Flipper::fliphorz_group(AnimGroup *group)
{
  AnimGroup *ngroup = new AnimGroup;
  ngroup->framecount = group->framecount;
  ngroup->frames = (AnimSprite **) malloc(group->framecount * sizeof (AnimSprite *), "AnimGroup.frame");
  for (unsigned int32 i = 0; i < group->framecount; i++) {
    ngroup->frames[i] = fliphorz(group->frames[i]);
  }
  return ngroup;
}