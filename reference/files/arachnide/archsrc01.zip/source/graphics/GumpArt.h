//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  GumpArt.h
//
//  Draws text onto the screen.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __GUMP_ART_H__
#define __GUMP_ART_H__

class GumpArt {
  public :
    static void draw_gump_rect(int32 rectx, int32 recty, int32 rectw, int32 recth, unsigned int32 recttype);

    enum {
      GUMPRECT_FRONT_GRAY  = 0,
      GUMPRECT_BRIGHT_GRAY = 1,
      GUMPRECT_MAX         = 2,
    };

    static const unsigned int32 gump_rects[GUMPRECT_MAX][9];


#ifdef SANE
    GumpArt(); // Panic if initialised (static class maynot be instanced)
#endif
};

#endif