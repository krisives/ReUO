//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  GumpArt.cpp
//
//  Draws text onto the screen.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "GumpArt.h"
#include "../display/Box.h"
#include "../display/Display.h"
#include "../display/Sprite.h"
#include "../objects/ObjectMan.h"
#include "../system/system.h"

const unsigned int32 GumpArt::gump_rects[GUMPRECT_MAX][9] = {
  // GUMPRECT_FRONT_GRAY
  { 0x13BE, 0x13BF, 0x13C0, 
    0x13C1, 0x13C2, 0x13C3, 
    0x13C4, 0x13C5, 0x13C6, 
  },

  // GUMPRECT_BRIGHT_GRAY
  { 0x0BB8, 0x0BB9, 0x0BBA, 
    0x0BBB, 0x0BBC, 0x0BBD, 
    0x0BBE, 0x0BBF, 0x0BC0, 
  }
};


#ifdef SANE
GumpArt::GumpArt()
{
  System::panic("Initialization of static class");
}
#endif

void GumpArt::draw_gump_rect(int32 rectx, int32 recty, int32 rectw, int32 recth, unsigned int32 recttype)
{
  // draw upper border
  unsigned int32 rect_rlim = rectx + 12 + rectw;
  unsigned int32 rect_dlim = recty + 12 + recth;
  unsigned int32 x;
  unsigned int32 y;
    
  Sprite *sprite;
  Box *screen = Display::masterbox;

  sprite = ObjectMan::get_gump(gump_rects[recttype][0]);
  screen->drawSprite(rectx, recty, sprite);
  unsigned int32 bord_l = sprite->width;
  sprite->release();

  sprite = ObjectMan::get_gump(gump_rects[recttype][1]);
  unsigned int32 bord_u = sprite->height;
  for (x = rectx + bord_l; x < rect_rlim; x+= sprite->width) {
    if (x + sprite->width > rect_rlim) {
      screen->drawSprite(x, recty, sprite, x, recty, rect_rlim, recty + sprite->height);
    } else {
      screen->drawSprite(x, recty, sprite);
    }
  }
  sprite->release();

  sprite = ObjectMan::get_gump(gump_rects[recttype][2]);
  screen->drawSprite(rect_rlim, recty, sprite);
  sprite->release();
    
  // draw lower border
  sprite = ObjectMan::get_gump(gump_rects[recttype][6]);
  screen->drawSprite(rectx, rect_dlim, sprite);
  bord_l = sprite->width;
  sprite->release();

  sprite = ObjectMan::get_gump(gump_rects[recttype][7]);
  for (x = rectx + bord_l; x < rect_rlim; x+= sprite->width) {
    if (x + sprite->width > rect_rlim) {
      screen->drawSprite(x, rect_dlim, sprite, x, rect_dlim, rect_rlim, rect_dlim + sprite->height);
    } else {
      screen->drawSprite(x, rect_dlim, sprite);
    }
  }
  sprite->release();

  sprite = ObjectMan::get_gump(gump_rects[recttype][8]);
  screen->drawSprite(rect_rlim, rect_dlim, sprite);
  sprite->release();

  // draw left border  
  sprite = ObjectMan::get_gump(gump_rects[recttype][3]);
  bord_l = sprite->width;
  for (y = recty + 12; y < rect_dlim; y+= sprite->height) {
    if (y + sprite->height > rect_dlim) {
      screen->drawSprite(rectx, y, sprite, rectx, y, rectx + bord_l, rect_dlim);
    } else {
      screen->drawSprite(rectx, y, sprite);
    }
  }
  sprite->release();
    
  // draw right border  
  sprite = ObjectMan::get_gump(gump_rects[recttype][5]);
  for (y = recty + bord_u; y < rect_dlim; y+= sprite->height) {
    if (y + sprite->height > rect_dlim) {
      screen->drawSprite(rect_rlim, y, sprite, rect_rlim, y, rect_rlim + sprite->width, rect_dlim);
    } else {
      screen->drawSprite(rect_rlim, y, sprite);
    }
  }
  sprite->release();
    
  // draw center border  
  sprite = ObjectMan::get_gump(gump_rects[recttype][4]);
  for (x = rectx + bord_l; x < rect_rlim; x+= sprite->width) {
    for (y = recty + bord_u; y < rect_dlim; y+= sprite->height) {
      screen->drawSprite(x, y, sprite, x, y, rect_rlim, rect_dlim);
    }
  }
  sprite->release(); 
}
