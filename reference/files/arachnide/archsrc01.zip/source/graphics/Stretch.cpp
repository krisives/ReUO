//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Stretch.cpp
//
//  Implentation of the stretch-o-tilt algorithmn.
//  3D-Tile coloring, and color smoothing
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "../fission/MapFission.h"
#include "Stretch.h"
#include "../display/Sprite.h"
#include "../map/MapCell.h"
#include "../objects/ObjectMan.h"
#include "../system/system.h"
#include "../util/IniFile.h"

#define MAX(x,y) (x < y ? y : x)
#define MIN(x,y) (x < y ? x : y)

MapFission * Stretch::mapFission;
bool         Stretch::_3d_coloring;
bool         Stretch::upandrun = false;


#ifdef SANE
Stretch::Stretch()
{
  System::panic("Initialization of static class");
}
#endif

bool Stretch::initialize(IniFile *config)
{
  mapFission = new MapFission;  
  _3d_coloring = config->getBoolean("3D COLORING", true);
  upandrun = true;
  return true;
}

void Stretch::finalize()
{
  delete mapFission;
  upandrun = false;
}

Sprite *Stretch::stretch(MapCell *cell, unsigned int32 x, unsigned int32 y)
{
  Sprite *original = ObjectMan::get_map_sprite(cell->id);
  /* Do not stretch
  {
    Sprite *sprite   = new Sprite(44, 44);
    memcpy(sprite->data, original->data, 44 * 44 * 2);
    sprite->mask = original->mask;
    sprite->stretched = false;  
    original->release();
    return sprite;
  }
  */   
  unsigned int32 hl  = cell->hl;
  unsigned int32 hr  = cell->hr;
  signed int32 stl = cell->stl;
  signed int32 str = cell->str;
  unsigned int32 height = MAX(hl, hr);
  signed int32 sheight = height;

  byte *o_data = (byte *) original->data;
  //
  // brighten the original
  byte *b_data;
  if (_3d_coloring) {
    b_data = (byte *) malloc(44 * 44 * 2, "Sprite.data");
    byte *od = o_data;
    byte *bd = b_data;
    
    o_data = b_data;
    unsigned int32 pixel;
    //unsigned int bright = (stl - str) * 512 / (sheight * 5) + 256;
    unsigned int32 bright = cell->bright;
    
    unsigned int32 brights;
    unsigned int32 brighte;
    unsigned int32 brightw;
    unsigned int32 brightn;
    
    MapCell *neighbour = mapFission->getCell(x, y + 1, true);
    if (neighbour != NULL) {
      brights = neighbour->bright;
      mapFission->release();
    } else {
      brights = 0x100;
    }

    neighbour = mapFission->getCell(x + 1, y, true);
    if (neighbour != NULL) {
      brighte = neighbour->bright;
      mapFission->release();
    } else {
      brighte = 0x100;
    }

    neighbour = mapFission->getCell(x - 1, y, true);
    if (neighbour != NULL) {
      brightw = neighbour->bright;
      mapFission->release();
    } else {
      brightw = 0x100;
    }

    neighbour = mapFission->getCell(x, y - 1, true);
    if (neighbour != NULL) {
      brightn = neighbour->bright;
      mapFission->release();
    } else {
      brightn = 0x100;
    }

    unsigned int32 red;
    unsigned int32 green;
    unsigned int32 blue;
    
    signed int32 by;
    unsigned int32 bl;
    unsigned int32 br;
    for (by = 0; by < 22; by++) {
      int32 bsl = (brightw - bright);
      int32 bsr = (brightn - bright);
      for (signed int32 bx = 0; bx < 22; bx++) {
        bl = bright + (bsl * (22 - bx)) / (44 - by);
        //bl = bright - (bsl * (bx + by - 44) / 22);
        pixel = *((unsigned int16 *) od);
        pixel = ((red   = (((pixel & 0x7C00) * bl) >> 8) ) > 0x7C00 ? 0x7C00 : (red   & 0x7C00)) | 
                ((green = (((pixel & 0x03E0) * bl) >> 8) ) > 0x03E0 ? 0x03E0 : (green & 0x03E0)) | 
                ((blue  = (((pixel & 0x001f) * bl) >> 8) ) > 0x001F ? 0x001F : (blue  & 0x001F));
        *((unsigned int16 *) bd) = pixel;
        od += 2;
        bd += 2;
      }
      for (; bx < 44; bx++) {
        br = bright - (bsr * (22 - bx)) / (44 - by);
        //br = bright - (bsr * (by - bx) / 22);
        pixel = *((unsigned int16 *) od);
        pixel = ( (red   = (((pixel & 0x7C00) * br) >> 8) ) > 0x7C00 ? 0x7C00 : (red   & 0x7C00)) | 
                ( (green = (((pixel & 0x03E0) * br) >> 8) ) > 0x03E0 ? 0x03E0 : (green & 0x03E0)) | 
                ( (blue  = (((pixel & 0x001f) * br) >> 8) ) > 0x001F ? 0x001F : (blue  & 0x001F));
        *((unsigned int16 *) bd) = pixel;
        od += 2;
        bd += 2;
      }
    }
    for (by = 0; by < 22; by++) {
      bl = brights;
      br = bright;
      int32 bsl = (brights - bright);
      int32 bsr = (brighte - bright);
      for (signed int32 bx = 0; bx < 22; bx++) {
        if (bx >= by) {
          bl = bright + (bsl * (22 - bx)) / (44 - by);
          //bl = bright - (bsl * (bx + 44 - by - 44) / 22);
          pixel = *((unsigned int16 *) od);
          pixel = ( (red   = (((pixel & 0x7C00) * bl) >> 8) ) > 0x7C00 ? 0x7C00 : (red   & 0x7C00)) | 
                  ( (green = (((pixel & 0x03E0) * bl) >> 8) ) > 0x03E0 ? 0x03E0 : (green & 0x03E0)) | 
                  ( (blue  = (((pixel & 0x001f) * bl) >> 8) ) > 0x001F ? 0x001F : (blue  & 0x001F));

          *((unsigned int16 *) bd) = pixel;
        } 
        od += 2;
        bd += 2;
      }
      for (; bx < 44; bx++) {
        if (bx <= 44 - by) {
          br = bright - (bsr * (22 - bx)) / (44 - by);
          //br = bright - (bsr * (44 - bx + 44 - by - 44) / 22);
          pixel = *((unsigned int16 *) od);
          pixel = ( (red   = (((pixel & 0x7C00) * br) >> 8) ) > 0x7C00 ? 0x7C00 : (red   & 0x7C00)) | 
                  ( (green = (((pixel & 0x03E0) * br) >> 8) ) > 0x03E0 ? 0x03E0 : (green & 0x03E0)) | 
                  ( (blue  = (((pixel & 0x001f) * br) >> 8) ) > 0x001F ? 0x001F : (blue  & 0x001F));
          *((unsigned int16 *) bd) = pixel;
        }
        od += 2;
        bd += 2;
      }
    }
  }

  Sprite *sprite   = new Sprite(44, height);


  // o -> <o>riginal
  // s -> new <s>prite
  unsigned byte *o_mask = original->mask;
  unsigned int32 masksize = 6 * height;  
  unsigned byte *s_mask = (unsigned byte *) malloc(masksize, "Sprite.mask");    // round_up(44 / 8) => 6
#ifdef SANE
  if (s_mask == NULL) {
    System::message("Out of memory");
  }
#endif
  sprite->mask = s_mask;
  unsigned byte *sm = s_mask;
  memset(s_mask, 0, masksize);

  byte *s_data = (byte *) sprite->data;
  byte *sd = s_data;
  unsigned int8 mask = 0x01;

  unsigned int32 oy;
  for (unsigned int32 sy = 0; sy < height; sy++) {
    for (unsigned int32 sx = 0; sx < 44; sx++) {
      // ox is alway sx (width is not stretched)
      if (sx >= 22) {
        oy = (sy * 44 + (sx - 22) * (hr - str * 2)) / hr;
      } else {
        oy = (sy * 44 - (22 - sx) * (stl * 2 - hl)) / hl;
      }
      // sx/sy are is the new position
      // sx/oy are is the position in the original
      if ((oy >= 0) && (oy < 44)) {
        if (o_mask[oy * 6 + (sx >> 3)] & mask) {
          *((unsigned int16 *) sd) = *((unsigned int16 *) (o_data + oy * 88 + (sx << 1)));
          *sm |= mask;
        }
      }
      sd += 2;
      if ((mask <<= 1) == 0) {
        mask = 0x01;
        sm++;
      }
    }
    sm = s_mask + 6 * (sy + 1);
    mask = 0x01;
  } 

  if (_3d_coloring) {
    free(b_data);
  }
  sprite->stretched = true;
  original->release();
  return sprite;
}

