//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Vision.cpp
//
//  The ingame screen.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "../Sdl/SDL.h"
#include "../config.h"
#include "../memguard.h"

#include "ScreenRenderer.h"
#include "Vision.h"
#include "../display/Display.h"
#include "../mulreader/MAnimReader.h"
#include "../skin/AnimGroup.h"
#include "../system/system.h"
#include "../system/Console.h"
#include "../world/World.h"

#define MAX(x,y) (x < y ? y : x)
#define MIN(x,y) (x < y ? x : y)

bool  Vision::upandrun = false;

#ifdef SANE
Vision::Vision()
{
  System::panic("Initialization of static class");
}
#endif

bool Vision::initialize(IniFile *config)
{

  upandrun = true;
  return true;
}

void Vision::finalize()
{
  upandrun = false;
}

unsigned int32 Vision::calcdir(unsigned int32 mousex, unsigned int32 mousey, unsigned int32 width, unsigned int32 height)
{
   int32 rx = (width  >> 1) - mousex;
   int32 ry = (height >> 1) - mousey;
   int32 ax = abs(rx);
   int32 ay = abs(ry);
   if (((ay >> 1) - ax) >= 0) {
     if (ry > 0) {
       return UP;
     } else {
       return DOWN;
     }
   } else if (((ax >> 1) - ay) >= 0) {
     if (rx > 0) {
       return LEFT;
     } else {
       return RIGHT;
     }
   } else if ((rx >= 0) && (ry >= 0)) { 
     return WEST;
   } else if ((rx >= 0) && (ry < 0)) { 
     return SOUTH;
   } else if ((rx < 0) && (ry < 0)) { 
     return EAST;
   } else {
     return NORTH;
   }
}

int32 Vision::run()
{
  int32 scroll = 0;
  int32 x = 0;
  //Sprite *sp = artReader.readMapSprite(0x3FF0);
  //front->drawSprite(-10, -10, sp);
  bool leftdown = false;
  bool rightdown = false;
  bool leftclick = false;
  bool rightclick = false;
  unsigned int32 mousex = 0;
  unsigned int32 mousey = 0;
  int32 dir = 0;
  
  time_t start, now;
  time(&start);
  unsigned int32 frame = 0;
  unsigned int32 cycle = 0;

  int32 w = Display::width();
  int32 h = Display::height();

    
  //malloc(10, "TEST");
  for(;;) {
    frame++;
    cycle++;
    SDL_Event event;    
    SDL_PollEvent(&event);

    switch (event.type) {
        case SDL_KEYDOWN:
            if (event.key.keysym.scancode != 1) {
              // Quit on ESC
              break;
            }
            // !!! FALL_THROUGH !!!
        case SDL_QUIT:
            return 0;
            break;
        case SDL_MOUSEBUTTONDOWN :
            if (event.button.button == SDL_BUTTON_LEFT) {
               if (!leftdown) {
                 leftclick = true;
               }
              leftdown = true;
            }
            if (event.button.button == SDL_BUTTON_RIGHT) {
              if (!rightdown) {
                rightclick = true;
              }
              rightdown = true;
            }

            break;
        case SDL_MOUSEBUTTONUP :
            if (event.button.button == SDL_BUTTON_LEFT) {
              leftdown = false;
            }
            if (event.button.button == SDL_BUTTON_RIGHT) {
              rightdown = false;
            }
            break;
        case SDL_MOUSEMOTION:
            mousex = event.motion.x;
            mousey = event.motion.y;
            dir = calcdir(mousex, mousey, w, h);
  //          exit(0);
    }
    //box->scroll(8, 0);
    //front->lock();
    //front->scroll(8, 0);
    //front->unlock();
    //front->update();
    if (rightdown || leftdown) {
      World::walk_creature(0, dir);           
    }

    //System::sleep(1000);
    ScreenRenderer::draw();

    time(&now);

    double elapsed_time = difftime(now, start );
    if (elapsed_time > 5) {
      Console::printf("+ frames/sec: %2.1f", (frame / elapsed_time));
      frame = 0;
      time(&start);
    } 
    if ((cycle & 0x7) == 0) {
      System::cycle();
      if ((cycle & 0xFF) == 0) {
        //Console::printf("Position: %d/%d/%d", creatures[curx, Vision::cury, Vision::curz);
      }
    }
    leftclick = false;
    rightclick = false;
  }
  // never recached
}