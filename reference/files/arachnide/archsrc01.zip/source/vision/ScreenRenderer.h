//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  ScreenRenderer.h
//
//  Renders the ingame UO-Screens.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __SCREEN_RENDERER_H__
#define __SCREEN_RENDERER_H__

class Box;
class IniFile;
class Fracture;
class Map;
class MapCell;
class MapFission;
class ObjectMan;
class Sprite;
class VRect;

class ScreenRenderer  {
  private :
    static Box *front;
    static Box *back;
    static MapFission *mapFission;

    static int32 xTiles; // how many horizontal tiles to draw
    static int32 yTiles; // how many vertical   tiles to draw

    static int32 shiftx; // screen shifting (centeralize player)
    static int32 shifty; // screen shifting (centeralize player)

    static int32 scrollx; // current scroll position
    static int32 scrolly; // current scroll position

    static unsigned int32 width;
    static unsigned int32 height;
    
    static bool fullbuffer_rendering;

    static int32 last_orgx;
    static int32 last_orgy;

    static bool blanking;   // Erase screen between the frames.
    static Fracture **fracts; //  Fracture pool
    static unsigned int32 fpoolsize;

    static void enlarge_fract_pool(unsigned int32 newsize);
    static inline void draw_fracture(unsigned int32 *nfrac, unsigned int32 fracc, int32 screenx, int32 screeny, VRect *rect, unsigned int32 irec, bool *regard_frac);

  public :
    static bool initialize(IniFile *config);
    static void finalize();
    static bool upandrun;

    static void draw();

#ifdef SANE
    ScreenRenderer(); // Panic if initialized (static class maynot be instanced)
#endif
};

#endif