//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Vision.cpp
//
//  Renders the ingame UO-Screens.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string.h>
#include "../Sdl/SDL.h"
#include "../config.h"
#include "../memguard.h"

#include "Fracture.h"
#include "ScreenRenderer.h"
#include "VRect.h"
#include "../display/Box.h"
#include "../display/Display.h"
#include "../display/Sprite.h"
#include "../fission/AnimFission.h"
#include "../fission/MapFission.h"
#include "../fission/WorldFission.h"
#include "../fission/TiledataFission.h"
#include "../map/MapCell.h"
#include "../map/StaticCell.h"
#include "../map/Tiledata.h"
#include "../mulreader/MAnimReader.h"
#include "../objects/ObjectMan.h"
#include "../skin/AnimSprite.h"
#include "../system/system.h"
#include "../util/IniFile.h"
#include "../world/Creature.h"
#include "../world/World.h"
#include "../world/WorldCell.h"

#include "../skin/AnimGroup.h"

#define BLANK 0x14

#define MAX(x,y) (x < y ? y : x)
#define MIN(x,y) (x < y ? x : y)

// Static variables
bool           ScreenRenderer::upandrun = false;
Box *          ScreenRenderer::front;
Box *          ScreenRenderer::back;
MapFission *   ScreenRenderer::mapFission;
int32          ScreenRenderer::xTiles;
int32          ScreenRenderer::yTiles;
int32          ScreenRenderer::shiftx;
int32          ScreenRenderer::shifty;
int32          ScreenRenderer::scrollx;
int32          ScreenRenderer::scrolly;
unsigned int32 ScreenRenderer::width;
unsigned int32 ScreenRenderer::height;
bool           ScreenRenderer::fullbuffer_rendering;
int32          ScreenRenderer::last_orgx;
int32          ScreenRenderer::last_orgy;
bool           ScreenRenderer::blanking; 
Fracture **    ScreenRenderer::fracts; //  Fracture pool
unsigned int32 ScreenRenderer::fpoolsize;


#ifdef SANE
ScreenRenderer::ScreenRenderer()
{
  System::panic("Initialization of static class");
}
#endif

bool ScreenRenderer::initialize(IniFile *config)
{
  shiftx = -15;
  shifty =  +2;

  scrollx = 0;
  scrolly = 0;

  front  = Display::masterbox;
  back   = new Box(Box::CLONE, front->screen);
  xTiles = front->width() / 44 +  5;           // how many horizontal tiles to draw
  yTiles = front->height() / 44 + 13;          // how many vertical   tiles to draw
  blanking             = config->getBoolean("BLANKING",   false);
  fullbuffer_rendering = config->getBoolean("FULL BUFFER RENDERING", false);


  width  = front->width();
  height = front->height();
  mapFission = new MapFission();

  last_orgx = 0xffffffff;
  last_orgy = 0xffffffff;

  fpoolsize = FRACT_POOL_START;
  fracts = (Fracture **) malloc(fpoolsize * sizeof(Fracture *), "Vision.fracts");
  for (unsigned int32 i = 0; i < fpoolsize; i++) {
    fracts[i] = new Fracture;
  }  
  upandrun = true;
  return true;
}

void ScreenRenderer::enlarge_fract_pool(unsigned int32 newsize)
{
  unsigned int32 oldsize = fpoolsize;
#ifdef SANE
  if (newsize <= oldsize) {
    System::panic("Illegal Vision::enlargePool() call");
  }
#endif
  fracts = (Fracture **) realloc(fracts, fpoolsize * sizeof(Fracture *));
  for (unsigned int32 i = oldsize; i < newsize; i++) {
    fracts[i] = new Fracture;
  }
  fpoolsize = newsize;
}

void ScreenRenderer::finalize()
{
  delete mapFission;
  delete back;
  for(unsigned int32 i = 0; i < fpoolsize; i++) {
    delete fracts[i];
  }
  delete fracts;
  upandrun = false;
}

unsigned int32 frame = 0;

inline void ScreenRenderer::draw_fracture(unsigned int32 *nfrac, unsigned int32 fracc, int32 screenx, int32 screeny, VRect *rect, unsigned int32 irec, bool *regard_frac) 
{
  AnimSprite *fsprite = fracts[*nfrac]->sprite;
  int32 drawx = screenx - fsprite->offsetx;
  int32 drawy = screeny - fsprite->height - (fracts[*nfrac]->z << 2) - fsprite->offsety;
  for(unsigned int32 j = 0; j < irec; j++) {
    VRect *r = &rect[j];
    if (INTERRECT(r, drawx, drawy, (int32) fsprite->width, (int32) fsprite->height)) {
      front->drawSprite(drawx, drawy, fsprite, r->l, r->u, r->r, r->d);
    }
  }
  *nfrac++;
  if (*nfrac >= fracc) {
    *regard_frac = false;
  } else {
    if (!((fracts[*nfrac - 1]->x == fracts[*nfrac]->x) && 
          (fracts[*nfrac - 1]->y == fracts[*nfrac]->y))) {
      *regard_frac = false;
    }
  }                
}

void ScreenRenderer::draw()
{
  front->lock();
  int32 curx = World::creatures[0]->x;
  int32 cury = World::creatures[0]->y;
  int32 curz = World::creatures[0]->z;

  unsigned int32 fracc = 1; // fracture count
  unsigned int32 nfrac = 0; // next fracture in queue
  unsigned int32 body = World::creatures[0]->body;
  if (++frame == 10) {
    frame = 0;
  }
  AnimSprite *player_sprite = AnimFission::getFrame(body, AnimFission::RUN, World::creatures[0]->dir, frame);
  fracts[0]->sprite = player_sprite;
  fracts[0]->x      = curx;
  fracts[0]->y      = cury;
  fracts[0]->z      = curz;

  int32 orgx = (curx - cury) * 22 + scrollx + (shiftx - shifty) * 22 + 88;  // screen coordinates X-offset for everything
  int32 orgy = (curx + cury) * 22 + scrolly + (shiftx + shifty) * 22 + 88 - (curz << 2);  // screen coordinates Y-offset for everything         

  VRect rect[4];
  unsigned int32 irec = 0;
  bool fullscreen;
  int32 difx = 0;
  int32 dify = 0;
  if ((last_orgx == 0xffffffff) || fullbuffer_rendering) {
    fullscreen = true;
    irec = 1;
    rect[0].l = 0;
    rect[0].r = width - 1;
    rect[0].u = 0;
    rect[0].d = height - 1;
  } else {
    difx = orgx - last_orgx;
    dify = orgy - last_orgy;
    if (difx < 0) {
      rect[0].u = 0;
      rect[0].l = 0;
      rect[0].r = -difx;
      rect[0].d = height - 1;      
      irec++;
    } else if (difx > 0) {
      rect[0].u = 0;
      rect[0].l = width - 1 - difx;
      rect[0].r = width - 1;
      rect[0].d = height - 1;
      irec++;
    } 
    if (dify < 0) {
      rect[irec].u = 0;
      rect[irec].l = 0;
      rect[irec].r = width - 1;
      rect[irec].d = -dify;
      irec++;
    } else if (dify > 0) {
      rect[irec].u = height - 1 - dify;
      rect[irec].l = 0;
      rect[irec].r = width - 1;
      rect[irec].d = height - 1;
      irec++;
    } 
    fullscreen = false;
    front->scroll(difx, dify);
  }  
  bool do_blanking = blanking; // localize variable
  // turn on blanking if reaching the map borders.
  int32 blankx = curx + shiftx;
  int32 blanky = cury + shifty;
  if (((blankx - 2) < xTiles) || ((blanky - 2) < yTiles) ||
      ((blankx + 10 + xTiles) >= 768 * 8) || ((blanky + 10 + yTiles) >= 512 * 8)) {
    // turn on blanking if reaching the map borders.
    do_blanking = true;
  }

  if (do_blanking) {
    if (fullscreen) {
      memset(front->screen->pixels, BLANK, front->screen->h * front->screen->pitch);
    } else {
      unsigned int32 pitch = front->screen->pitch;
      byte *pixels = (byte *) front->screen->pixels;
      for (unsigned int32 i = 0; i < irec; i++) {
        VRect *r = &rect[i];
        unsigned int32 u = r->u;
        unsigned int32 l2 = (r->l) << 1;
        unsigned int32 d = r->d;
        unsigned int32 w2 = (r->r - r->l) << 1;
        for (unsigned int32 y = u; y < d; y++) {
          memset(pixels + y * pitch + l2, BLANK, w2);
        }
      }
    }
  }

  // fill in clipping rectangles for creatures;
  // Do it still if in fullscreen mode!
  //   we'll need the last-frame information if leaving fullscreen mode.
  Creature *creature = World::creatures[0];
  int32 screenx = (curx - cury) * 22 - orgx;            
  int32 screeny = (curx + cury) * 22 - orgy - (curz << 2);
  int32 clip_u = screeny - player_sprite->height - player_sprite->offsety;
  int32 clip_l = screenx - player_sprite->offsetx;
  int32 clip_r = screenx + player_sprite->width  - player_sprite->offsetx;
  int32 clip_d = screeny - player_sprite->offsety;
  bool cancel_clip = false;
  if (creature->hasclip) {
    register int32 t;
    rect[irec].u = ((t = MIN(clip_u, creature->lastclip.u - dify)) < 0               ) ? 0          : t;
    rect[irec].l = ((t = MIN(clip_l, creature->lastclip.l - difx)) < 0               ) ? 0          : t;
    rect[irec].r = ((t = MAX(clip_r, creature->lastclip.r - difx)) >= (signed) width ) ? width  - 1 : t;
    rect[irec].d = ((t = MAX(clip_d, creature->lastclip.d - dify)) >= (signed) height) ? height - 1 : t;
    if ((rect[irec].u >= (signed) height)  || 
        (rect[irec].r <  0) || 
        (rect[irec].l >= (signed) width) || 
        (rect[irec].d < 0)) {
      cancel_clip = true;
      // remove clip if it calculates completly offscreen.
    }
  } else {
    register int32 t;
    rect[irec].u = ((t = clip_u) < 0) ? 0 : t;
    rect[irec].l = ((t = clip_l) < 0) ? 0 : t;
    rect[irec].r = ((t = clip_r) >= (signed) width ) ? width  - 1 : t;
    rect[irec].d = ((t = clip_d) >= (signed) height) ? height - 1 : t;
  }
    
  if (!cancel_clip) {
    creature->lastclip.u = clip_u;
    creature->lastclip.l = clip_l;
    creature->lastclip.r = clip_r;
    creature->lastclip.d = clip_d;
    creature->hasclip = true;
    irec++;
  }

  int32 hshift = - curz / 11;
  for (int32 y = hshift - 2; y < hshift + yTiles; y++) {                 // draw from top to bottom
    for (int32 odd = 0; odd <=1; odd++) {                       // then draw the 0.5 shifted cells
      int32 tilex = curx + y + odd + shiftx;                    // valculate current x tile to draw
      int32 tiley = cury + y + shifty;                          // calculate x position of tile 
      for (int32 x = 0; x < xTiles; x++) {    	              // draw from left to right
        int32 screenx = (tilex - tiley) * 22 - orgx;            // calculate x-cooridinate of tile on screen
        int32 screeny = (tilex + tiley) * 22 - orgy;// + curz;     // calculate y-cooridinate of tile on screen
        WorldCell *cell = WorldFission::getCell(tilex , tiley);
        if (cell != NULL) {
          bool regard_frac = false;
          if (nfrac < fracc) {
            if ((tilex == fracts[nfrac]->x) && (tiley == fracts[nfrac]->y)) {
              regard_frac = true;
            }
          }
          for(unsigned int32 i = 0; cell[i].type != 0; i++) {
            if (regard_frac) {
              if (cell[i].z > fracts[nfrac]->z) {
                draw_fracture(&nfrac, fracc, screenx, screeny, rect, irec, &regard_frac);
              }
            }
            Sprite *sprite;        
            int32 drawx;
            int32 drawy;
            switch (cell[i].type) {
              case World::MAP_CELL :
                {
                  MapCell *cell = mapFission->getCell(tilex, tiley, true);
                  drawx = screenx;
                  drawy = screeny - (((int32) cell->z) << 2);
                  mapFission->release();
                  //if (cell->stretched) {
                  Tiledata * tiledata = TiledataFission::get_map_tiledata(cell->id);
                  if (tiledata->flags & FLAG_WATER) {
                    // To not stretch wet tiles.
                    sprite = ObjectMan::get_map_sprite(cell->id);
                  } else {
                    sprite = ObjectMan::get_stretch_sprite(cell, tilex, tiley);
                  }
                  TiledataFission::release();
                  //} else {
                  //  sprite = ObjectMan::getMapSprite(cell->id);
                  //}
                  break;
                }
              case World::STATIC_CELL :
                {
                  sprite = ObjectMan::get_static_sprite(cell[i].id);
                  drawx = screenx - (sprite->width >> 1) + 22;
                  drawy = screeny - (cell[i].z << 2) - sprite->height + 44;
                  break;
                }
              case World::SKIP_CELL :
                {
                  continue;
                }
              default :
                  System::panic("Vision::draw, invalid world cell");
            }
            for(unsigned int32 j = 0; j < irec; j++) {
              VRect *r = &rect[j];
              if (INTERRECT(r, drawx, drawy, (int32) sprite->width, (int32) sprite->height)) {
              // if ((tilex != curx) && (tiley != cury)) // (uncomment for debug-center-cross)
                front->drawSprite(drawx, drawy ,sprite, r->l, r->u, r->r, r->d);
              }
            }
            sprite->release();
          }
          while (regard_frac) {
            Sprite *fsprite = fracts[nfrac]->sprite;
            draw_fracture(&nfrac, fracc, screenx, screeny, rect, irec, &regard_frac);
          }
          WorldFission::release();
        }         
        tilex++; 
        tiley--; 
      }
    }
  }

  //front->drawSprite(10, 10, sprite);
  AnimFission::release();

  //AnimGroup *anim = MAnimReader::readAnimGroup(0x190 * 110);
  //front->drawSprite(100, 100, anim->frames[0]);

  last_orgx = orgx;
  last_orgy = orgy;

  front->unlock();
  front->update();
  //curx++;
  //cury--;
}

