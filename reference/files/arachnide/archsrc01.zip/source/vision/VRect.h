//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Rect.h
//
//  The rectangle class and interect stuff.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __RECT_H__
#define __RECT_H__

// Intersect says if rectangale 1 (x,y,width, height) intersects with rectangale 2 (x,y,width, height)
#define INTERSECT(x1, y1, w1, h1, x2, y2, w2, h2) (\
                 (((x1 <= x2) && (x1 + w1 >= x2)) || ((x2 <= x1) && (x2 + w2 >= x1))) &&\
                 (((y1 <= y2) && (y1 + h1 >= y2)) || ((y2 <= y1) && (y2 + h2 >= y1))) \
                 )

// same as above but with a first rect of the RECT call
#define INTERRECT(r, x1, y1, w1, h1) (\
                 (((r->l <= x1) && (r->r >= x1)) || ((x1 <= r->l) && (x1 + w1 >= r->l))) &&\
                 (((r->u <= y1) && (r->d >= y1)) || ((y1 <= r->u) && (y1 + h1 >= r->u))) \
                 )

class VRect {
public :
  int32 l;
  int32 u;
  int32 r;
  int32 d;
};

#endif