//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Cache.h
//
//  Handles the cache. Keeps track of the objects in a chain list sorted from
//  oldest object to newest, but it also uses a hashtable to signifcantly speed up 
//  lookups
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __CACHE_H__
#define __CACHE_H__

class Object;
class HugeHashtable;
class IniFile;

#define SPRITE_MAP       1
#define SPRITE_SOT       2     // SOT -> Stretch-o-tilted
#define SPRITE_STATIC    3
#define MAPBLOCK         4 
#define STATICBLOCK      5
#define WORLDBLOCK       6
#define TILEDATA_MAP     7
#define TILEDATA_STATIC  8
#define ANIMGROUP        9
#define GUMP            10

// parmanent stuff
#define FONTSET        129

class Cache {
  private :
    static Object *oldest;
    static Object *newest;
    static HugeHashtable *hash;
    static unsigned int32 count;
    static unsigned int32 max_count;
    static void delete_oldest();

  public :
    static bool initialize(IniFile *config);
    static void finalize();   
    static bool upandrun;
    
    static void enrol(Object *object, unsigned int8 group, unsigned int32 ext, unsigned int32 id);
    static Object *aquire(unsigned int8 group, unsigned int32 ext, unsigned int32 id);

#ifdef SANE
    Cache(); // Panic if initialized (static class maynot be instanced)
#endif
};

#endif