�"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~�
  /objects
�"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~�

Primary handles caching of tile.

~ Object is a general purpose basic class of all chachable items.
~ ObjectMan is the interface all other subsytem aquire their data from.
~ Cache manages a Hashtable of all items, and keeps it to a finite memory usage.
  (continously deletest the oldest item)

�"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~�
