//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  ObjecMan.cpp
//
//  Object manager, all other parts of the system have to aquire their
//  object through this managar. It uses the cache to save them in memory.
//
// 
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __OBJECT_MAN_H__
#define __OBJECT_MAN_H__

class AnimGroup;
class Cache;
class Fontset;
class IniFile;
class MArtReader;
class MTiledataReader;
class Sprite;
class StaticBlock;
class MapBlock;
class MapCell;
class WorldBlock;
class TiledataGroup;

class ObjectMan {
  private :
    static Cache  *cache;
    static Fontset *fontsets[MAX_FONT_SETS];
    static unsigned int32 fcount; // counts the fontset read, since they have to be read in a serie

  public :
    static bool initialize(IniFile *config);
    static void finalize();
    static bool upandrun;

    static unsigned int16 hues[MAX_HUES][32];

    static Sprite *        get_map_sprite(unsigned int32 id);
    static Sprite *        get_stretch_sprite(MapCell *cellSprite, unsigned int32 x, unsigned int32 y);
    static Sprite *        get_static_sprite(unsigned int32 id);
    static Sprite *        get_font_sprite(unsigned int32 set,unsigned byte ch);
    static Sprite *        get_gump(unsigned int32 id);
    static MapBlock *      get_map_block(unsigned int32 id);
    static StaticBlock *   get_static_block(unsigned int32 id);
    static WorldBlock *    get_world_block(unsigned int32 id);
    static TiledataGroup * get_static_tiledata_group(unsigned int32 id);
    static TiledataGroup * get_map_tiledata_group(unsigned int32 id);
    static AnimGroup *     get_anim_group(unsigned int32 id);

#ifdef SANE
    ObjectMan(); // Panic if initialized (static class maynot be instanced)
#endif
};

#endif