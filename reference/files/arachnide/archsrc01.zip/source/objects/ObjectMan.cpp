//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  ObjecMan.cpp
//
//  Object manager, all other parts of the system have to aquire their
//  object through this managar. It uses the cache to save them in memory.
//
//  Object       ~    Aquire possibilities
//  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//  Sprite       ~    getMapSprite
// 
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string.h>
#include "../config.h"
#include "../memguard.h"

#include "Cache.h"
#include "ObjectMan.h"
#include "../display/Sprite.h"
#include "../graphics/Flipper.h"
#include "../graphics/Stretch.h"
#include "../map/Mapblock.h"
#include "../map/Staticblock.h"
#include "../map/TiledataGroup.h"
#include "../mulreader/MMapReader.h"
#include "../mulreader/MStaticReader.h"
#include "../mulreader/MTiledataReader.h"
#include "../mulreader/MArtReader.h"
#include "../mulreader/MAnimReader.h"
#include "../mulreader/MFontReader.h"
#include "../mulreader/MGumpReader.h"
#include "../skin/AnimGroup.h"
#include "../skin/FontSet.h"
#include "../system/system.h"
#include "../world/Worldblock.h"
#include "../world/World.h"

bool ObjectMan::upandrun = false;
Fontset *ObjectMan::fontsets[MAX_FONT_SETS];
unsigned int32 ObjectMan::fcount = 0;

#ifdef SANE
// Panic of initialization (static class maynot be instanced)
ObjectMan::ObjectMan()
{
  System::panic("Initialization of static class");
}
#endif


bool ObjectMan::initialize(IniFile *config)
{
  for(unsigned int32 i = 0; i < MAX_FONT_SETS; i++) {
    fontsets[i] = NULL;  
  }
  fcount = 0;
  upandrun = true;
  return true;
}

void ObjectMan::finalize()
{
  for(unsigned int32 i = 0; i < MAX_FONT_SETS; i++) {
    if (fontsets[i] != NULL) {
      delete fontsets[i];
    }
  }

  upandrun = false;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ObjectMan::getMapSprite
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
Sprite * ObjectMan::get_map_sprite(unsigned int32 id)
{
  Sprite *sprite = (Sprite *) Cache::aquire(SPRITE_MAP, 0, id);
  if (sprite != NULL) {
    sprite->lock();
    return sprite;
  }
  sprite = MArtReader::readMapSprite(id);
  sprite->_lock = 1;

  Cache::enrol(sprite, SPRITE_MAP, 0, id);
  return sprite;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ObjectMan::get_stretch_sprite
//
// Aquire a stretch-o-tilted map sprite.
// These tiles are cached by the coordinates, so an id, stretched in exactly the
// same manner will be evaluated twice. However detecting and chaching such 
// situations is much more processor effort than simply calculate and store twice.
// (it are 5 long int's identifing a SOT Sprite)
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
Sprite  *ObjectMan::get_stretch_sprite(MapCell *cell, unsigned int32 x, unsigned int32 y)
{
#ifdef SANE
  //if (!cell->stretched) {
  //  System::panic("ObjectMan::getSotSprite() called for unstretched tile.");
  //}
#endif  
 
  unsigned int32 key1 = x;
  unsigned int32 key2 = y;

  Sprite *sprite = (Sprite *) Cache::aquire(SPRITE_SOT, key1, key2);
  if (sprite != NULL) {
    sprite->lock();
    return sprite;
  }
  sprite = Stretch::stretch(cell, x , y); 
  sprite->_lock = 1;
  Cache::enrol(sprite, SPRITE_SOT, key1, key2);
  return sprite;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ObjectMan::getStaticSprite
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
Sprite * ObjectMan::get_static_sprite(unsigned int32 id)
{
  Sprite *sprite = (Sprite *) Cache::aquire(SPRITE_STATIC, 0, id);
  if (sprite != NULL) {
    sprite->lock();
    return sprite;
  }
  sprite = MArtReader::readStaticSprite(id);
  sprite->_lock = 1;

  Cache::enrol(sprite, SPRITE_STATIC, 0, id);
  return sprite;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ObjectMan::get_map_block
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
MapBlock * ObjectMan::get_map_block(unsigned int32 id)
{
  MapBlock *mapblock = (MapBlock *) Cache::aquire(MAPBLOCK, 0, id);
  if (mapblock != NULL) {
    mapblock->lock();
    return mapblock;
  }
  mapblock = MMapReader::readMapBlock(id);
  mapblock->_lock = 1;
  Cache::enrol(mapblock, MAPBLOCK, 0, id);
  return mapblock;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ObjectMan::get_static_block
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
StaticBlock * ObjectMan::get_static_block(unsigned int32 id)
{
  StaticBlock *staticblock = (StaticBlock *) Cache::aquire(STATICBLOCK, 0, id);
  if (staticblock != NULL) {
    staticblock->lock();
    return staticblock;
  }
  staticblock = MStaticReader::readStaticBlock(id);
  staticblock->_lock = 1;
  Cache::enrol(staticblock, STATICBLOCK, 0, id);
  return staticblock;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ObjectMan::get_world_block
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
WorldBlock * ObjectMan::get_world_block(unsigned int32 id)
{
  WorldBlock *wblock = (WorldBlock *) Cache::aquire(WORLDBLOCK, 0, id);
  if (wblock != NULL) {
    wblock->lock();
    return wblock;
  }
  wblock = World::createWorldBlock(id);
  wblock->_lock = 1;
  Cache::enrol(wblock, WORLDBLOCK, 0, id);
  return wblock;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ObjectMan::get_static_tiledata_group
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
TiledataGroup *ObjectMan::get_static_tiledata_group(unsigned int32 id)
{
  TiledataGroup *group = (TiledataGroup *) Cache::aquire(TILEDATA_STATIC, 0, id);
  if (group != NULL) {
    group->lock();
    return group;
  }
  group = MTiledataReader::read_static_tiledata(id);
  group->_lock = 1;
  Cache::enrol(group, TILEDATA_STATIC, 0, id);
  return group;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ObjectMan::get_map_tiledata_group
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
TiledataGroup *ObjectMan::get_map_tiledata_group(unsigned int32 id)
{
  TiledataGroup *group = (TiledataGroup *) Cache::aquire(TILEDATA_MAP, 0, id);
  if (group != NULL) {
    group->lock();
    return group;
  }
  group = MTiledataReader::read_map_tiledata(id);
  group->_lock = 1;
  Cache::enrol(group, TILEDATA_MAP, 0, id);
  return group;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ObjectMan::get_anim_group
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
AnimGroup* ObjectMan::get_anim_group(unsigned int32 id)
{
  AnimGroup *group = (AnimGroup *) Cache::aquire(ANIMGROUP, 0, id);
  if (group != NULL) {
    group->lock();
    return group;
  }
  if (id & 0x80000000) {
    // it's a flipped tile
    group = get_anim_group(id & 0x7fffffff);
    AnimGroup *ngroup = Flipper::fliphorz_group(group);
    group->release();
    ngroup->_lock = 1;
    Cache::enrol(ngroup, ANIMGROUP, 0, id);
    return ngroup;
  } else {
    group = MAnimReader::readAnimGroup(id);
    group->_lock = 1;
    Cache::enrol(group, ANIMGROUP, 0, id);
    group = (AnimGroup *) Cache::aquire(ANIMGROUP, 0, id);
    return group;
  }
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ObjectMan::get_font_sprite
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
Sprite * ObjectMan::get_font_sprite(unsigned int32 set,unsigned byte ch)
{
  Fontset *fset = fontsets[set];
  if (fset == NULL) {
    while (fcount <= set) {
      fset = MFontReader::readFontset(set);
      fontsets[fcount] = fset;
      fcount++;
    }
  }
  return fset->characters[ch];
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ObjectMan::get_gump
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
Sprite * ObjectMan::get_gump(unsigned int32 id)
{
  Sprite *sprite = (Sprite *) Cache::aquire(GUMP, 0, id);
  if (sprite != NULL) {
    sprite->lock();
    return sprite;
  }
  sprite = MGumpReader::read_gump(id);
  if (sprite == NULL) {
    return NULL;
  }
  sprite->_lock = 1;

  Cache::enrol(sprite, GUMP, 0, id);
  return sprite;
}
