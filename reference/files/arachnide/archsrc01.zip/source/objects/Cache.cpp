//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Cache.h
//
//  Handles the cache. Keeps track of the objects in a chain list sorted from
//  oldest object to newest, but it also uses a hashtable to signifcantly speed up 
//  lookups.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <stdlib.h>
#include <string>
#include "../config.h"
#include "../memguard.h"

#include "../display/Sprite.h"
#include "../map/MapBlock.h"
#include "../map/StaticBlock.h"
#include "../map/TiledataGroup.h"
#include "../skin/AnimGroup.h"
#include "../system/system.h"
#include "../util/HugeHashtable.h"
#include "../util/IniFile.h"
#include "../world/WorldBlock.h"
#include "Cache.h"
#include "Object.h"

// static stuff needed by compiler
bool            Cache::upandrun = false;
Object *        Cache::oldest = NULL;
Object *        Cache::newest = NULL;
HugeHashtable * Cache::hash = NULL;
unsigned int32  Cache::count = 0;
unsigned int32  Cache::max_count = 0;


#ifdef SANE
// Panic of initialization (static class maynot be instanced)
Cache::Cache()
{
  System::panic("Initialization of static class");
}
#endif

bool Cache::initialize(IniFile *config)
{
  max_count = config->getInteger("CACHE", 4000);
  hash = new HugeHashtable();
  oldest = NULL;
  newest = NULL;
  count  = 0;
  upandrun = true;
  return true;
}

void Cache::finalize()
{
  while (count > 0) {
    if (oldest->_lock != 0) {
      System::panic("Cache locked while shutdown");
    }
    if (count == 2) {
      count = count;
    }
    delete_oldest();
  }
  delete hash;
  upandrun = false;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Cache::enrol
//
// register an object in the cache. 
// (too bad the word 'register' is already taken by c)
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void Cache::enrol(Object *object, unsigned int8 group, unsigned int32 ext, unsigned int32 id)
{
#ifdef SANE
  if (ext & 0xFF000000) {
    System::panic("Invalid id-key in chache");
  }
  if (object == NULL) {
    System::panic("Putting NULL object into hashtable.");
  }
#endif
  hash->put((((unsigned int32) group) << 24) | ext, id, object);
  // append to the chain list 
  if (newest == NULL) {
    // chain list is empty
    newest = object;
    oldest = object;
    object->older = NULL;
  } else {
    // chain list not emty
    newest->newer = object;
    object->older = newest;
    newest = object;
  }
  object->newer = NULL;
  
  count++;
  /*
#ifdef DEBUG_CACHE
{
  if ((count % 100) == 0) {
    Console::printf("D Cache: reached %d objects." , buf);
  }
}
#endif
*/
  if (count >= max_count) {
    delete_oldest();
  }
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Cache::aquire
//
// gets an object out of chache.
//
// returns NULL if the object is not in cache, if it is in cache it moves
// it's possition to newest.
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
Object *Cache::aquire(unsigned int8 group, unsigned int32 ext, unsigned int32 id)
{
  if (ext & 0xFF000000) {
    System::panic("Invalid id-key in chache");
  }
  Object *object = (Object *) hash->get((((unsigned int32) group) << 24) | ext, id);
  if (object == NULL) {
    return NULL;
  }
  // move the object on top of the list
  if (object == newest) {
    // already newest nothing to do
    return object;
  }
  if (object->older == NULL) {
#ifdef SANE
    if (object != oldest) {
      System::panic("Chainlist broken");
    }
#endif
    // this is the oldest entry
    if (object->newer == NULL) {
      // this is the only entry -> nothing to do
      return object;
    }
    oldest = object->newer;
    oldest->older = NULL;
    newest->newer = object;
    object->older = newest;
  } else {
    // this is a entry in the list
    object->older->newer = object->newer;
    object->newer->older = object->older;
    newest->newer = object;
    object->older = newest;
  }
  object->newer = NULL;
  newest = object;
  return object;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Cache::delete_oldest
//
// delete oldest if not used object.
//
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void Cache::delete_oldest()
{
  do {
    if (oldest->_lock != 0) {
      return;
    }
    Object *obj = oldest;
    oldest = oldest->newer;
    hash->remove(obj);
    if (oldest != NULL) {
      oldest->older = NULL;
    }
    switch (obj->type) {
      case SPRITE_MAP :
      case SPRITE_SOT :
      case SPRITE_STATIC :
          delete ((Sprite *) obj);
          break;
      case MAPBLOCK:
          delete ((MapBlock *) obj);
          break;
      case STATICBLOCK:
          delete ((StaticBlock *) obj);
          break;
      case WORLDBLOCK:
          delete ((WorldBlock *) obj);
          break;
      case TILEDATA_MAP:
      case TILEDATA_STATIC:
          delete ((TiledataGroup *) obj);
          break;
      case ANIMGROUP:
          delete ((AnimGroup *) obj);
          break;
      default :
          System::panic("Cache::delete_oldest() unkown object");
    }
    count--;
  } while (count >= max_count);
}
