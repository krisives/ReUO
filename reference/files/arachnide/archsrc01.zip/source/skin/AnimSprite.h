//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  AnimSprite.h
//
//  A normal sprite with offset extentions.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __ANIM_SPRITE_H__
#define __ANIM_SPRITE_H__

#include "../display/Sprite.h"


class AnimSprite : public Sprite {
  public :
    signed int32 offsetx;
    signed int32 offsety;
    AnimSprite(unsigned int32 width, unsigned int32 height);
    //~AnimSprite();
};

#endif