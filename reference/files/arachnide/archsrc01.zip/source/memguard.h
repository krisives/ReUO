//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// memguard.h
//
// This one `guards� memory, tracking of all allocated and freed memory
// if enabled. This is very, very usefull to track down memory leaks.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#ifndef __MEM_GUARD_H__
#define __MEM_GUARD_H__

#ifndef __CONFIG_H__
#error  wrong include sequence (config.h needed first)!
#endif

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Mem-guard level
//
// 0 ... memory guard disabled
// 1 ... count allocs/frees
// 2 ... track memory
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
#if MEM_GUARD_LEVEL == 0
  // no guarding
#  define  malloc(s,name)      malloc(s)
#  define  new(x)              new 

#elif MEM_GUARD_LEVEL==1
   // count memory allocs
   extern long alloc_count;
#  define  malloc(s,name)      malloc(s);alloc_count++
#  define  free(x)             free(x);alloc_count--
#  define  realloc(p,s)        realloc(p,s)
#  define  new(x)              new 

#elif MEM_GUARD_LEVEL==2
   void *operator new(size_t size);
   void operator delete(void *mem);
   void *operator new(size_t size, byte *text);
   void operator delete(void *mem, byte *text);
   #define  malloc(s,name)      gmalloc(s,name)
   #define  free(x)             gfree(x)
   #define  realloc(p,s)        grealloc(p,s)
   // keep track on memry
   
   extern void *gmalloc(size_t size, byte *name);
   extern void gfree(void *memblock);
   extern void showMemory();

   extern void *memmark(void *point, byte *name);
   extern void  memunmark(void *point);
   extern void *grealloc(void *memblock, size_t size);

#else 
# error invalid guard level specified.
#endif

#endif