�"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~�
  fission
�"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~�
The fission classes are responsible to take seperate the blocks into
their `cellular� parts. As almost all things are stored block wise in cache
to reduce overhead, most parts of the system want to handle single cells, parts
of information, without caring about the blocking. The fission classes provide
a convient cell based interface, witch a first level cache. (remember last block
accessed)

�"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~�


