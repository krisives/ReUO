//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  AnimFission.h
//
//  Calculates the animation id and graps the desired animation frame,
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __ANIM_FISSION_H__
#define __ANIM_FISSION_H__

// Type modifactators

class AnimSprite;
class AnimGroup;
class IniFile;

class AnimFission {
  private :
    static AnimGroup *front_cache;
    static unsigned int32 front_cache_id;

  public :
    static bool initialize(IniFile *config);
    static void finalize();
    static bool upandrun;

    static AnimSprite *getFrame(unsigned int32 creature, unsigned int32 type, unsigned int32 dir, unsigned int32 frame);
    static void release();

    enum {
      WALK     = 0,
      STAND    = 1,
      DIE1     = 2,
      ATTACK1  = 3,
      ATTACK2  = 5,
      ATTACK3  = 6,
      STUMBLE  = 10,
      MISC1    = 11,
      MISC2    = 12,
      GETHIT2  = 15,
      GETHIT3  = 16,
      FIDGET1  = 17,
      FIDGET2  = 18,
      RUN      = 19,
    };

#ifdef SANE
    static bool locked;
    AnimFission(); // Panic if initialized (static class maynot be instanced)
#endif
};


#endif