//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  AnimFission.cpp
//
//  Calculates the animation id and graps the desired animation frame,
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "AnimFission.h"
#include "../objects/ObjectMan.h"
#include "../skin/AnimGroup.h"
#include "../system/system.h"
#include "../util/IniFile.h"
#include "../world/World.h"

bool           AnimFission::upandrun = false;
AnimGroup *    AnimFission::front_cache;
unsigned int32 AnimFission::front_cache_id;

#ifdef SANE
AnimFission::AnimFission()
{
  System::panic("Initialization of static class");
}

bool AnimFission::locked;
#endif

bool AnimFission::initialize(IniFile *config)
{
  front_cache = NULL;
  front_cache_id = 0xffffffff;
  upandrun = true;
#ifdef SANE
  locked = false;
#endif
  return true;
}

void AnimFission::finalize()
{
  if (front_cache != NULL) {
    front_cache->release();
  }
  upandrun = false;
}

AnimSprite *AnimFission::getFrame(unsigned int32 creature, unsigned int32 type, unsigned int32 dir, unsigned int32 frame)
{
#ifdef SANE
  if (locked) {
    System::panic("Double lock in AnimFission");
  }
  locked = true;
#endif
  unsigned int32 id;
  if (creature < 0xc8) {
    id = creature * 110;
    switch (dir) {
      case UP    : id += 4; break;
      case NORTH : id += 3; id |= 0x80000000; break;
      case RIGHT : id += 2; id |= 0x80000000; break;
      case EAST  : id += 1; id |= 0x80000000; break;
      case DOWN  :          break;
      case SOUTH : id += 1; break;
      case LEFT  : id += 2; break;
      case WEST  : id += 3; break;
    }   
    id += type * 5;
  } else if (creature < 0x190) {
    id = (creature - 0xc8) * 65 + 22000;
    frame >>= 1;  // low detail creatures have half frame count
  } else {
    id = (creature - 0x190) * 175 + 35000;
    switch (dir) {
      case UP    : id += 4; break;
      case NORTH : id += 3; id |= 0x80000000; break;
      case RIGHT : id += 2; id |= 0x80000000; break;
      case EAST  : id += 1; id |= 0x80000000; break;
      case DOWN  :          break;
      case SOUTH : id += 1; break;
      case LEFT  : id += 2; break;
      case WEST  : id += 3; break;
    }   
    id += 0;
  }

  if (id == front_cache_id) {
    front_cache->lock();
    //return front_cache->frames[0];
    return front_cache->frames[frame];
  }
  if (front_cache != NULL) {
    front_cache->release();
  }
  AnimGroup *group = ObjectMan::get_anim_group(id);
  front_cache = group;
  front_cache_id = id;
  front_cache->lock();
  return group->frames[frame];
  //return group->frames[0];
}

void AnimFission::release()
{
#ifdef SANE  
  if ((front_cache == NULL) || (!locked)) {
    System::panic("Unlocked release in AnimFission");
  }
  locked = false;
#endif
  front_cache->release();
}