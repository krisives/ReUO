//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  WorldFission.cpp
//
//  Get world information per cell.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "WorldFission.h"
#include "../world/WorldCell.h"
#include "../world/WorldBlock.h"
#include "../objects/ObjectMan.h"
#include "../system/system.h"

#define MAX(x,y) (x < y ? y : x)
#define MIN(x,y) (x < y ? x : y)

WorldBlock  *  WorldFission::front_cache;
unsigned int32 WorldFission::front_cache_id;
bool           WorldFission::upandrun;


bool WorldFission::initialize(IniFile *config)
{
  front_cache_id = 0xFFFFFFFF;
  front_cache    = NULL;
  upandrun = true;
  return true;
}

void WorldFission::finalize()
{
  if (front_cache != NULL) {
    front_cache->release();
  }
  upandrun = false;
}

WorldCell *WorldFission::getCell(int32 cx, int32 cy)
{
  unsigned int32 bx = cx >> 3;
  unsigned int32 by = cy >> 3;

  if ((cx < 0) || (cy < 0) || (cx >= 768 * 8) || (cy >= 512 * 8)) {
    return NULL;
  }
  unsigned int32 id = (bx) * 512 + (by);
  if (id == front_cache_id) {
    front_cache->lock();
    return front_cache->cells[cx & 0x7][cy & 0x7];
  }
  if (front_cache != NULL) {
    front_cache->release();
  }

  WorldBlock *block = ObjectMan::get_world_block(id);
  
  front_cache = block;
  front_cache_id = id;
  front_cache->lock();
  return block->cells[cx & 0x7][cy & 0x7];
}


void WorldFission::release()
{
  if (front_cache != NULL) {
    front_cache->release();
  }
}