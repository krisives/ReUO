//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  MapFission.cpp
//
//  Interface to the map data (no block grouping)
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "MapFission.h"
#include "MapPrepare.h"
#include "../map/MapCell.h"
#include "../map/MapBlock.h"
#include "../objects/ObjectMan.h"
#include "../system/system.h"

#define MAX(x,y) (x < y ? y : x)
#define MIN(x,y) (x < y ? x : y)

MapFission::MapFission()
{
  front_cache_id = 0xFFFFFFFF;
  front_cache    = NULL;
}

MapFission::~MapFission()
{
}


MapCell *MapFission::getCell(int32 cx, int32 cy, bool prepare)
{
  unsigned int32 bx = cx >> 3;
  unsigned int32 by = cy >> 3;

  if ((cx < 0) || (cy < 0) || (cx >= 768 * 8) || (cy >= 512 * 8)) {
    return NULL;
  }

  unsigned int32 id = (bx) * 512 + (by);
  if (id == front_cache_id) {
    front_cache->lock();
    return &(front_cache->cells[cx & 0x7][cy & 0x7]);
  }

  MapBlock *block = ObjectMan::get_map_block(id);
  
  if ((prepare) && (!block->prepared)) {
    // prepare the block if it has been desired, and has not been done already
    // (calculate the stretch-o-tilt paramters)
    MapPrepare::prepare(id, block);
  }
 
  front_cache = block;
  front_cache_id = id;
  return &block->cells[cx & 0x7][cy & 0x7];
}


void MapFission::release()
{
  if (front_cache != NULL) {
    front_cache->release();
  }
}