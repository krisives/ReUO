//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Map.cpp
//
//  Interface to the map data (no block grouping)
//  Calculation of the preparing values
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "MapPrepare.h"
#include "../map/MapCell.h"
#include "../map/MapBlock.h"
#include "../objects/ObjectMan.h"
#include "../system/system.h"
#include "../util/IniFile.h"


#define MAX(x,y) (x < y ? y : x)
#define MIN(x,y) (x < y ? x : y)

bool MapPrepare::upandrun = false;

MapCell MapPrepare::void_cell = {
  507,     // unsigned int id;
  0,     // signed int8 z;
  false, // bool stretched;
  44,    // unsigned int hl;       // height of tile on the left side
  44,    // unsigned int hr;       // height of tile on the right side 
  22,    // unsigned int stl;      // stretch the corner to this height on the left side 
  22,    // unsigned int str;      // stretch the corner to this height on the left side 
};

MapBlock * MapPrepare::void_mapblock = NULL;

bool MapPrepare::initialize(IniFile *config)
{
  if (void_mapblock == NULL) {
    void_mapblock = new MapBlock;
    for (unsigned int32 x = 0; x < 8; x++) {
      for (unsigned int32 y = 0; y < 8; y++) {
        void_mapblock->cells[x][y].id  = void_cell.id;
        void_mapblock->cells[x][y].hr  = void_cell.hr;
        void_mapblock->cells[x][y].hl  = void_cell.hl;
        void_mapblock->cells[x][y].str = void_cell.str;
        void_mapblock->cells[x][y].stl = void_cell.stl;
        void_mapblock->cells[x][y].z   = void_cell.z;
        void_mapblock->cells[x][y].stretched   = void_cell.stretched;
      }
    }
    void_mapblock->prepared = false;
  }
  upandrun = true;
  return true;
}

void MapPrepare::finalize()
{
  delete void_mapblock;
  upandrun = false;
}


MapBlock *MapPrepare::prepare(unsigned int32 id, MapBlock *block)
{
  if (!block->prepared) {
    // prepare the block if it has not been done already
    // (calculate the stretch-o-tilt paramters)
    MapBlock *e_blk; // est block
    MapBlock *s_blk; // south block
    MapBlock *w_blk; // west  block
    MapBlock *d_blk; // down  block        

    if (id + 512 < 768 * 512) {
      e_blk = ObjectMan::get_map_block(id + 512);  
    } else {
      e_blk = void_mapblock;
      e_blk->lock();
    }

    if (id + 1 < 768 * 512) {
      s_blk = ObjectMan::get_map_block(id +   1);  
    } else {
      s_blk = void_mapblock;
      s_blk->lock();
    }

    if (id >= 512) {
      w_blk = ObjectMan::get_map_block(id - 512);  
    } else {
      w_blk = void_mapblock;
      w_blk->lock();
    }

    if (id + 513 < 768 * 512) {
      d_blk = ObjectMan::get_map_block(id + 513);  // down  block        
    } else {
      d_blk = void_mapblock;
      d_blk->lock();
    }
        
    unsigned int32 x , y;
    // build stretch value for centered, east, and south tiles.
    for(x = 0; x < 7; x++) {
      for(y = 0; y < 7; y++) {
        block->cells[x][y].stl = abs(((((int32) block->cells[x][y].z) - ((int32) block->cells[x][y+1].z)) << 2) + 22);
        block->cells[x][y].str = abs(((((int32) block->cells[x][y].z) - ((int32) block->cells[x+1][y].z)) << 2) + 22);
      }
    }

    // build stretch values for south tiles
    for(x = 0; x < 7; x++) {
      block->cells[x][7].stl = abs(((((int32) block->cells[x][7].z) - ((int32) s_blk->cells[x][0].z))   << 2) + 22);
      block->cells[x][7].str = abs(((((int32) block->cells[x][7].z) - ((int32) block->cells[x+1][7].z)) << 2) + 22);         
    }
    
    // build stretch values for east tiles
    for(y = 0; y < 7; y++) {
      block->cells[7][y].stl = abs(((((int32) block->cells[7][y].z) - ((int32) block->cells[7][y+1].z)) << 2) + 22);
      block->cells[7][y].str = abs(((((int32) block->cells[7][y].z) - ((int32) e_blk->cells[0][y].z))   << 2) + 22);
    }

    // build stretch value for the south-east tile
    block->cells[7][7].stl = abs(((((int32) block->cells[7][7].z) - ((int32) s_blk->cells[7][0].z)) << 2) + 22);
    block->cells[7][7].str = abs(((((int32) block->cells[7][7].z) - ((int32) e_blk->cells[0][7].z)) << 2) + 22);
    
    
    // build height values for centered, north and east tiles     
    for(x = 0; x < 7; x++) {
      for(y = 0; y < 7; y++) {
        block->cells[x][y].hl = block->cells[x][y].stl + block->cells[x][y+1].str;
        block->cells[x][y].hr = block->cells[x][y].str + block->cells[x+1][y].stl;
      }       
    }     
    // build height values for south tiles     
    for(x = 0; x < 7; x++) {
      block->cells[x][7].hl = block->cells[x][7].stl + abs(((((int32) s_blk->cells[x][0].z) - ((int32) s_blk->cells[x+1][0].z)) << 2) + 22);
      block->cells[x][7].hr = block->cells[x][7].str + block->cells[x+1][7].stl;
    }
    // build height values for east tiles     
    for(y = 0; y < 7; y++) {
      block->cells[7][y].hl = block->cells[7][y].stl + block->cells[7][y+1].str;
      block->cells[7][y].hr = block->cells[7][y].str + abs(((((int32) e_blk->cells[0][y].z) - ((int32) e_blk->cells[0][y+1].z)) << 2) + 22);
    }
    // build height values for south east tile
    block->cells[7][7].hl = block->cells[7][7].stl + abs(((((int32) s_blk->cells[7][0].z) - ((int32) d_blk->cells[0][0].z)) << 2) + 22);
    block->cells[7][7].hr = block->cells[7][7].str + abs(((((int32) e_blk->cells[0][7].z) - ((int32) d_blk->cells[0][0].z)) << 2) + 22);

    e_blk->release();
    s_blk->release();
    w_blk->release();
    d_blk->release();
    for(x = 0; x < 8; x++) {
      for(y = 0; y < 8; y++) {
        if ( (block->cells[x][y].stl == 22) &&
             (block->cells[x][y].str == 22) &&
             (block->cells[x][y].hl == 44) &&
             (block->cells[x][y].hr == 44)
           ) {
          block->cells[x][y].stretched = false;
        } else {
          block->cells[x][y].stretched = true;
        }
      }
    }

    for (x = 0; x < 8; x++) {
      for (y = 0; y < 8; y++) {
        block->cells[x][y].bright = ((signed int32) block->cells[x][y].stl - (signed int32) block->cells[x][y].str) * 512 / ((signed int32)(MAX(block->cells[x][y].hl, block->cells[x][y].hr))  * 5) + 256;
      }
    }


    block->prepared = true;
  }
 
  return block;
}