//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  TiledataFission.h
//
//  Interface to the tiledata
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __TILEDATA_FISSION_H__
#define __TILEDATA_FISSION_H__

class IniFile;
class Tiledata;
class TiledataGroup;

class TiledataFission {
  private :
    static TiledataGroup *front_cache;
    static unsigned int32 front_cache_id;

  public :
    static bool initialize(IniFile *config);
    static void finalize();
    static bool upandrun;

    static Tiledata *get_map_tiledata(unsigned int32 id);
    static Tiledata *get_static_tiledata(unsigned int32 id);
    static void release();

#ifdef SANE
    static bool locked;
    TiledataFission(); // Panic if initialized (static class maynot be instanced)
#endif
};


#endif