//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  StaticFission.cpp
//
//  Static data fission.
//  THIS IS NOT USED CURRENTLY!
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "MapFission.h"
#include "MapPrepare.h"
#include "../map/MapCell.h"
#include "../map/MapBlock.h"
#include "../objects/ObjectMan.h"
#include "../system/system.h"

#define MAX(x,y) (x < y ? y : x)
#define MIN(x,y) (x < y ? x : y)

#ifdef AWAY_WITH_THIS

StaticBlock  *World::static_cache   = NULL;
unsigned int  World::static_cache_id = NULL;

StaticFission::StaticFission()
{
  front_cache_id = 0xFFFFFFFF;
  front_cache    = NULL;
}

StaticFission::~StaticFission()
{
}


StaticCell *World::getStaticCell(int cx, int cy)
{
  // this is a historic method, or rfu...
  System::panic("World::getStaticCell, method should not be called");
  unsigned int bx = cx >> 3;
  unsigned int by = cy >> 3;

  if ((cx < 0) || (cy < 0) || (cx >= 768 * 8) || (cy >= 512 * 8)) {
    return NULL;
  }

  unsigned int id = (bx) * 512 + (by);
  if (id == static_cache_id) {
    static_cache->lock++;
#ifdef SANE
    if (static_cache->lock == 0xFE) {
      System::panic("Lock overrun");
    }
#endif
    return (static_cache->cells[cx & 0x7][cy & 0x7]);
  }

  StaticBlock *block = ObjectMan::getStaticBlock(id);
  static_cache = block;
  static_cache_id = id;
  return block->cells[cx & 0x7][cy & 0x7];
}

void StaticFission::release()
{
  if (front_cache != NULL) {
    front_cache->release();
  }
}

#endif