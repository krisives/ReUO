//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Crystals.cpp
//
//  A crystal-growth simulation.
//  Well more a demonstration how also order can come from itself
//  into a choatic system.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "../config.h"
#include "../memguard.h"

#include "../display/Box.h"
#include "Crystals.h"

Crystals::Crystals()
{
}

Crystals::~Crystals()
{
}


bool Crystals::initialize(Box *s_box, IniFile *config)
{
  box = s_box;
  width  = box->width();
  height = box->height();
  size   = width * height;
  srand((unsigned) time(NULL));
  
  for (unsigned int32 i = 0; i < CRYSTALS; i++) {
    color_red[i]   = rand() & 0xFF;
    color_green[i] = rand() & 0xFF;
    color_blue[i]  = rand() & 0xFF;
  }

  cells   = (byte *) malloc(size + 1, "Crystals.cells");
  cells_b = (byte *) malloc(size + 1, "Crystals.cells_b");
  for (int32 y = 0; y < height; y++) {
    for (int32 x = 0; x < width; x++) {
      cells[y * width + x] = rand() % CRYSTALS;
    }
  }

  return true;
}

void Crystals::finalize()
{
  free(cells);
  free(cells_b);
}

void Crystals::step()
{
  int32 x, y;
  for (y = 0; y < height; y++) {
   for (x = 0; x < width; x++) {
     byte *cell_b = &cells_b[y * width + x];
     int8 cell = cells[y * width + x];
     int8 eat  = cell - 1;
     if (eat < 0) {
       eat += CRYSTALS;
     }
     *cell_b = cell;
     if (x > 0) {
      if (cells[y * width + x - 1] == eat)
         *cell_b = cells[y * width + x - 1] ;
     } 
     if (x < width - 1) {
       if (cells[y * width + x + 1] == eat)
         *cell_b = cells[y * width + x + 1] ;
     } 
     if (y > 0) {
       if (cells[(y - 1) * width + x] == eat)
         *cell_b = cells[(y - 1) * width + x];
     } 
     if (y < height - 1) {
       if (cells[(y + 1) * width + x] == eat)
         *cell_b = cells[(y + 1) * width + x];
     }     
   }
  }
  memcpy(cells, cells_b, size);
  box->lock();
  for (y = 0; y < height; y++) {
   for (x = 0; x < width; x++) {
     int32 cell  = cells[y * width + x];
     int8 red   = color_red[cell];
     int8 green = color_green[cell];
     int8 blue  = color_blue[cell];
     box->drawpixel(x, y, red, green, blue);
    }        
  }
  box->unlock();
}
