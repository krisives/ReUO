//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Rainbow.cpp
//
//  A rather simple graphic test, draws a rainbow color-blend over the screen.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string.h>
#include <time.h>
#include "../config.h"
#include "../memguard.h"

#include "../display/Box.h"
#include "Rainbow.h"

Rainbow::Rainbow()
{
}

Rainbow::~Rainbow()
{
}


bool Rainbow::initialize(Box *s_box, IniFile *config)
{
  box = s_box;
  unsigned int32 w  = box->width();
  unsigned int32 h = box->height();
  int32 size = w / 6;

  for (unsigned int32 y = 0; y < h; y++) {
    int32 p = (y) * w / h;
    for (unsigned int32 x = 0; x < w; x++, p++) {
      int32 seg = p / size;
      int8 pos = (((p % size) * 0xFF) / size) & 0xFF;
      switch (seg) {
        case 0 : box->drawpixel(x, y, 0xFF, pos, 0);           break; // red
        case 1 : box->drawpixel(x, y, 0xFF - pos, 0xFF, 0);    break; // yellow
        case 2 : box->drawpixel(x, y, 0x00, 0xFF, pos);        break; // green
        case 3 : box->drawpixel(x, y, 0x00, 0xFF - pos, 0xFF); break; // cyan
        case 4 : box->drawpixel(x, y, pos, 0, 0xFF);           break; // blue
        case 5 : box->drawpixel(x, y, 0xFF, 0, 0xFF - pos);    break; // mageneta
        case 6 : box->drawpixel(x, y, 0xFF, 0, 0); p = 0;      break; // wrap
      }
    }        
  }
  return true;
}

void Rainbow::finalize()
{
}

void Rainbow::step()
{
  //box->lock();
  //box->scroll(8, 0);
  //box->unlock();
}
