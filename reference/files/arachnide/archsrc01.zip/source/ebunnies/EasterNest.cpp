//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  EasterNest.cpp
//
//  Host of the easter bunny stuff.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string.h>
#include <time.h>
#include "../SDL/SDL.h"
#include "../config.h"
#include "../memguard.h"

#include "../system/System.h"
#include "../display/Box.h"
#include "../display/Display.h"
#include "../heart/Heart.h"
#include "../util/IniFile.h"
#include "EasterNest.h"
#include "Creadance.h"
#include "Crystals.h"
#include "Rainbow.h"
#include "Inferno.h"
#include "EasterBunny.h"
#include "Waterwave.h"

void EasterNest::run(const byte *ebunny, IniFile *config)
{ 
  EasterBunny *easterBunny;
  Crystals   crystals;
  Rainbow    rainbow;
  Inferno    inferno;
  Waterwave  waterwave;
  Creadance  creadance;

  if (!strcmp(ebunny, "CRYSTALS")) {
    easterBunny = &crystals;
  } else if (!strcmp(ebunny, "RAINBOW")) {
    easterBunny = &rainbow;
  } else if (!strcmp(ebunny, "INFERNO")) {
    easterBunny = &inferno;
  } else if (!strcmp(ebunny, "WATERWAVE")) {
    easterBunny = &waterwave;
  } else if (!strcmp(ebunny, "CREADANCE")) {
    easterBunny = &creadance;
  } else {
    System::message("ERROR: unkown easter bunny specified.\n               use \"NONE\" for normal game play.");
    return;
  }

  Heart::enter_level(LEVEL_DISPLAY);
  Box *box  = Display::masterbox;
  easterBunny->initialize(box, config);

  unsigned int32 cycle = 0;
  for(;;) {
    easterBunny->step();
    box->update();
    if ((++cycle & 0xf) == 0) {
      System::cycle();
    }
    SDL_Event event;    
    SDL_PollEvent(&event);

    switch (event.type) {
        case SDL_KEYDOWN:
            if (event.key.keysym.scancode != 1) {
              // Quit on ESC
              break;
            }
            // !!! FALL_THROUGH !!!
        case SDL_QUIT:
            SDL_Quit();
            easterBunny->finalize();
            Heart::enter_level(0);
            return;
    }
  }
}

