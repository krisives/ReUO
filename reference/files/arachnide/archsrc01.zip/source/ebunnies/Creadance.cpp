//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Creadance.cpp
//
//  A creature with a simple blending effect. As simple it is it looks cute.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string.>
#include <math.h>
#include <time.h>
#include "../config.h"
#include "../memguard.h"

#include "Creadance.h"
#include "../display/Box.h"
#include "../display/Sprite.h"
#include "../fission/AnimFission.h"
#include "../heart/Heart.h"
#include "../mulreader/MAnimReader.h"
#include "../objects/Cache.h"
#include "../objects/ObjectMan.h"
#include "../skin/AnimSprite.h"
#include "../system/system.h"
#include "../util/IniFile.h"

unsigned int32 Creadance::idc = 54;

unsigned int32 Creadance::ids[] = {
  0x1d,  0x06,  0x51,  0x08,  0x4c,  0x09,  0x0A,  0x97,  0x0C,  0x3B,
  0x3C,  0x0F,  0x10,  0x02,  0x12,  0x04,  0x16,  0x50,  0x1E,  0x1F,
  0x18,  0x21,  0x24,  0x23,  0x27,  0x01,  0x55,  0x57,  0x56,  0x11,
  0x29,  0x07,  0x2A,  0x2C,  0x2D,  0x2F,  0x30,  0x15,  0x96,  0x1A,
  0x38,  0x39,  0x33,  0x34,  0x1C,  0x47,  0x48,  0x46,  0x36,  0x35,
  0x37,  0x5f,  0x3a,  0x03
};

Creadance::Creadance()
{

}

Creadance::~Creadance()
{
}


bool Creadance::initialize(Box *s_box, IniFile *config)
{
  box = s_box;
  width  = box->width();
  height = box->height();

  srand((unsigned) time(NULL));

  Heart::enter_level(LEVEL_READERS);
  const byte *c_UOPath = config->getString("UOPATH", NULL);
  std::string uoPath = c_UOPath;

  std::string mul_filename = uoPath + "\\anim.mul";
  std::string idx_filename = uoPath + "\\anim.idx";   
      
  if (!MAnimReader::open(mul_filename.c_str(), 
                         idx_filename.c_str(), 
                         box->pixelformat())) {
    std::string message;
    message = "Failure opening \"" + mul_filename + "\" , \"" + idx_filename + "\"";
    System::panic(message.c_str());
    return false;
  }

  Heart::enter_level(LEVEL_FISSION);

  box->lock();
  for (unsigned int32 x = 0; x < width; x++) {
    for (unsigned int32 y = 0; y < height; y++) {
      box->drawpixel(x, y, 0, 0, 0);
    }
  }
  circle = 0;
    
  box->unlock();
  frame = 0;
  id = 0x3B;
  changeon = 150;
  dstep = 0;
  tick  = 0;
  return true;
}

void Creadance::finalize()
{
  AnimFission::finalize();
  ObjectMan::finalize();
  Cache::finalize();
  MAnimReader::finalize();
}

void Creadance::step()
{
  box->lock();
  double r = (double) rand() / (RAND_MAX);
  dstep += r - 0.5;
  tick++;
  if (dstep > 1.5) {
    dstep = 1.5;
  }
  if (dstep < -1.5) {
    dstep = -1.5;
  }
  circle += dstep;

  signed int32 scrollx = signed int32 (sin((double) circle / 20) * 20);
  signed int32 scrolly = signed int32 (cos((double) circle / 20) * 20);

  if (tick == changeon) {
    id = ids[rand() * idc / RAND_MAX];
    circle++;
    tick = 0;
    changeon = 100 + (rand() * 100) / RAND_MAX;
  }

  box->scroll(scrollx, scrolly);
  if (scrollx > 0) {
    for (unsigned int32 x = width - scrollx; x < width; x++) {
      for (unsigned int32 y = 0; y < height; y++) {
        box->drawpixel(x, y, 0, 0, 0);
      }
    }
  } else if (scrollx < 0) {
    for (unsigned int32 x = 0; x < -scrollx; x++) {
      for (unsigned int32 y = 0; y < height; y++) {
        box->drawpixel(x, y, 0, 0, 0);
      }
    }
  } 

  if (scrolly > 0) {
    for (unsigned int32 y = height - scrolly; y < height; y++) {
      for (unsigned int32 x = 0; x < width; x++) {
        box->drawpixel(x, y, 0, 0, 0);      
       }
    }
  } else if (scrolly < 0) {
    for (unsigned int32 y = 0; y < -scrolly; y++) {
      for (unsigned int32 x = 0; x < width; x++) {
        box->drawpixel(x, y, 0, 0, 0);
      }
    }
  } 

  if (++frame == 3 * 10) {
    frame = 0;
  }

  AnimSprite *animSprite = AnimFission::getFrame(id, AnimFission::WALK, 0, frame / 3);
  Sprite     *sprite = (Sprite *) animSprite;
  box->drawSprite((width - animSprite->width) / 2, (height - animSprite->height) / 2, sprite);
  AnimFission::release();
  box->unlock();
}
