//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Waterwave.cpp
//
//  A waterwave going over a pool background.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "../config.h"
#include "../memguard.h"

#include "../display/Box.h"
#include "Waterwave.h"

#define STEP 25


Waterwave::Waterwave()
{
}

Waterwave::~Waterwave()
{
}


bool Waterwave::initialize(Box *s_box, IniFile *config)
{
  box = s_box;
  width  = box->width();
  height = box->height();
  size   = width * height;
  srand((unsigned) time(NULL));

  gred   = (unsigned byte *) malloc(size, "Waterwave.red");
  ggreen = (unsigned byte *) malloc(size, "Waterwave.green");
  gblue  = (unsigned byte *) malloc(size, "Waterwave.blue");
  water  = (int32 *) malloc(width * height * sizeof(int32), "Waterwave.water");
  wdiffy = (int32 *) malloc(width * height * sizeof(int32), "Waterwave.wdiffy");
  wdiffx = (int32 *) malloc(width * height * sizeof(int32), "Waterwave.wdiffx");
  
  {
    for (int32 y = 0; y < height; y++) {
      for (int32 x = 0; x < width; x++) {
        if ((x % 32) == 0) {
          //gred  [y * width + x] = 0x90;
          //ggreen[y * width + x] = 0x90;
          //gblue [y * width + x] = 0xb0;
        } else if ((y % 32) == 0) {
          gred  [y * width + x] = 0x90;
          ggreen[y * width + x] = 0x90;
          gblue [y * width + x] = 0xb0;
        } else {
          gred  [y * width + x] = 0x00;
          ggreen[y * width + x] = 0x00;
          gblue [y * width + x] = 0xa0;
        }
      }
    }
  }

  for (int32 y = 0; y < height; y++) {
    for (int32 x = 0; x < width; x++) {      
        water[y * width + x] = (int32) (sin(((double) ((x) + y)) / 70) * 0x1000);
    }
  }
  pos = 0;

  return true;
}

void Waterwave::finalize()
{
  free(gred);
  free(ggreen);
  free(gblue);
  free(water);
  free(wdiffx);
  free(wdiffy);
}

void Waterwave::step()
{
  memmove(water, water + STEP, (width * height - STEP - 1) * sizeof(int32));
  pos += STEP;
  {
    for (int32 y = 0; y < height; y++) {
      for (int32 x = width - STEP; x < width; x++) {      
        water[y * width + x] = (int32) (sin(((double) ((x + pos) + y)) / 70) * 0x1000);
      }
    }
  }


  {
    for (int32 y = 1; y < height - 1; y++) {
      for (int32 x = 1; x < width - 1; x++) {      
        wdiffx[y * width + x] = (water[y * width + (x + 1)] - water[y * width + (x - 1)]);
        wdiffy[y * width + x] = (water[(y + 1) * width + x] - water[(y - 1) * width + x]);
      }
    }
  }


  box->lock();
  for (int32 y = 1; y < height - 1; y++) {
    for (int32 x = 1; x < width - 1; x++) {
      unsigned int32  pos = y * width + x;
      int32 diffx = wdiffx[pos];
      int32 diffy = wdiffy[pos];
      int32 wpos = (int32) (((y << 12) + diffy) * width + ((x << 12) + diffx)) >> 12;
      if (wpos >= width * height) {
        wpos = width * height - 1;
      }
      if (wpos < 0) {
        wpos = 0;
      }

      double w = water[wpos];

      unsigned int32 red   = gred  [wpos];
      unsigned int32 green = ggreen[wpos];
      unsigned int32 blue  = gblue [wpos];

      red   = unsigned int32 (((-diffy - diffx) + 0x1000) * red)   >> 12;
      green = unsigned int32 (((-diffy - diffx) + 0x1000) * green) >> 12;
      blue  = unsigned int32 (((-diffy - diffx) + 0x1000) * blue)  >> 12;

      if (red   > 0xff) red   = 0xff;
      if (green > 0xff) green = 0xff;
      if (blue  > 0xff) blue  = 0xff;

      box->drawpixel(x,y, (int8) red, (int8) green, (int8) blue);
    }
  }
  box->unlock();
}
