//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Inferno.cpp
//
//  A smooth fire simulation.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "../config.h"
#include "../memguard.h"

#include "../display/Box.h"
#include "Inferno.h"

#define MAX_HOT (RAND_MAX * 3 + (RAND_MAX / 2) + 1)
#define LIFE    1.35
#define CYCLES  1

Inferno::Inferno()
{
}

Inferno::~Inferno()
{
}


bool Inferno::initialize(Box *s_box, IniFile *config)
{
  box = s_box;
  width  = box->width();
  height = box->height();
  size   = width * height;

  cw = width  >> 1;
  ch = (height >> 1) + 4; // + 4 hides the lowest for lines from user screen. gives the fire
                          //   a chance to "smooth" itself before moving to screen.

  srand((unsigned) time(NULL));

  cells = (int32 *) malloc(((cw + 1) * ch + 1) * sizeof(int32), "Inferno.cells");
  unsigned int32 pos = 0;
  for (unsigned int32 y = 0; y < ch + 1; y++) {
    for (unsigned int32 x = 0; x < cw; x++) {
      cells[pos++] = 0;
    }
  }

  return true;
}

void Inferno::finalize()
{
  free(cells);
}

void Inferno::step()
{
  unsigned int32 x, y;
  for (unsigned int32 cycles = 0; cycles < CYCLES; cycles++) {
    unsigned int32 pos = (ch - 1) * cw;
    for (x = 0; x < cw; x++) {
      int32 b = cells[pos];
      int32 r = (int32) ((rand() / LIFE) - (RAND_MAX / (LIFE * 2)));
      int32 a = b + r;
      if (a < 0) {
        a = 0;
      }
      if (a > MAX_HOT) {
        a = MAX_HOT;
      }
      cells[pos] = a;
      pos++;
    } 

    pos = 0;
    for (y = 0; y < ch - 1; y++) {
     for (x = 0; x < cw; x++) {
       cells[pos] = (int32)((cells[pos + cw] + cells[pos + cw + 1] + cells[pos + cw - 1]) / 3.035);
       pos++;
     }
    }
  }

  box->lock();
  unsigned int8 r;
  unsigned int8 g;
  unsigned int8 b;
  for (y = 0; y < height; y++) {
   for (x = 0; x < width; x++) {
     int32 cell = cells[(y>>1) * cw + (x>>1)];
     if (cell > RAND_MAX * 3) {
       b = 0xFF;
       g = 0x80;
       r = 0x80;
     } else if (cell >= RAND_MAX * 2) {
       b = (cell * 0xFF / (RAND_MAX * 2)) ;
       if (b == 0xFF) 
         b = 0;
       g = 0xFF - b;
       r = 0xFF - b;
       b = (0x80 + b);
       if (b > 0xFF) 
         b = 0xFF;
     } else if (cell >= RAND_MAX) {
       b = 0;
       g = cell * 0xFF / RAND_MAX;
       if (g == 0xFF) 
         g = 0;
       r = 0xFF;
     } else {
       r = cell * 0xFF / RAND_MAX;
       g = 0;
       b = 0;
     }
     box->drawpixel(x, y, r, g, b);
    }        
  }
  box->unlock();
}
