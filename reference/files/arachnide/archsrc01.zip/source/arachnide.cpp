#include <stdlib.h>
#include <string>
#include "Sdl/SDL.h"
#include "config.h"
#include "memguard.h"

#include "display/Box.h"
#include "display/Display.h"
#include "ebunnies/EasterNest.h"
#include "fission/MapPrepare.h"
#include "graphics/Stretch.h"
#include "heart/Heart.h"
#include "map/Tiledata.h"
#include "mulreader/MMapReader.h"
#include "mulreader/MStaticReader.h"
#include "mulreader/MTiledataReader.h"
#include "mulreader/MArtReader.h"
#include "mulreader/MAnimReader.h"
#include "mulreader/MFontReader.h"
#include "objects/Cache.h"
#include "objects/ObjectMan.h"
#include "screens/Welcome.h"
#include "system/system.h"
#include "system/Console.h"
#include "util/IniFile.h"
#include "vision/ScreenRenderer.h"
#include "vision/Vision.h"
#include "world/World.h"

#undef int  // remove primitive-destruction as the main routine needs to be in standard types.

int __cdecl main(int argc, char* argv[])
{
  IniFile config("arachnide.cfg");
  if (!config.open()) {
    System::message("ERROR: cannot open \"arachnide.cfg\". Startup failed.");
    return -1;
  }
  Heart::startup(&config);
  Heart::enter_level(LEVEL_SYSTEM);

  // Initialize display, this has to be done before the reader
  // initialization's because they need to know the pixel format used.

  // EBunny stuff
  const byte *ebunny = config.getString("EBUNNY", "NONE");
  if (strcmp(ebunny, "NONE") != 0) {
    Console::printf("-> Easterbunny mode");
    EasterNest::run(ebunny, &config);
    return 0;
  }
  // Normal runmode
  
  if (!Heart::enter_level(LEVEL_DISPLAY)) {
    config.close();
    return -1;
  }

  Box *front = Display::masterbox;
  if (!Heart::enter_level(LEVEL_READERS)) {
    config.close();
    return -1;
  }

  /*
  Cache::initialize(&config);
  ObjectMan::initialize(&config);

  World::initialize(&config);
  MapPrepare::initialize(&config);
  Vision::initialize(&config);
  Stretch::initialize(&config);
  */
  
  /*
  FILE *file = fopen("tiles.txt", "w");
  for (unsigned int i = 0; i < 0x4000; i++) {
    Tiledata *tiledata = ObjectMan::get_map_tiledata(i);
    fprintf(file, " 0x%8x - 0x%8x\n", i, tiledata->flags);   
    tiledata->release();
  }
  fclose(file);
  */
  Console::printf("-> Welcome.");
  if (!Heart::enter_level(LEVEL_WELCOME)) {
    config.close();
    return -1;
  }

  unsigned int32 asw = Welcome::run();
  if (asw == 0) {
    Console::printf("-> Ingame.");
    if (!Heart::enter_level(LEVEL_OFFGAME)) {
      config.close();
      return -1;
    }
    Vision::run();
  }
  

  config.close();
  Heart::enter_level(LEVEL_CONSOLE);
#if MEM_GUARD_LEVEL == 2
  showMemory();
#endif
  Heart::enter_level(LEVEL_SHUTDWN);
  SDL_Quit();
  return -1;
}