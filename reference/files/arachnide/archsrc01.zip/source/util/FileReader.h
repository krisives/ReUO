//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  FileReader.cpp
//
//  Implements a file reader stream.
//    (I know there are streams ready in the c++ library, but i perfer 
//     definig my own ones (providing a more beautiful overall))
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __FILE_READER_H__
#define __FILE_READER_H__

#ifdef WIN32
   typedef struct _iobuf FILE;
#else
#  include <stdio.h>
#endif

class FileReader {
  private : 
    const byte  *filename;
    byte        *buf;
    size_t       bufsize;
    int32        mode;
    FILE        *file;
    bool         isopen;
    bool         iseof;

  public :
    FileReader(const byte *filename, int32 mode);
    ~FileReader();
    byte *readline();
    bool open();
    void close();
    bool eof();
    bool isOpen();
    bool seek(unsigned int32 offset);
    unsigned int32  pos();
    unsigned int32 read_uint32_little();
    unsigned int32 read_uint32_big();
    unsigned int16 read_uint16_little();
    unsigned int16 read_uint16_big();
    signed   int16 read_sint16_little();
    signed   int16 read_sint16_big();
    unsigned byte  read_byte();
    signed int8    read_sint8();

  enum {
    TEXT,
    BINARY
  };
};

#endif