//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  LongHashtable.cpp
//
//  Implements the favorite hashtable algorithm for long integer keys.
//  (Search for objects from keys)
//
//  Note, A key of 0xFFFFFFFF is not legal, as it represents 0
//        0 itself means invalid entry.
//        (using it is not fatal itself, but 0 and (-1) will override each other)
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <malloc.h>
#include <stdio.h>
#include "../config.h"
#include "../memguard.h"

#include "LongHashtable.h"
#include "Prime.h"

#define INVALID        0

#define HASH(x, size)        (x % size)    // yes, this is a very lousy hash algorithm.... 
#define DEFAULT_SIZE   HASH_DEFAULT_SIZE
#define LOAD_FACTOR    HASH_LOAD_FACTOR
#define HASH_ENTRY     LONG_HASH_ENTRY


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// LongHashtable::LongHashtable
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
LongHashtable::LongHashtable()
{
  tabsize = DEFAULT_SIZE;
  used    = 0;
  valve   = (unsigned int32) (tabsize * LOAD_FACTOR);
  table   = (HASH_ENTRY *) malloc(tabsize * sizeof(HASH_ENTRY), "LongHashTable.table");
  for(unsigned int32 l = 0; l < tabsize; l++) {
    table[l].key = INVALID;
  }

#ifdef PROFILE_HASHTABLE
  puts       = 0;
  collisions = 0;
  rehashes   = 0;
#endif
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// LongHashtable::~LongHashtable
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
LongHashtable::~LongHashtable()
{
  free(table);
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// LongHashtable::put
//
// Add an entry into the hashtable.
//
// unsigned long key  - the key value
// void * value       - a general purpose pointer / variable
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void LongHashtable::put(unsigned int32 key, void * value)
{
  if (key == INVALID) {
    key = INVALID - 1;
  }

  unsigned int32 hash = HASH(key, tabsize);

#ifdef PROFILE_HASHTABLE
    puts++;  
#endif

  if (++used >= valve) {
    rehash();
    hash = HASH(key, tabsize);
  }
  
  while (table[hash].key != INVALID) {    
    if (table[hash].key == key) {
      break;
    }
    if (++hash >= tabsize) {
      hash = 0;
    }
#ifdef PROFILE_HASHTABLE
    collisions++;  
#endif
  }

  table[hash].key   = key;
  table[hash].value = value;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// LongHashtable::get
//
// Receive an entry.
//
// unsigned long key  - the key value
//
// returns            - the value found, or 
//                      NULL if the key doesn't exist.
//                      Note: You can put NULL values has value in the table,
//                            but then you cannot distinguish between not found 
//                            entries
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void *LongHashtable::get(unsigned int32 key)
{
  if (key == INVALID) {
    key = INVALID - 1;
  }

  unsigned int32 hash = HASH(key, tabsize);

  for(;;) {
    if (table[hash].key == key) {
      return table[hash].value; 
    }
    if (table[hash].key == INVALID) {
      return 0;
    }
    hash++;
  }
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// LongHashtable::rehash
//
// Doubles the size of the hashtable and recalculates all keys. Called 
// automatic by put() when the number of entries reach a 
// hazardous level (LOAD_FACTOR)
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void LongHashtable::rehash()
{
  // calculate new table size (next higher prime number to double size)
  unsigned int32 newsize = Prime::nextPrime(tabsize * 2);
  // allocate new table
  HASH_ENTRY *newtable  = (HASH_ENTRY *) malloc(newsize * sizeof(HASH_ENTRY), "LongHashtable.table");
  // Initialize the new table to INVALID values
  for(unsigned int32 l = 0; l < newsize; l++) {
    newtable[l].key = INVALID;
  }

  for (unsigned int32 i = 0;i < tabsize; i++) {
    if (table[i].key != INVALID) {
      unsigned int32 hash = HASH(table[i].key, newsize);
      while (newtable[hash].key != INVALID) {
        // no need to check for duplicates
        if (++hash >= newsize) {
          hash = 0;
        }
      }
      newtable[hash].key   = table[i].key;
      newtable[hash].value = table[i].value;
    }
  }
  // free old table
  free(table);
  // assign new table to current
  table   = newtable;
  tabsize = newsize;
  valve   = (unsigned int32) (newsize * LOAD_FACTOR);
#ifdef PROFILE_HASHTABLE
  rehashes++;  
#endif
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// LongHashtable::relief
//
// Resets the table, AND free's all childs pointed by value!
// (So better be sure it are valid pointers *grins*)
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void LongHashtable::relief()
{
  for(unsigned int32 i = 0; i < tabsize; i++) {
    if (table[i].key != INVALID) {
      free(table[i].value);
      table[i].key = INVALID;
    }
  }
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// LongHashtable::isEmpty
//
// returns true is the table is empty
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool LongHashtable::isEmpty()
{
  return used > 0;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// LongHashtable::size
//
// returns the number of entries
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
unsigned int32 LongHashtable::size()
{
  return used;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// LongHashtable::first
//
// Receives the first entry in the table.
//   This is has not to be the first entry added to the list!
//   It's a complete random one. 
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void* LongHashtable::first()
{
  seq_pos = 0;
  return next();
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// LongHashtable::next
//
// Receives the next entry in the table. 
//   (first() has to be called before this function)
//   The is no pariticular order the entries are received.
//
// returns the next element or NULL if on end of list
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void* LongHashtable::next()
{
  for(unsigned int32 i = seq_pos; i < tabsize; i++) {
    if (table[i].key != INVALID) {
      seq_pos = i + 1;
      return table[i].value;
    }
  }  
  return NULL;
}

#ifdef PROFILE_HASHTABLE
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// LongHashtable::profile
//
// Print the table profile to stdout.
//
// byte * name - The name of the table. 
//               (used the recognize it for humans in the output)
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void LongHashtable::profile(byte * name)
{
  printf("Hashtable (long) profile: %s\n", name);
  printf("  size       %6d\n",  (int32) tabsize);
  printf("  used       %6d\n",  (int32) used);
  printf("  puts       %6d\n",  (int32) puts);
  printf("  collisions %6d\n",  (int32) collisions);
  printf("  rehashes   %6d\n",  (int32) rehashes);
  printf("  ratio         %6.2f%%\n",  (100.0f * collisions) / puts);
}



#endif
