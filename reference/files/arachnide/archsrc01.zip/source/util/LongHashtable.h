//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  LongHashtable.cpp
//
//  Implements the favorite hashtable algorithm for long integer keys.
//  (Search for objects from keys)
//
//  Note, A key of 0xFFFFFFFF is not legal, as it represents 0
//        0 itself means invalid entry.
//        (using it is not fatal itself, but 0 and (-1) will override each other)
//
//  Entries in this table can't be deleted
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __LONG_HASHTABLE_H__
#define __LONG_HASHTABLE_H__
         
struct LONG_HASH_ENTRY {
  unsigned int32 key;
  void *value;
};

class LongHashtable {
  private : 
    LONG_HASH_ENTRY  *table;
    unsigned int32 tabsize; // size of table
    unsigned int32 used;    // how many entries are used
    unsigned int32 valve;   // if used reaches this value the table is rehashed
    unsigned int32 seq_pos; // position for first() and next()

  public :
    LongHashtable();
    ~LongHashtable();
    void rehash();
    void put(unsigned int32 key, void* value);
    void* get(unsigned int32 key);
    void relief();

    void* first();
    void* next();

    bool isEmpty();
    unsigned int32 size();

#ifdef PROFILE_HASHTABLE
  private :
    unsigned int32 puts;
    unsigned int32 collisions;    
    unsigned int32 rehashes;
  public  :
    void profile(byte * name);
#endif

};

#endif