//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Vector.cpp
//
//  Implements a growable array.
//  (I know there is also one in the STL template libraries, but I hate
//   templates, world functions well without them.)
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <malloc.h>
#include <stdlib.h>
#include "../config.h"
#include "../memguard.h"

#include "Vector.h"

#define DEFAULT_SIZE   VECTOR_DEFAULT_SIZE

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Vector::Vector
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
Vector::Vector()
{
  tabsize = DEFAULT_SIZE;
  used    = 0;
  table   = (void **) malloc(tabsize * sizeof(void*), "Vector.table");
  if (table == NULL) {
    // PANIC
  }
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Vector::~Vector
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
Vector::~Vector()
{
  free(table);
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Vector::append
//
// Add an entry at the end to the vector.
//
// void * value       - a general purpose pointer / variable
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void Vector::append(void *value)
{
  if (used + 1 == tabsize)
    expand();

  table[used++] = value;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Vector::elementAt
//
// Receive an entry at the given position
//
// Returns the element, or NULL if pos is greater than the vector size.
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void *Vector::elementAt(unsigned int32 pos)
{
  if (pos >= used) {
    return NULL;
  }
  return table[pos];
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Vector::expand
//
// Doubles the size of the Vector.
//
// returns true on success, false if out-of-memory
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool Vector::expand()
{
  unsigned int32 newsize = tabsize * 2;
  // allocate new table
  void **newtable  = (void **) realloc(table, newsize * sizeof(void *));

  if (newtable == NULL) {
    return false;
  }
  tabsize = newsize;
  table   = newtable;
  return true;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Vector::relief
//
// Resets the vector, AND free's all childs pointed by value!
// (So better be sure it are valid pointers *grins*)
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void Vector::relief()
{
  for(unsigned int32 i = 0; i < used; i++) {
    free(table[i]);
  }
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Vector::isEmpty
//
// returns true is the table is empty
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool Vector::isEmpty()
{
  return used > 0;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Vector::size
//
// returns the size of the vector
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
unsigned int32 Vector::size()
{
  return used;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Vector::reset
//
// set vector size to 0
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void Vector::reset()
{
  used = 0;
}
