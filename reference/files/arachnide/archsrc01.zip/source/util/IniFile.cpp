//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  IniFile.cpp
//
//  The INI configuration file, special feature is that the reader remembers
//  exact structure of the file, so it can be resynthesized on write back.
//  (The application also saved it's settings inside it)
//
//  Note: Tabs in the original string will be translated to single space on write
//        back
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <stdio.h>
#include <malloc.h>
#include <string>
#include "../config.h"
#include "../memguard.h"

#include "FileReader.h"
#include "StringHashtable.h"
#include "IniFile.h"
#include "Vector.h"

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// local class IniEntry
//
// Holds information about a single INI-File line.
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
class IniEntry {
  public :
    int32 pos_command;
    int32 pos_equal;
    int32 pos_parm;
    int32 pos_hash;
    int32 pos_comment;
  
    byte *command;
    byte *parm;
    byte *comment;

    IniEntry(int32 pos_command,
             int32 pos_equal,
             int32 pos_parm,
             int32 pos_hash,
             int32 pos_comment,  
             const byte *line
            );
    
    ~IniEntry();
};

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// ~~~ IniFile ~~~
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// IniFile::IniFile
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

IniFile::IniFile(const byte *s_filename)
{
  filename = s_filename;
  reader   = new FileReader(s_filename, FileReader::TEXT);
  lines    = new Vector();
  hash     = new StringHashtable();
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// IniFile::~IniFile
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

IniFile::~IniFile()
{
  if (reader->isOpen()) {
    reader->close();
  }
  delete reader;

  // Delete all entries in the line-vector
  // (relief() cannot be used, since the destructors 
  //  will not be called)
  IniEntry *entry = (IniEntry *)hash->first();
  unsigned int32 linesize = lines->size();
  for (unsigned int32 i = 0; i < linesize; i++) {
    delete ((IniEntry *) lines->elementAt(i));
  }
  delete lines;
  delete hash;
}

bool IniFile::open()
{
  if (reader->isOpen()) {
    return false;
  }
  bool asw = reader->open();
  if (asw != true) {
    return false;
  }

  for(;;) {
    byte *line  = reader->readline();
    if (reader->eof()) {
      break;
    }
    unsigned int32 linelen = strlen(line);

    byte *pos_command = NULL;
    byte *pos_equal   = NULL;
    byte *pos_parm    = NULL;
    byte *pos_hash    = NULL;
    byte *pos_comment = NULL;
  
    byte *cp = tokenStart(line);
    if (cp != NULL) {
      // just a comment
      if (*cp == '#') {
        pos_hash = cp;
        cp++;
        cp = tokenStart(cp);
        if (cp != NULL) {
          pos_comment = cp;
        }
      } else {
        pos_command = cp;
        cp = strchr(cp, '=');
        if (cp != NULL) {
          pos_equal   = cp;
          cp++;

          cp = tokenStart(cp);
          if (cp != NULL) {   
            pos_parm = cp;

            cp = strchr(cp, '#');
            if (cp != NULL) {
              pos_hash = cp;
              cp++;

              cp = tokenStart(cp);
              if (cp != NULL) {
                pos_comment = cp;       
              }
            }
          }
        }
      } 
    }
    IniEntry *entry = new IniEntry(pos_command != 0 ? pos_command - line : -1,
                                   pos_equal   != 0 ? pos_equal   - line : -1,
                                   pos_parm    != 0 ? pos_parm    - line : -1,
                                   pos_hash    != 0 ? pos_hash    - line : -1,
                                   pos_comment != 0 ? pos_comment - line : -1,
                                   line
                                  );   
    
    lines->append(entry);
    if (entry->command != NULL) {
      if (*entry->command != 0) {
        hash->put(entry->command, entry);
      }
    }
  }
  return true;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// IniFile::tokenStart
//
// returns next pointer to the next character in string which is not a space
// or tab, or NULL, if the whole string consists only of spaces/tabs.
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
byte * IniFile::tokenStart(byte *str) 
{
  while(*str != 0) {
    if ((*str != ' ') && (*str != '\t')) {
      // token start
      return str;
    }
    str++;
  }
  return NULL;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// IniFile::getString
//
// Recevie an INI-File entry, return defval if the value isn't found.
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
const byte *IniFile::getString(const byte *command, const byte *defval)
{
  IniEntry *entry = (IniEntry *) hash->get(command);

  if (entry == NULL) {
    return defval;
  } else {
    if (entry->parm == NULL) {
      return defval;
    } else {
      return entry->parm;
    }
  }
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// IniFile::getBoolean
//
// Recevie an INI-File entry, return defval if the value isn't found.
// The value is treated as boolean, if it begins with '1','Y','J' or 'T'
//   it's truth else it's false
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool IniFile::getBoolean(const byte *command, bool defval)
{
  byte trueChars[] = "1YJTyjt";
  const byte *entry = getString(command, defval ? "Y" : "N");

  if (entry[0] == 0) {
    return defval;
  }

  return strchr(trueChars, entry[0]) != NULL;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// IniFile::getInteger
//
// Recevie an INI-File entry, return defval if the value isn't found.
// The value is treated as integer. 
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
int32 IniFile::getInteger(const byte *command, int32 defval)
{
  const byte *entry = getString(command, NULL);
  if (entry == NULL) {
    return defval;
  }
  
  return atoi(entry);
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// IniFile::close
//
// Close the file.
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void IniFile::close()
{
  if (!reader->isOpen()) 
    return;
  reader->close();
}



//�"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"
// ~~~  IniEntry  ~~~
//�"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// IniEntry::IniEntry
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
IniEntry::IniEntry(int32 s_pos_command,
                   int32 s_pos_equal,
                   int32 s_pos_parm,
                   int32 s_pos_hash,
                   int32 s_pos_comment,
                   const byte *line
                  )              
{
  unsigned int32 linelen = strlen(line);
  pos_command  = s_pos_command;
  pos_equal    = s_pos_equal;
  pos_parm     = s_pos_parm;
  pos_hash     = s_pos_hash;
  pos_comment  = s_pos_comment;
  
  command      = NULL;
  parm         = NULL;
  comment      = NULL;

  if (s_pos_command >= 0) {
    int32 cend;
    if (s_pos_equal >= 0) {
      cend = s_pos_equal - 1;
    } else {
      cend = linelen - 1;
    }
    // trim the string
    while ((line[cend] == ' ') || (line[cend] == '\t')) {
      cend--;
    }
    int32 clen = cend - s_pos_command + 1;

    command = (byte *) malloc(clen + 1, "IniEntry.command");
    strncpy(command, &line[s_pos_command], clen );
    command[clen] = 0;
    strupr(command);
  }


  if (s_pos_parm >= 0) {
    int32 cend;
    if (s_pos_hash >= 0) {
      cend = s_pos_hash - 1;
    } else {
      cend = linelen - 1;
    }
    // trim the string
    while ((line[cend] == ' ') || (line[cend] == '\t')) {
      cend--;
    }
    int32 clen = cend - s_pos_parm + 1;

    parm = (byte *) malloc(clen + 1, "IniEntry.parm");
    strncpy(parm, &line[s_pos_parm], clen );
    parm[clen] = 0;
  }

  if (s_pos_comment >= 0) {
    int32 cend = linelen - 1;
    // trim the string
    while ((line[cend] == ' ') || (line[cend] == '\t')) {
      cend--;
    }
    int32 clen = cend - s_pos_comment + 1;

    comment = (byte *) malloc(clen + 1, "IniEntry.comment");
    strncpy(comment, &line[s_pos_comment], clen );
    comment[clen] = 0;
  }

}

IniEntry::~IniEntry()
{
  if (command != NULL) {
    free(command);
  }
  if (parm != NULL) {
    free(parm);
  }
  if (comment != NULL) {
    free(comment);
  }
}
