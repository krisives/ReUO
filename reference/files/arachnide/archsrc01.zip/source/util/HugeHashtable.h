//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  HugeHashtable.cpp
//
//  Implements the favorite hashtable algorithm with two paired long integer keys,
//  This table is special tailored to the needs of the Cache, it requieres Object's 
//  as values, and uses the hash_entry member-variable to quickly reverse find values.
//
//  It uses a double-sized table, where in the lower half the hash codes are entered
//  and in the upper half collision are chained.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __HUGE_HASHTABLE_H__
#define __HUGE_HASHTABLE_H__
  
class Object;
       
struct HUGE_HASH_ENTRY {
  unsigned int32 key1;
  unsigned int32 key2;
  unsigned int32 next; // collision entries
  unsigned int32 before;
  Object *value;
};

class HugeHashtable {
  private : 
    HUGE_HASH_ENTRY  *table; // normal table
    unsigned int32 tabsize;   // size of table
    unsigned int32 tabsize_2; // size of table * 2
    unsigned int32 used;    // how many entries are used
    unsigned int32 valve;   // if used reaches this value the table is rehashed
    unsigned int32 seq_pos; // position for first() and next()
    unsigned int32 cpos;    // position in the collision table

  public :
    HugeHashtable();
    ~HugeHashtable();
    void rehash();
    void put(unsigned int32 key1, unsigned int32 key2, Object* value);
    Object* get(unsigned int32 key1, unsigned int32 key2);
    bool remove(unsigned int32 key1, unsigned int32 key2);
    void remove(Object *value);
    void relief();

    bool isEmpty();
    unsigned int32 size();

#ifdef PROFILE_HASHTABLE
  private :
    unsigned int32 puts;
    unsigned int32 collisions;    
    unsigned int32 rehashes;
  public  :
    void profile(byte * name);
#endif

};

#endif