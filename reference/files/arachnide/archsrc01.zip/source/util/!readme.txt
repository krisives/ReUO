�"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~�
  /util
�"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~�

This directory contains general usable API functions/algorithmns.

These classes replace, extend, provide an alternative of the standard c++ API
or wrap around it.

Some class API might remember in far of the java.util API, it's because I like it 
and has proven very usefull in the past. 

* FileReader       Stream for reading files.
* HugeHashtable    A Hash table with two unsigned long key's, tailored on the needs of the cache.
* IniFile          Parser and Synthesizer(writeback) for the arachnide.cfg file
* LongHashtable    A Hash table for unsigned long key's
* StringHashtable  A Hash table for string key's (char *).
* Prime            A prime number generator
* Vector           A Vector of pointers. 

�"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~�
