//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  FileReader.cpp
//
//  Implements a file reader stream.
//    (I know there are streams ready in the c++ library, but i perfer 
//     definig my own ones (providing a more beautiful overall))
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <stdio.h>
#include <malloc.h>
#include <string>
#include "../config.h"
#include "../memguard.h"

#include "../system/system.h"
#include "FileReader.h"

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::FileReader
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
FileReader::FileReader(const byte *s_filename, int32 s_mode)
{
  filename = s_filename;
  mode     = s_mode;
  file     = NULL;
  isopen   = false;
  iseof    = true;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::~FileReader
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
FileReader::~FileReader()
{
  if (isopen) {
    close();
  }
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::~FileReader
//
// Opens the file, and allocates the buffers.
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool FileReader::open()
{
  if (isopen) 
    return false;
  switch(mode) {
    case TEXT : 
        file = fopen(filename, "r");
        break;
    case BINARY : 
        file = fopen(filename, "rb");
        break;
  } 
  if (file == NULL) 
    return false;
  buf     = (byte *) malloc(FILE_READER_BUFFER, "FileReader.buf");
  bufsize = FILE_READER_BUFFER;
  isopen  = true;
  iseof   = false;

  if (buf == NULL) {
    close();
    return false;
  }
  return true;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::~close
//
// Closes the file
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void FileReader::close()
{
  if (!isopen) 
    return;
  isopen = false;
  fclose(file);
  file = NULL; // just to be safe
  iseof = true;

  if (buf != NULL) { // this test is necessary
    free(buf);       // since if initial start malloc failed the file will be close again
  }
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::readline
//
// Reads a line until next '\n' or EOF, the needed buffer is expanded if necessary.
// '\n','\r' are scrapped on lineend.
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
byte *FileReader::readline()
{
  if (!isopen) 
    return NULL;
  byte *asw = fgets(buf, bufsize, file);
  if ((asw == NULL) || (*asw == 0)) {
    iseof = true;
    return NULL;
  }
  while (buf[strlen(buf) - 1] != '\n') {
    // special case, the line was longer than the buffer!
    byte *oldbuf = buf;
    int32  oldsize = bufsize;
    buf = (byte *) realloc(buf, bufsize *=2); // double buffer size
    if (buf == NULL) {
      buf = oldbuf;
      iseof = true;
      return NULL;
    }
    asw = fgets(buf + strlen(buf), oldsize + 1, file);
    if ((asw == NULL) || (*asw == 0)) {
      iseof = true;
      return NULL;
    }
  }
  // cut away traling CR and LF's
  byte *c = &buf[strlen(buf) - 1];
  while ((*c == '\n') || (*c == '\r')) {
    *c-- = 0;    
    if (c < buf) {
      break;
    }
  }

  return buf;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::eof
//
// returns true if end of file has been reached or the file is closed.
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool FileReader::eof()
{
  return iseof;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::isOpen
//
// returns true if file is open.
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool FileReader::isOpen()
{
  return isopen;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::seek
//
// set's the filepointer to offset.
//
// returns true on success, otherwise false
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool FileReader::seek(unsigned int32 offset)
{
  int32 asw = fseek(file, offset, SEEK_SET);
  return asw == 0;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::read_uint32_little
//
// reads a 4 byte value. 
//
// Reads in little indian convetion.
// (assumes a little indian machinge right now)
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
unsigned int32 FileReader::read_uint32_little()
{
  unsigned int32 asw = 0;
  if (fread(&asw, 4, 1, file) != 1) {
    System::panic("IO-Error");
  }
  return asw;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::readLongBig
//
// reads a 4 byte value. 
//
// Reads in little indian convetion.
// (assumes a little indian machinge right now)
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
unsigned int32 FileReader::read_uint32_big()
{
  unsigned int32 asw = 0;
  if (fread(&asw, 4, 1, file) != 1) {
    System::panic("IO-Error");
  }
  asw = ((asw & 0xFF000000) >> 24) |
        ((asw & 0x00FF0000) >>  8) |
        ((asw & 0x0000FF00) <<  8) |
        ((asw & 0x000000FF) << 24);
  return asw;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::read_uint16_little
//
// reads a 2 byte value. 
//
// Reads in little indian convetion.
// (assumes a little indian machinge right now)
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
unsigned int16 FileReader::read_uint16_little()
{
  unsigned int16 asw = 0;
  if (fread(&asw, 2, 1, file) != 1) {
    System::panic("IO-Error");
  }
  return asw;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::readWordBIf
//
// reads a 2 byte value. 
//
// Reads in bif indian convetion.
// (assumes a little indian machinge right now)
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
unsigned int16 FileReader::read_uint16_big()
{
  unsigned int16 asw = 0;
  if (fread(&asw, 2, 1, file) != 1) {
    System::panic("IO-Error");
  }
  return (((asw & 0xFF00) >> 8) | ((asw & 0x00FF) << 8));
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::read_sint16_little
//
// reads a 2 byte value. 
//
// Reads in little indian convetion.
// (assumes a little indian machinge right now)
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
signed int16 FileReader::read_sint16_little()
{
  unsigned int16 asw = 0;
  if (fread(&asw, 2, 1, file) != 1) {
    System::panic("IO-Error");
  }
  return asw;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::read_sint16_big
//
// reads a 2 byte value. 
//
// Reads in bif indian convetion.
// (assumes a little indian machinge right now)
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
signed int16 FileReader::read_sint16_big()
{
  unsigned int16 asw = 0;
  if (fread(&asw, 2, 1, file) != 1) {
    System::panic("IO-Error");
  }
  return (((asw & 0xFF00) >> 8) | ((asw & 0x00FF) << 8));
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::read_byte
//
// reads a single unsigned byte
//
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
unsigned byte FileReader::read_byte()
{
  /*byte asw = 0;
  if (fread(&asw, 1, 1, file) != 1) {
    System::panic("IO-Error");
  }
  return asw;
  */
  return fgetc(file);
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::read_int8
//
// reads a single signed byte
//
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
signed int8 FileReader::read_sint8()
{
  /*byte asw = 0;
  if (fread(&asw, 1, 1, file) != 1) {
    System::panic("IO-Error");
  }
  return asw;
  */
  return fgetc(file);
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// FileReader::pos
//
// reads file position
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
unsigned int32 FileReader::pos()
{
  return ftell(file);
}
