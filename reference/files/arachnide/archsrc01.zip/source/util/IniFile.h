//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  IniFile.h
//
//  The INI configuration file, special feature is that the reader remembers
//  exact structure of the file, so it can be resynthesized on write back.
//  (The application also saved it's settings inside it)
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __INI_FILE_H__
#define __INI_FILE_H__

class FileReader;
class StringHashtable;
class Vector;

class IniFile {
  private : 
    const byte *filename;
    FileReader *reader;
    StringHashtable *hash; // quick find entries
    Vector     *lines;

    byte * tokenStart(byte *str);

  public :
    IniFile(const byte *filename);
    ~IniFile();
    bool open();
    void close();

    const byte *getString(const byte *command, const byte *defval);
    bool getBoolean(const byte *command, bool defval);
    int32 getInteger(const byte *command, int32 defval);
};

#endif