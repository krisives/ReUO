//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  HugeHashtable.cpp
//
//  Implements the favorite hashtable algorithm with two paired long integer keys,
//  This table is special tailored to the needs of the Cache, it requieres Object's 
//  as values, and uses the hash_entry member-variable to quickly reverse find values.
//
//  It uses a double-sized table, where in the lower half the hash codes are entered
//  and in the upper half collision are chained.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <malloc.h>
#include <stdio.h>
#include "../config.h"
#include "../memguard.h"

#include "../objects/Object.h"
#include "../system/Console.h"
#include "../system/System.h"
#include "HugeHashtable.h"
#include "Prime.h"

#define INVALID        0xFFFFFFFF

#define HASH(x1, x2, size)        ((x1 ^ x2) % size)    
      // is the most lousy hash algorithm of all :o(
#define DEFAULT_SIZE   HASH_DEFAULT_SIZE
#define LOAD_FACTOR    HASH_LOAD_FACTOR
#define HASH_ENTRY     HUGE_HASH_ENTRY


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// HugeHashtable::HugeHashtable
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
HugeHashtable::HugeHashtable()
{
  tabsize   = DEFAULT_SIZE;
  tabsize_2 = DEFAULT_SIZE * 2;
  used    = 0;
  valve   = (unsigned int32) (tabsize * LOAD_FACTOR);
  table   = (HASH_ENTRY *) malloc(tabsize_2 * sizeof(HASH_ENTRY), "HugeHashtable.table");
  cpos    = tabsize;
  for(unsigned int32 l = 0; l < tabsize_2; l++) {
    table[l].key1   = INVALID;
    table[l].next   = 0;
    table[l].before = 0;
  }

#ifdef PROFILE_HASHTABLE
  puts       = 0;
  collisions = 0;
  rehashes   = 0;
#endif
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// HugeHashtable::~HugeHashtable
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
HugeHashtable::~HugeHashtable()
{
  free(table);
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// HugeHashtable::put
//
// Add an entry into the hashtable.
//
// unsigned long key  - the key value
// void * value       - a general purpose pointer / variable
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void HugeHashtable::put(unsigned int32 key1, unsigned int32 key2, Object* value)
{
#ifdef SANE
  if (key1 == INVALID) {
    System::panic("Hashtable: invalid hashkey");
  }
#endif
  
/*
  //extreme paranoica
  for(unsigned int i = 0; i < tabsize_2; i++) {
    if ((table[i].key1 == key1) && (table[i].key2==key2)) {
      //System::panic("Hashtable, paranoid failure");
      i = i;
    }
  }
  */

  unsigned int32 hash = HASH(key1, key2, tabsize);

#ifdef PROFILE_HASHTABLE
    puts++;  
#endif

  if (++used >= valve) {
    rehash();
    hash = HASH(key1, key2, tabsize);
  }
    
  unsigned int32 hpos = hash;
  if(table[hpos].key1 != INVALID) {
#ifdef PROFILE_HASHTABLE
      collisions++;  
#endif
#ifdef SANE
    if ((table[hpos].key1 == key1) &&
        (table[hpos].key2 == key2)) {
      System::panic("Hashtable: Overwriting an existing entry");
    }
#endif
    // a collision occured
    // get an entry from collision table
    while (table[cpos].key1 != INVALID) {
      if (++cpos >= tabsize_2) {
        cpos = tabsize;
      }
    }
    // go til end of the collision chain
    while (table[hpos].next != 0) {
      hpos = table[hpos].next;
    }
    table[hpos].next   = cpos;

    table[cpos].key1   = key1;
    table[cpos].key2   = key2;
    table[cpos].value  = value;
    table[cpos].next   = 0;
    table[cpos].before = hpos;

    value->hash_entry = cpos;    
    return;
  }
  // phew...no collisions
  table[hpos].key1   = key1;
  table[hpos].key2   = key2;
  table[hpos].value  = value;
  table[hpos].next   = 0;
  table[hpos].before = 0;
  value->hash_entry  = hpos;    
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// HugeHashtable::get
//
// Receive an entry.
//
// unsigned long key  - the key value
//
// returns            - the value found, or 
//                      NULL if the key doesn't exist.
//                      Note: You can put NULL values has value in the table,
//                            but then you cannot distinguish between not found 
//                            entries
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
Object *HugeHashtable::get(unsigned int32 key1, unsigned int32 key2)
{
#ifdef SANE
  if (key1 == INVALID) {
    System::panic("Hashtable: invalid hashkey");
  }
#endif

  unsigned int32 hash = HASH(key1, key2, tabsize);

  for(;;) {
    if ((table[hash].key1 == key1) &&
        (table[hash].key2 == key2)) {
      return table[hash].value;
    } 
    hash = table[hash].next;
    if (hash == 0) {
      return NULL;
    }
  }
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// HugeHashtable::remove
//
// Remove an entry by value.
//
// returns true if the entry is found and removed. or false if it doesn't exist.
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void HugeHashtable::remove(Object *value)
{
  unsigned int32 hpos   = value->hash_entry;
  unsigned int32 before = table[hpos].before;
  unsigned int32 next   = table[hpos].next;
#ifdef SANE
  if (table[hpos].value != value) {
    System::panic("Hashtable reverse entries corrupt");
  }
  value->hash_entry = -1;
#endif
  if (before != 0) {
    // this is an list entry
    table[before].next = next;
  }
  table[hpos].key1 = INVALID;
  if (next != 0) {
    // this is an list entry not at the listend
    if (hpos < tabsize) {
      // a root entry is removed.
      // the last table has to be moved, so the root is valid again.
      table[hpos].next  = table[next].next;
      if (table[next].next != 0) {
        table[table[next].next].before = hpos;
      }
      //table[next].before = hpos;
      table[hpos].key1  = table[next].key1;
      table[hpos].key2  = table[next].key2;
      table[hpos].value = table[next].value;
      table[hpos].value->hash_entry = hpos;
      table[next].key1  = INVALID;
    } else {
      // removing a middle in list entry.
      table[next].before = before;
    }
  }
  used--;
} 

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// HugeHashtable::rehash
//
// Doubles the size of the hashtable and recalculates all keys. Called 
// automatic by put() when the number of entries reach a 
// hazardous level (LOAD_FACTOR)
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void HugeHashtable::rehash()
{
  unsigned int32 oldsize   = tabsize;
  unsigned int32 oldsize_2 = tabsize_2;
  // calculate new table size (next higher prime number to double size)
  tabsize   = Prime::nextPrime(tabsize * 2);
  tabsize_2 = tabsize * 2;
  cpos      = tabsize;
  used      = 0;
  HASH_ENTRY *oldtable = table;
  // allocate new table
  table  = (HASH_ENTRY *) malloc(tabsize_2 * sizeof(HASH_ENTRY), "HugeHashtable.table");
  valve   = (unsigned int32) (tabsize * LOAD_FACTOR);
  // Initialize the new table to INVALID values
  for(unsigned int32 l = 0; l < tabsize_2; l++) {
    table[l].key1 = INVALID;
    table[l].before = 0;
    table[l].next   = 0;
  }
  for (unsigned int32 i = 0;i < oldsize_2; i++) {
    if ((oldtable[i].key1 == 0x03000000) && (oldtable[i].key2 == 0xc8)) {
       i = i;
    }
    if (oldtable[i].key1 != INVALID) {
      put(oldtable[i].key1, oldtable[i].key2, oldtable[i].value);
    }
  }
  // free old table
  free(oldtable);
#ifdef PROFILE_HASHTABLE
  rehashes++;  
#endif
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// LongHashtable::relief
//
// Resets the table, AND free's all childs pointed by value!
// (So better be sure it are valid pointers *grins*)
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void HugeHashtable::relief()
{
  for(unsigned int32 i = 0; i < tabsize; i++) {
    if (table[i].key1 != INVALID) {
      delete table[i].value;
      table[i].key1 = INVALID;
    }
  }
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// HugeHashtable::isEmpty
//
// returns true is the table is empty
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool HugeHashtable::isEmpty()
{
  return used > 0;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// HugeHashtable::size
//
// returns the number of entries
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
unsigned int32 HugeHashtable::size()
{
  return used;
}

#ifdef PROFILE_HASHTABLE
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// LongHashtable::profile
//
// Print the table profile to stdout.
//
// byte * name - The name of the table. 
//               (used the recognize it for humans in the output)
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void HugeHashtable::profile(byte * name)
{
  Console::printf("Hashtable (long) profile: %s\n", name);
  Console::printf("  size       %6d\n",  (int32) tabsize);
  Console::printf("  used       %6d\n",  (int32) used);
  Console::printf("  puts       %6d\n",  (int32) puts);
  Console::printf("  collisions %6d\n",  (int32) collisions);
  Console::printf("  rehashes   %6d\n",  (int32) rehashes);
  Console::printf("  ratio         %6.2f%%\n",  (100.0f * collisions) / puts);
}



#endif
