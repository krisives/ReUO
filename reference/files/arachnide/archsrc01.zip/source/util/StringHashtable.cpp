//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  StringHashtable.cpp
//
//  Implements the favorite hashtable algorithm for string keys
//  (Search for objects from keys)
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <malloc.h>
#include <stdio.h>
#include <string>
#include "../config.h"
#include "../memguard.h"

#include "../system/system.h"
#include "StringHashtable.h"
#include "Prime.h"

#define DEFAULT_SIZE   HASH_DEFAULT_SIZE
#define LOAD_FACTOR    HASH_LOAD_FACTOR
#define HASH_ENTRY     STRING_HASH_ENTRY

#define HASH(x, size)        crossSum(x, size)    // yes, this is also a very lousy hash algorithm.... 

unsigned int32 crossSum(const byte *c, unsigned int32 size) {
  unsigned int32 sum = 0;
  while (*c != 0) {
    sum = (sum + *(unsigned byte *)(c)++) % size;
  }
  return sum;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// StringHashtable::StringHashtable
//
// Initialize an hashtable
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
StringHashtable::StringHashtable()
{
  tabsize = DEFAULT_SIZE;
  used    = 0;
  valve   = (unsigned int32) (tabsize * LOAD_FACTOR);
  table   = (HASH_ENTRY *) malloc(tabsize * sizeof(HASH_ENTRY), "StringHashtable.table");
  for(unsigned int32 l = 0; l < tabsize; l++) {
    table[l].key = NULL;
  }

#ifdef PROFILE_HASHTABLE
  puts       = 0;
  collisions = 0;
  rehashes   = 0;
#endif
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// StringHashtable::~StringHashtable
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
StringHashtable::~StringHashtable()
{
  // free the table keys
  for(unsigned int32 i = 0; i < tabsize; i++) {
    if (table[i].key != NULL) {
      free(table[i].key);
    }
  }
  // free the table itself
  free(table);
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// StringHashtable::put
//
// Add an entry into the hashtable.
//
// unsigned long key  - the key value
// void * value       - a general purpose pointer / variable
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void StringHashtable::put(const byte *key, void * value)
{
  unsigned int32 hash = HASH(key, tabsize);

#ifdef PROFILE_HASHTABLE
    puts++;  
#endif
  if (++used >= valve) {
    rehash();
    hash = HASH(key, tabsize);
  }
  
  while (table[hash].key != NULL) {    
    if (!strcmp(table[hash].key, key)) {
      break;
    }
    if (++hash >= tabsize) {
      hash = 0;
    }
#ifdef PROFILE_HASHTABLE
    collisions++;  
#endif
  }

  // create a copy of the key, so the original string can be modified 
  // without affecting the hashtable
  byte *keyclone = (byte *) malloc(strlen(key) + 1, "StringHashtable.keyclone");
  strcpy(keyclone, key);
  table[hash].key   = keyclone;
  table[hash].value = value;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// StringHashtable::get
//
// Receive an entry.
//
// key    - the key value
//
// returns            - the value found, or 
//                      NULL if the key doesn't exist.
//                      Note: You can put NULL values has value in the table,
//                            but then you cannot distinguish between not found 
//                            entries
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void *StringHashtable::get(const byte *key)
{
  unsigned int32 hash = HASH(key, tabsize);

  for(;;) {
    if (table[hash].key == NULL) {
      return 0;
    }
    if (!strcmp(table[hash].key, key)) {
      return table[hash].value; 
    }
    hash++;
  }
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// StringHashtable::rehash
//
// Doubles the size of the hashtable and recalculates all keys. Called 
// automatic by put() when the number of entries reach a 
// hazardous level (LOAD_FACTOR)
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void StringHashtable::rehash()
{
  // calculate new table size (next higher prime number to double size)
  unsigned int32 newsize = Prime::nextPrime(tabsize * 2);
  // allocate new table
  HASH_ENTRY *newtable  = (HASH_ENTRY *) malloc(newsize * sizeof(HASH_ENTRY), "StringHashtable.table");
  // Initialize the new table to INVALID values
  for(unsigned int32 l = 0; l < newsize; l++) {
    newtable[l].key = NULL;
  }

  for (unsigned int32 i = 0;i < tabsize; i++) {
    if (table[i].key != NULL) {
      unsigned int32 hash = HASH(table[i].key, newsize);
      while (newtable[hash].key != NULL) {
        // no need to check for duplicates
        if (++hash >= newsize) {
          hash = 0;
        }
      }
      newtable[hash].key   = table[i].key;
      newtable[hash].value = table[i].value;
    }
  }
  // free old table
  free(table);
  // assign new table to current
  table   = newtable;
  tabsize = newsize;
  valve   = (unsigned int32) (newsize * LOAD_FACTOR);
#ifdef PROFILE_HASHTABLE
  rehashes++;  
#endif
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// StringHashtable::relief
//
// Resets the table, AND free's all childs pointed by value!
// (So better be sure it are valid pointers *grins*)
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void StringHashtable::relief()
{
  for(unsigned int32 i = 0; i < tabsize; i++) {
    if (table[i].key != NULL) {
      free(table[i].value);
      table[i].key = NULL;
    }
  }
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// StringHashtable::isEmpty
//
// returns true is the table is empty
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool StringHashtable::isEmpty()
{
  return used > 0;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// StringHashtable::size
//
// returns the number of entries
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
unsigned int32 StringHashtable::size()
{
  return used;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// StringHashtable::first
//
// Receives the first entry in the table.
//   This is has not to be the first entry added to the list!
//   It's a complete random one. 
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void* StringHashtable::first()
{
  seq_pos = 0;
  return next();
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// StringHashtable::next
//
// Receives the next entry in the table. 
//   (first() has to be called before this function)
//   The is no pariticular order the entries are received.
//
// returns the next element or NULL if on end of list
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void* StringHashtable::next()
{
  for(unsigned int32 i = seq_pos; i < tabsize; i++) {
    if (table[i].key != NULL) {
      seq_pos = i + 1;
      return table[i].value;
    }
  }  
  return NULL;
}

#ifdef PROFILE_HASHTABLE
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// StringHashtable::profile
//
// Print the table profile to stdout.
//
// byte * name - The name of the table. 
//               (used the recognize it for humans in the output)

//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void StringHashtable::profile(byte * name)
{
  printf("Hashtable (string) profile: %s\n", name);
  printf("  size       %6d\n",  (int32) tabsize);
  printf("  used       %6d\n",  (int32) used);
  printf("  puts       %6d\n",  (int32) puts);
  printf("  collisions %6d\n",  (int32) collisions);
  printf("  rehashes   %6d\n",  (int32) rehashes);
  printf("  ratio         %6.2f%%\n",  (100.0f * collisions) / puts);
}



#endif
