//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Creature.h
//
//  A creature, is any of these:
//   * the player
//   * other players
//   * npc's
//   * animals
//   * monsters
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __CREATURE_H__
#define __CREATURE_H__

class Sprite;
#include "../Vision/VRect.h"

class Creature {
  public :
    unsigned int32 x;
    unsigned int32 y;
    int32 z;

    unsigned int32 body;
    unsigned int32 dir;
    Sprite *sprite;   // this is just a temporary variable used in the ScreenRenderer
                      // you may not use or access it somewhere else!
    bool hasclip;
    VRect lastclip;
};

#endif