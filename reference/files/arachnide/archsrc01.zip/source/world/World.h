//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// World.h
//
// Arachnides mirror of the world. This world is the one displayed to the user and
// gets synchronized by the network with the world existing on the server.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __WORLD_H__
#define __WORLD_H__

class StaticBlock;
struct StaticCell;
class WorldBlock;
class Creature;
struct WorldCell;

#define UP     0
#define NORTH  1
#define RIGHT  2
#define EAST   3
#define DOWN   4
#define SOUTH  5
#define LEFT   6
#define WEST   7

class World {
  private :
    static StaticCell *  getStaticCell(int32 x, int32 y);

  public :
    static bool initialize(IniFile *config);
    static void finalize();
    static bool upandrun;

    static Creature **creatures;
    static unsigned int32 ncreature;

    static WorldBlock *createWorldBlock(unsigned int32 id);
    static void walk_creature(unsigned int32 c, unsigned int32 dir);

    enum {
      END_OF_LIST = 0,
      SKIP_CELL,
      MAP_CELL,
      STATIC_CELL,
    };
};


#endif