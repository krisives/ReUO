//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  World.cpp
//
// Arachnides mirror of the world. This world is the one displayed to the user and
// gets synchronized by the network with the world existing on the server.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <string>
#include "../config.h"
#include "../memguard.h"

#include "../fission/MapFission.h"
#include "../fission/TiledataFission.h"
#include "../map/MapBlock.h"
#include "../map/StaticBlock.h"
#include "../map/StaticCell.h"
#include "../map/Tiledata.h"
#include "../objects/ObjectMan.h"
#include "../system/system.h"
#include "Creature.h"
#include "Walking.h"
#include "World.h"
#include "WorldBlock.h"
#include "WorldCell.h"

#define MAX(x,y) (x < y ? y : x)
#define MIN(x,y) (x < y ? x : y)

bool           World::upandrun = false;
Creature **    World::creatures;
unsigned int32 World::ncreature;

// compare two cells an determine which has drawin priority.
// this is done as macro, to relief the sorting alogorithm 
// to see this implemenation specific stuff
/*
#define COMPARE_CELLS(ca, cb) (                                \
             (ca.z  > cb.z) ||                                 \
           ( (ca.z == cb.z) && (cb.flags & FLAG_FLOOR) &&      \
             (!(ca.flags & FLAG_WALKABLE) && (ca.type != MAP_CELL))       \
           )                                                   \
        )
        */
#define COMPARE_CELLS(ca, cb) (                                                    \
             (ca.z + ca.height  > cb.z + cb.height) ||                             \
           ( (ca.z + ca.height == cb.z + cb.height) && ((ca.flags & FLAG_FLOOR))   \
           )                                                                       \
        )

bool World::initialize(IniFile *config) 
{
  ncreature = 1;
  creatures = (Creature **) malloc(1 * sizeof(Creature *), "World.creatures");
  creatures[0] = new Creature;
  creatures[0]->x    = 1472;
  creatures[0]->y    = 1650;
  creatures[0]->z    = 0;
  //creatures[0]->body = 0x3B;
  creatures[0]->body = 0x190;
  creatures[0]->dir  = DOWN;
  creatures[0]->hasclip = false;
  creatures[0]->lastclip.u = 0;
  creatures[0]->lastclip.d = 0;
  creatures[0]->lastclip.r = 0;
  creatures[0]->lastclip.l = 0;

  //northern edge
  //curx = 20;
  //cury = 20;
  //britatin center
  creatures[0]->x = 1472;
  creatures[0]->y = 1650;
  //dungeon entrance
  //curx = 1296;
  //cury = 1081;

  //southern edga
  //creatures[0]->x = 6084;
  //creatures[0]->y = 4076;
  //somewhere in t2a  
  //curx = 668 * 8 - 60;
  //cury = 412 * 8 - 20;

  //snow platform
  //curx = 5161;
  //cury = 2395;
  upandrun = true;
  return true;
}


void World::finalize() 
{
  for(unsigned int32 i = 0; i < ncreature; i++) {
    delete creatures[i];
  }
  delete creatures;
  upandrun = false;
}

WorldBlock *World::createWorldBlock(unsigned int32 id)
{
  WorldBlock  *wblock = new WorldBlock;
  StaticBlock *sblock = ObjectMan::get_static_block(id);
  MapBlock    *mblock = ObjectMan::get_map_block(id); 

  unsigned int32 ty = (id % 512) * 8;
  unsigned int32 tx = (id / 512) * 8;

  for(unsigned int32 x = 0; x < 8; x++) {
    for(unsigned int32 y = 0; y < 8; y++) {
      if ((tx +x == 1481) && (ty +y == 1647)) {
        x = x;
      }
      unsigned int32 si = 0;
      StaticCell *s =  sblock->cells[x][y];
      MapCell *m    = &mblock->cells[x][y];
      if (s != NULL) {
        while (s[si].id != 0xffffffff) {
          si++;
        }
      }
      unsigned int32 wp = 0; // world cell pointer, incremental array progress
      wblock->cells[x][y] = (WorldCell *) malloc((si + 2) * sizeof(WorldCell), "WorldBlock.cell");
      WorldCell *w  =  wblock->cells[x][y];
      WorldCell t;
      w[wp].type  = MAP_CELL;
      unsigned int32 id = w[wp].id = m->id;
      w[wp].z     = m->z;
      signed int32 height = MAX(m->hl, m->hr);
      int32 dif = (height - 44) >> 2;
      w[wp].height = 0;
      if (dif > 0) {
        w[wp].z -= dif;
      }

      Tiledata *tiledata = TiledataFission::get_map_tiledata(id);
      w[wp].flags = tiledata->flags;
      w[wp].transparent = tiledata->transparent;
      TiledataFission::release();
      wp++;
      unsigned int32 i, j;
      for (i = 0; i < si; i++) {
        unsigned int32 id = w[wp].id = s[i].id;
        w[wp].type  = STATIC_CELL;
        w[wp].z     = s[i].z;
        w[wp].transparent = 0;
        Tiledata *tiledata = TiledataFission::get_static_tiledata(id);
        w[wp].flags = tiledata->flags;
        w[wp].height = tiledata->height;
        TiledataFission::release();
        wp++;
      }

      for (i = 0; i < wp; i++) {
        for (j = i + 1; j < wp; j++) {
          if (COMPARE_CELLS(w[i], w[j])) {
            memcpy((void *) &t,    (void *) &w[i], sizeof(WorldCell));
            memcpy((void *) &w[i], (void *) &w[j], sizeof(WorldCell));
            memcpy((void *) &w[j], (void *) &t,    sizeof(WorldCell));
          }
        }
      }

      /*
      for (i = 1; i < wp; i++) {
        Tiledata *ti = ObjectMan::getTiledata(w[i].id);
        if (ti->isroof()) {
          w[i].type = SKIP_CELL;
        }
        ti->release();
      }
      */
      wblock->cells[x][y][wp].type   = END_OF_LIST;
    }
  }
  
  mblock->release();
  sblock->release();    
  return wblock;
}

void World::walk_creature(unsigned int32 c, unsigned int32 dir)
{
  unsigned int32 newx = creatures[0]->x;
  unsigned int32 newy = creatures[0]->y;

  switch (dir) {
    case UP    : newx--; newy--; break;
    case NORTH :         newy--; break;
    case RIGHT : newx++; newy--; break;
    case EAST  : newx++;         break;
    case DOWN  : newx++; newy++; break;
    case SOUTH :         newy++; break;
    case LEFT  : newx--; newy++; break;
    case WEST  : newx--;         break;
  }

  int32 newz = Walking::walk(newx, newy, creatures[0]->z);
  if (newz > -128) {
    creatures[0]->x = newx;
    creatures[0]->y = newy;
    creatures[0]->z = newz;
    creatures[0]->dir = dir;
  }
}