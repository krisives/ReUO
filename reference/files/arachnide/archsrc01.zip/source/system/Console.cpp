//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Console.cpp
//
//  Controll's arachnide's console
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include "../config.h"
#include "../memguard.h"

#include "Console.h"
#include "System.h"
#include "../util/IniFile.h"

byte   Console::buffer[PRINTF_MAX_BUFFER];
bool   Console::upandrun = false;
bool   Console::logging;
FILE * Console::file;


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Console::initialize
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool Console::initialize(IniFile *config)
{
  logging = config->getBoolean("LOG CONSOLE", true);

  if (logging) {
    file = fopen("console.log", "w");
  }
  //if (config->getBoolean("CONSOLE", false)) {    
  //  activate_console();
  //}
  upandrun = true;
  return true;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Console::finalize
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void Console::finalize()
{
  if (logging) {
    fclose(file);
  }
  upandrun = false;
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Console::printf
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void __cdecl Console::printf(const byte *format, ...)
{ 
  va_list args;

#undef int
  va_start(args, format);
  _vsnprintf(buffer, PRINTF_MAX_BUFFER - 1, format, args);
  va_end(args);
#define int ERROR

  if (logging) {
    fputs(buffer, file);
    fputs("\n", file);
  } 
  System::console(buffer);
}

