�"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~�
  /system
�"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~�

In these subdirectories for every supported system a class
provides an interface for all platform indepentand special's.

MessageBox
Network

currently supported Systems:
- Win32     32-bit Windows

(Okay that was all, but it will be certantly more in future :) (hopefully)

�"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~~"~�
