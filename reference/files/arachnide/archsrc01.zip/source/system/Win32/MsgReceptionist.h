//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Console.cpp
//
//  Win32 - Console interface. This console spawns a new process, and 
//  communicates with it using a pipe.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __CONSOLE_MSG_RECEPTIONIST_H__
#define __CONSOLE_MSG_RECEPTIONIST_H__

struct SDL_mutex;
struct SDL_cond;

class MsgReceptionist {
  private:
    bool  running;
    bool  finished;
    int32 hpipe;

    SDL_mutex *msg_mutex;
    SDL_mutex *msg_handled_mutex;
    SDL_cond  *msg_handled;

    struct message {
      int32         status;  
      unsigned int8 msg_id;
      byte          text[256];
    } message;

    enum {
     IDLE,     // Waiting for a message to be received
     AVIABLE,  // Message is received and ready to be handled
    };

    void pipeBroke();

  public :
    MsgReceptionist();
    ~MsgReceptionist();

    bool start(int32 hpipe);
    void stop(int32 hsender);
    bool aviable();
    unsigned int8 receive(byte *text);
    void run();
};

#endif