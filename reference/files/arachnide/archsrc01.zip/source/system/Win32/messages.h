//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  messages.h
//
//  Win32 - Defines the messages handled between the arachnide main application and
//  it's console
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __CONSOLE_MESSAGES_H__
#define __CONSOLE_MESSAGES_H__

// Given as paramter, to check no one dares to call the console alone.
// (and to check possible version mismatches)
#define CALL_ID "ARACHNIDE_0_1_CONSOLE_SUBPROCESS_REQUEST"


#define WAIT_FOR_HANDSHAKE  5   // Seconds to wait for console to answer 
                                // welcome handshake

#define MSG_HELLO_CONSOLE   0   // After spawning first message send to console
#define MSG_GOODBYE_CONSOLE 1   // Master is going to shutdown. (console is supposed to follow)
#define MSG_POST            2   // Show string on screen
                                // Is followed by a character defining the length of text.
                                // Then the textmessage follows
      

#define MSG_HELLO_MASTER    100 // Answer from HELLO_CONSOLE message
#define MSG_POST_CONFIRM    102

#define MSG_TIMEOUT         200 // A timeout occured
#define MSG_STOP            250 // Stop the receiver thread
#define MSG_IO_ERROR        254 // The pipe is broken.
#define MSG_INVALID         255

#endif