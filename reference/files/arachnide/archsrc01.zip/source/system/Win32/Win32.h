//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Win32.h
//
//  Platform dependant stuff for 32-bit windows.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __WIN32_H__
#define __WIN32_H__

class Consio;
class IniFile;

class Win32 {
  private :
    static Consio *consio;    
    static bool    console_active;
    static bool    keep_console;
    static byte    buffer[PRINTF_MAX_BUFFER];
    static byte    pbuffer[PRINTF_MAX_BUFFER]; 

  public :
    static bool initialize(IniFile *config);
    static void finalize();
    static bool upandrun;

    static void __cdecl message(const byte *format, ...);
    static void __cdecl panic(const byte *format, ...);
    static void console(const byte *text);
    static void cycle();
    static void activate_console();
    static void sleep(unsigned int32 time);
};

#endif