//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  MsgReceptionist.cpp
//
//  Win32 - Console-IO Message receiver.
//          This classes uses multi-threading to read messages coming
//          in from the console.
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <io.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>
#include "../../Sdl/SDL.h"
#include "../../Sdl/SDL_thread.h"
#include "../../config.h"
#include "../../memguard.h"

#include "MsgReceptionist.h"
#include "messages.h"

#undef int
int thread_starter(void *data) 
{
  ((MsgReceptionist *) data)->run();
  return 0;
}
#define int ERROR


MsgReceptionist::MsgReceptionist()
{
  running  = false;
  finished = false;
}

MsgReceptionist::~MsgReceptionist()
{
  if (running) {
    // Panic
  }
}

bool MsgReceptionist::start(int32 s_hpipe)
{
  if (running) {
    return false();
  }
  hpipe = s_hpipe;
 
  msg_mutex         = SDL_CreateMutex();
 
  msg_handled_mutex = SDL_CreateMutex();
  msg_handled       = SDL_CreateCond();

  SDL_CreateThread(thread_starter, this);
  return true;
}

void MsgReceptionist::stop(int32 hsender)
{
  running = false;
  // wait for the thread to be finished
  unsigned byte msgid = MSG_STOP;
  write(hsender, &msgid, 1);
  msgid = receive(NULL);
  while (!finished) {
    Sleep(100);
  }
  SDL_DestroyMutex(msg_mutex);
  SDL_DestroyMutex(msg_handled_mutex);
  SDL_DestroyCond(msg_handled);
}

void MsgReceptionist::pipeBroke() 
{
  SDL_mutexP(msg_mutex);
  message.msg_id = MSG_IO_ERROR;
  message.status = AVIABLE;
  SDL_mutexV(msg_mutex);
  running = false;
}


void MsgReceptionist::run() 
{
  running = true;
  byte text[256];
  while (running) {
    unsigned byte msg_id;
    int32 count  = read(hpipe, &msg_id, 1);
    if (count == -1) {
      pipeBroke();
      break;
    }

    if (msg_id == MSG_POST) {
      unsigned byte len;
      count = read(hpipe, &len, 1);
      if (count == -1) {
        pipeBroke();
        break;
      }
      count = read(hpipe, text, len);
      if (count == -1) {
        pipeBroke();
        break;
      }      
      text[len] = 0;
    }

    // Set the received value in the message handler
    SDL_mutexP(msg_mutex);
    message.msg_id = msg_id;
    message.status = AVIABLE;
    if (msg_id == MSG_POST) {
      strcpy(message.text, text);
    } else {
      *message.text  = 0;
    }
    SDL_mutexV(msg_mutex);
    // Wait for main routine to handle the message
    SDL_mutexP(msg_handled_mutex);
    SDL_CondWait(msg_handled, msg_handled_mutex);
    // Up again to next turn   
  }
  finished = true;
}

bool MsgReceptionist::aviable() 
{
  SDL_mutexP(msg_mutex);
  bool asw = message.status == AVIABLE;
  SDL_mutexV(msg_mutex);
  return asw;
}

unsigned int8 MsgReceptionist::receive(byte *text) 
{  
  SDL_mutexP(msg_mutex);
  if (message.status != AVIABLE) {
    // No message avialbe, so wait's for one.
    SDL_mutexV(msg_mutex);   // first unlock the mutex
    time_t start;
    time(&start); // remember time from start;
    for(;;) {
      Sleep(50);             // wait
      SDL_mutexP(msg_mutex); // and peek again
      if (message.status == AVIABLE) {
        break;
      }
      // no luck, unlock again
      SDL_mutexV(msg_mutex);
      time_t now;
      time(&now); // remember time from start;
      if (difftime(now, start) > WAIT_FOR_HANDSHAKE) {
        // timeout occured
        return MSG_TIMEOUT;
      }
    }
  }
  
  if ((message.msg_id == MSG_POST) && (text != NULL)) {
    strcpy(text, message.text);
  }
  message.status = IDLE;
  
  SDL_mutexV(msg_mutex);
  
  SDL_CondSignal(msg_handled);
  return message.msg_id;
}