//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Win32.cpp
//
//  Platform dependant stuff for 32-bit windows.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <windows.h>
#include <winuser.h>
#include <winbase.h>
#include <string>
#include "../../config.h"
#include "../../memguard.h" 

#include "Win32.h"
#include "Consio.h"
#include "../../util/IniFile.h"

bool    Win32::upandrun       = false;
Consio *Win32::consio         = NULL;
bool    Win32::console_active = false;
bool    Win32::keep_console;         // keep the console after shutdown?


byte Win32::buffer[PRINTF_MAX_BUFFER];
byte Win32::pbuffer[PRINTF_MAX_BUFFER]; // the panic() routine may not use the same buffer
                                        // as the others.

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Win32::message
//
// Shows a message box.
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void __cdecl Win32::message(const byte *format, ...)
{
  va_list args;

  va_start(args, format);
  _vsnprintf(buffer, PRINTF_MAX_BUFFER - 1, format, args);
  va_end(args);

  MessageBox(NULL, buffer, "Arachnide", MB_OK);
}


//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Win32::panic
//
// Some fatal error occurs, and execution is stopped after a 
// message box with crash reason is showed of course.
//
// This spot is always ideal for a breakpoint :o)
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void __cdecl Win32::panic(const byte *format, ...)
{
  va_list args;

  va_start(args, format);
  _vsnprintf(pbuffer, PRINTF_MAX_BUFFER - 1, format, args);
  va_end(args);

  message("ARACHNIDE PANIC:\n%s", pbuffer);  
  exit(1);
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Win32::console
//
// Puts some string onto the console.
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void Win32::console(const byte *text)
{
  if (console_active) {  
    consio->message(text);
  }
  cycle();
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Win32::initialize
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
bool Win32::initialize(IniFile *config)
{
  consio = new Consio;
  upandrun = true;
  if (config->getBoolean("CONSOLE", false)) {    
    activate_console();
  }
  keep_console = config->getBoolean("KEEP CONSOLE", false);
  return true;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Win32::activate_console
//
// Acitivates the windows console if the configuration files desires it.
// 
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void Win32::activate_console()
{ 
  if (consio->initialize()) {
    console_active = true;
  }
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Win32::finalize
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void Win32::finalize()
{
  if (console_active) {  
    if (!keep_console) {    
      consio->finalize(false);
    } else {      
      consio->flush();
      consio->finalize(true);
    }
    console_active = false;
  }
  upandrun = false;
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Win32::cycle
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void Win32::cycle()
{
  consio->cycle();
}

//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
// Win32::sleep
//
// Suspend processor
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
void Win32::sleep(unsigned int32 time)
{
  Sleep(time);
}