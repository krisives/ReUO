//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Consio.cpp
//
//  Win32 - Console interface. This console spawns a new process, and 
//  communicates with it using a pipe.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#include <stdlib.h>
#include <fcntl.h>
#include <io.h>
#include <process.h>
#include <time.h>
#include <windows.h>
#include "../../config.h"
#include "../../memguard.h"

#include "../system.h"
#include "../../util/Vector.h"
#include "Consio.h"
#include "MsgReceptionist.h"
#include "messages.h"

#define PIPE_READ   0
#define PIPE_WRITE  1

//Consio::upandrun = false;
 
Consio::Consio()
{
  init   = false;
  broken = true;
}

Consio::~Consio()
{
}


bool Consio::initialize()
{
  if (init) {
    return false;
  }
  broken = false;
  // open the pipe
  int32 asw;
#undef int
  asw = _pipe((int *) hpipe_out, 270, O_BINARY);
  if (asw == -1)
    return false;

  asw = _pipe((int *) hpipe_in,  270, O_BINARY);
  if (asw == -1)
    return false;
#define int ERROR
  
  byte hstr_out[20];
  byte hstr_in[20];
  byte hstr_outback[20];
  itoa(hpipe_out[PIPE_READ], hstr_out, 10);
  itoa(hpipe_in[PIPE_WRITE], hstr_in,  10);
  itoa(hpipe_out[PIPE_WRITE], hstr_outback, 10);

  broken = false;

  pid = _spawnl(_P_NOWAIT, "console.exe", "console.exe", CALL_ID, hstr_out, hstr_in, hstr_outback, NULL);
  if (pid < 0) {
    return false;
  }

  recept = new MsgReceptionist();
  recept->start(hpipe_in[PIPE_READ]);

  send(MSG_HELLO_CONSOLE, NULL);

  // Wait for console to answer welcome requests
  unsigned byte msgid = recept->receive(NULL);

  if (msgid != MSG_HELLO_MASTER) {
    System::message("Console handshake-fault: Bad answer.");
    return false;
  }

  msg_pos   = 0;
  msg_count = 0;
  msg_wait  = false;
    
  init = true;
  messages = new Vector;
  //upandrun = true;
  return true;
}

void Consio::finalize(bool keep)
{
  if (!init) {
    return;
  }
  if (!keep) {
    send(MSG_GOODBYE_CONSOLE, NULL);
    flush();
  }

  init = false;
  recept->stop(hpipe_in[PIPE_WRITE]);
  delete recept;
  close(hpipe_in[PIPE_WRITE]);
  close(hpipe_in[PIPE_READ]);
  close(hpipe_out[PIPE_WRITE]);
  close(hpipe_out[PIPE_READ]);
  for (unsigned int32 i = msg_pos; i < messages->size(); i++) {
    free((byte *) messages->elementAt(i));
  }
  delete messages;
  broken = true;
  //upandrun = false;
}

void Consio::send(unsigned int8 msgid, const byte *text)
{
  if (broken) {
    return;
  }
  int32 asw = write(hpipe_out[PIPE_WRITE], &msgid, 1);
  if (asw != 1) {
    System::message("Console disabled: Pipe broken");
    broken = true;
    return;
  }
  if (text != NULL) {
    unsigned int32 textlen = strlen(text);
    msgid = (int8) textlen;
    asw = write(hpipe_out[PIPE_WRITE], &msgid, 1);
    if (asw != 1) {
      System::message("Console disabled: Pipe broken");
      broken = true;
      return;
    }
    
    asw = write(hpipe_out[PIPE_WRITE], text, textlen);
    if (asw != (int32) textlen) {
      System::message("Console disabled: Pipe broken");
      broken = true;
      return;
    }
  }
}

void Consio::message(const byte *text)
{
  if (broken) {
    return;
  }
  byte *buf = (byte *) malloc(strlen(text) + 1, "message.buf");
  strcpy(buf, text);
  messages->append((void *) buf);
  msg_count++;
  cycle();
}

void Consio::flush()
{
  while ((msg_count > 0) && (!broken)) {
    cycle();
  }
}

void Consio::cycle()
{
  if (broken) {
    return;
  }
  if (msg_wait) {
    time_t now;
    time(&now);
    if (recept->aviable()) {
      unsigned int8 msgid = recept->receive(NULL);
      if (msgid == MSG_TIMEOUT) {
        broken = true;
        System::message("Console disabled: Timeout");     
      } else if (msgid == MSG_POST_CONFIRM) {
        msg_count--;
        if (msg_count > 0) {
          byte *text = (byte *) messages->elementAt(msg_pos++);
          send(MSG_POST, text);
          free(text);
          time(&tstart);
        } else {
          msg_pos = 0;
          messages->reset();
          msg_wait = false;
        }
      } else {    
        broken = true;
        System::message("Console disabled: Illegal post answer");
      }
      return;
    } else if ((difftime(now, tstart) > 5)) {
      broken = true;
      System::message("Console disabled: timeout");
    }
  } else {
    if (msg_count > 0) {
      byte *text = (byte *) messages->elementAt(msg_pos++);
      send(MSG_POST, text);
      time(&tstart);
      free(text);
      msg_wait = true;
    }
  }
}