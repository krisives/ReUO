//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//  Consio.h
//
//  Win32 - Console interface. This console spawns a new process, and 
//  communicates with it using two pipe's.
//
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
//
//  Arachnide. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

#ifndef __CONSOLE_IO_H__
#define __CONSOLE_IO_H__

//typedef int32 time_t;

class MsgReceptionist;
class Vector;

class Consio {
  private:
    bool init;    
    bool broken;
    int32 hpipe_out[2];
    int32 hpipe_in[2];
    int32 pid;

    MsgReceptionist *recept;
    Vector *messages;
    int32 msg_pos;
    int32 msg_count;
    bool msg_wait;
    time_t tstart;

    void send(unsigned int8 msgid, const byte *text);

  public :
    Consio();
    ~Consio();

    bool initialize();
    void finalize(bool keep);
    void cycle();
    void flush();
    void message(const byte *text);
};

#endif