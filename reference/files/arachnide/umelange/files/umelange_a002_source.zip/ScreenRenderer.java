//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.util.*;
import java.awt.*;
import java.awt.image.*;

//  Programmers compass rose:
//  -------------------------------------------------
//
//  screen Y-Axis
//
//  A             
//  |            
//  |                         Up (u) 
//  |                           A
//  |                           |
//  |           West (w)        |         North (n) 
//  |                   �.   .--+--.   ,� 
//  |                     �.�   |   `,� 
//  |                     / �.  |  ,� \ 
//  |                    |    �.|,�    |
//  |    Left (l) <------+------X------+--------> Right (r)
//  |                    |     ,|.     |
//  |                     \  ,� | �.  / 
//  |                      ,�   |   �.
//  |                    ,�  �--+--�  �.
//  |           South (s)       |       � East (e)
//  |                           |
//  |                           V
//  |                       Down (d)
//  |
//  |
//  +-------------------------------------------------------> screen X-Axis
//
//             I hope it also looks nicely on your screen ;)
//
//                     - knoxos


public class ScreenRenderer implements ImageProducer {		
 static final int rawlen[]  = { 2, 4, 6, 8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,
                               44,42,40,38,36,34,32,30,28,26,24,22,20,18,16,14,12,10, 8, 6, 4, 2};
 static final int rawoffs[] = {21,20,19,18,17,16,15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,
                                0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,20,21};

 GameWindow gameWindow;
 ColorModel model;
 int[] pixels;
 int[] foreGround;
 int pixeloffset;
 int pixelscan;
 Hashtable properties;
 Vector theConsumers;
 boolean animating;
 boolean fullbuffers;
 // special variables
 public Sprite aSprite = null;
 public Sprite whispSprite = null;
 int scrollerX  = 0;
 int scrollerY  = 0;  
 public Vector runTiles = new Vector();
 
 private boolean    clearScreen; // clear the screen between frames.
 private boolean    showBall; // clear the screen between frames.
 private CacheDemon cacheDemon;  
 private MapWindow  mapWindow;
   
 static final int screenPreviewRight = 616;
 static final int screenPreviewLeft  = -87;
 static final int screenPreviewDown  = 440;
 static final int screenPreviewUp    = -87;
 
 static final int screenWidth       = 640;
 static final int screenHeight      = 480;
 static final int screenSize        = 640*480;

 static final int bufferWidth       = 640*2;
 static final int bufferHeight      = 480*2;
 static final int bufferWidthMin1   = bufferWidth - 1;
 static final int bufferWidthPlus1  = bufferWidth + 1;
 static final int bufferSize        = (bufferWidth)* (bufferHeight );
 //static final int bufferBorder      = (bufferWidth)* (bufferHeight - 1);
 //static final int bufferBorder      = (bufferWidth)* (bufferHeight) - bufferWidth;
 static final int bufferBorder      = (bufferWidth)* (bufferHeight);
 static final int screenShiftX      = -15;
 static final int screenShiftY      = 2;

 int offset     = (bufferSize - screenSize) / 2;
  

 public ScreenRenderer(ColorModel colormodel, int setPixels[], 
                       GameWindow setGameWindow, 
                       CacheDemon setCacheDemon, 
                       MapWindow setMapWindow,
                       boolean setClearScreen,
                       boolean setShowBall) 
 {
   cacheDemon = setCacheDemon;
   theConsumers = new Vector();
   gameWindow = setGameWindow;
   mapWindow  = setMapWindow;
   showBall   = setShowBall;
   model = colormodel;
   pixels = setPixels;
   pixeloffset = 0;
   pixelscan = bufferWidth;
   clearScreen = setClearScreen;
   properties = new Hashtable();
   //initialize(colormodel, setPixels, 0, bufferWidth, null);
   foreGround = new int[(screenWidth * 2) * (screenHeight * 2)];
   //whispSprite = cacheDemon.getRunSprite(14078, bufferWidth);
   whispSprite = cacheDemon.getRunSprite(14001, bufferWidth);
 }

/**
 * Adds an ImageConsumer to the list of consumers interested in
 * data for this image.
 */
 public synchronized void addConsumer(ImageConsumer ic) 
 {
   if (theConsumers.contains(ic)) 
     return;
   theConsumers.addElement(ic);
   try {
     initConsumer(ic);
     sendPixels(ic, 0, 0, screenWidth, screenHeight);
     if (isConsumer(ic)) {
       ic.imageComplete(animating? ImageConsumer.SINGLEFRAMEDONE
				 : ImageConsumer.STATICIMAGEDONE);
       if (!animating && isConsumer(ic)) {
	 ic.imageComplete(ImageConsumer.IMAGEERROR);
	 removeConsumer(ic);
       }
     }
   } catch (Exception e) {
     if (isConsumer(ic)) 
       ic.imageComplete(ImageConsumer.IMAGEERROR);
   }
 }

 private void initConsumer(ImageConsumer imageconsumer) 
 {
   // knoxos: don't ask me why this is done so strange...
   //         I asume the consumer can cancel it's membership at any point.    
   if(isConsumer(imageconsumer))
     imageconsumer.setDimensions(screenWidth, screenHeight);
   if(isConsumer(imageconsumer))
     imageconsumer.setProperties(properties);
   if(isConsumer(imageconsumer))
     imageconsumer.setColorModel(model);
   if(isConsumer(imageconsumer))
     imageconsumer.setHints(animating ? fullbuffers ? 6 : 1 : 30);      
 }

 public synchronized boolean isConsumer(ImageConsumer imageconsumer)
 {
   return theConsumers.contains(imageconsumer);
 }

 public void newPixels()
 {
   int bpos = offset;
   int fpos = 0;
   
   if (clearScreen) {
     for (int i = 0; i < bufferSize; i++)
       foreGround[i] = 0x0000FF;        
   }
  
   int currentX = gameWindow.currentX;
   int currentY = gameWindow.currentY;
   MapBlock cBlock = cacheDemon.getMapBlockOfRawTile(currentX,currentY,true);
   MapCell cCell = cBlock.cells[currentX % 8][currentY % 8];   
   int currentHeight = cCell.height;
   int hshift = -currentHeight / 44;
   //int curShiftX = screenShiftX - currentHeight / 22;
   //int curShiftY = screenShiftY - currentHeight / 22;
   //IntegerRef ch = new IntegerRef();
   int orgX = (currentX - currentY) * 22 + scrollerX + (screenShiftX - screenShiftY)*22 + 88;
   int orgY = (currentX + currentY) * 22 + scrollerY + (screenShiftX + screenShiftY)*22 + 88;
   for (int y = hshift - 2; y < 20 + hshift; y++) {
   //{int y = 8;
     for (int odd = 0; odd <=1; odd++) { 
     //{int odd = 0;
       int tileX = currentX + y + odd + screenShiftX;
       int tileY = currentY + y + screenShiftY;
       for (int x = 0; x < 19; x++) {    	
       //{int x = 0; 
         int screenX = (tileX-tileY)*22 - orgX;
         int screenY = (tileX+tileY)*22 - orgY + currentHeight;
         //int screenX = 150;
         //int screenY = 150;
         if ((tileX >= 0) && (tileY >= 0) && (tileX < 768*8)  && (tileY < 512*8)) {
           MapCell cell = cacheDemon.getMapCell(tileX, tileY, true);              
           int len = cell.hl < cell.hr ? cell.hr : cell.hl;
           
           //if ((tileX!=currentX) || (tileY!=currentY)) {
           if ((screenX < screenWidth) && 
               (screenX > -44) &&
               (screenY + len - cell.height > 0) && 
               (screenY - cell.height < screenHeight)) {
             if ((cell.hr == 44) && (cell.hl == 44) && (cell.stl == 22) && (cell.str == 22)) {
               RawTile tile = cacheDemon.getRawTile(cell.id);
               addRawTile(screenX,  screenY - cell.height, tile);
             } else {
               Sprite sprite = cacheDemon.getRawSprite(cell, bufferWidth);
               if (sprite != null)
                 drawSprite(screenX,  screenY - cell.height , sprite);
             }
           } 
           StaticCell sCell = cacheDemon.getStaticCell(tileX, tileY);
           for (int j = 0; j < sCell.tiles.length; j++) {
             StaticParticle sp = sCell.tiles[j];
             if (sp.sprite == null) {
               sp.sprite = cacheDemon.getRunSprite(sp.id, bufferWidth);
             }
             int spx = screenX - sp.sprite.width / 2 + 22;
             //spx = screenX;
               drawSprite(spx, screenY - sp.h - sp.sprite.height + 44, sp.sprite);
           }
           /*} else {
             StaticCell sCell = cacheDemon.getStaticCell(tileX, tileY);
             for (int j = 0; j < sCell.tiles.length; j++) {
               StaticParticle sp = sCell.tiles[j];
               //System.out.println(cacheDemon.getStaticTileData(sp.id));
             }
           }*/
           if ((tileX == currentX) && (tileY == currentY) && (showBall)) {
             cell = cacheDemon.getMapCell(tileX, tileY , true);
             drawSprite(screenX + scrollerX, screenY - cell.height + scrollerY - 66, whispSprite);
           }       
             
         } //else {
           //eraseRawTile(screenX, screenY , 0);	
         //}
         tileX++; // move to right        
         tileY--; 
       }
     }
   }
   /*
   for (int y = 0; y < screenHeight; y++) {
     System.arraycopy(pixels, bpos, foreGround, fpos, screenWidth);
     bpos += bufferWidth;
     if (bpos > bufferBorder) { // wrap
       bpos -= bufferBorder;
     }
     fpos += screenWidth * 2;
   }
   */

    /*
    //drawSprite(                    10 , aSprite);
    int cx = gameWindow.currentX;
    int cy = gameWindow.currentY;  
    for (Enumeration en = runTiles.elements(); en.hasMoreElements();) {
      RunTile aRunTile = (RunTile) en.nextElement();   
      int px = aRunTile.x - cx;
      int py = aRunTile.y - cy;
      int sx = (px - py) * 22 - scrollerX;
      int sy = (px + py) * 22 - scrollerY - aRunTile.h * 4;
      if ((sx > -aRunTile.sprite.width) && (sy > -aRunTile.sprite.height) &&
          (sx < screenWidth + aRunTile.sprite.width) && (sy < screenHeight + aRunTile.sprite.height))
      drawSprite(sx + sy*(screenWidth * 2), aRunTile.sprite);      
    }
    */
   newPixels(0, 0, screenWidth, screenHeight, true);
 }
  
  protected void drawSprite(int x, int y, Sprite sprite) 
  {
    // insert a sprite
    int data[] = sprite.data;
    int run[]  = sprite.run;
    int runpos = 0;
    boolean level = false;
    int bpos = 0;
    int fpos = x + y * bufferWidth;   
    int runby = -1;    
    runby = run[runpos++];
    if (runby == 0) {
      level = true;
      runby = run[runpos++];
    }
    while (runby != 0) {
      if (!level) {
        fpos+=runby;
        level = true;
      } else {      	
      	if (fpos + runby >= bufferSize)
      	  break;      	
      	if (fpos > 0)
      	  System.arraycopy(data, bpos, foreGround, fpos, runby);
        fpos+=runby;      	
        bpos+=runby;
        level = false;
      }      
      runby = run[runpos++];
    } 
  }

 public synchronized void newPixels(int i, int j, int k, int l, boolean flag)
 {
   if (animating) {
     if(fullbuffers) {
       i = j = 0;
       k = screenWidth;
       l = screenHeight;
     } else {
       if (i < 0) {
         k += i;
         i = 0;
       }
       if(i + k > screenWidth)
         k = screenWidth - i;
       if(j < 0) {
         l += j;
         j = 0;
       }
       if(j + l > screenHeight)
         l = screenHeight - j;
     }
     if((k <= 0 || l <= 0) && !flag)
       return;
     for(Enumeration enumeration = theConsumers.elements(); enumeration.hasMoreElements();) {
       ImageConsumer imageconsumer = (ImageConsumer)enumeration.nextElement();
       if(k > 0 && l > 0)
         sendPixels(imageconsumer, i, j, k, l);
       if(flag && isConsumer(imageconsumer))
         imageconsumer.imageComplete(2);
     }
   }
 }

 public synchronized void removeConsumer(ImageConsumer imageconsumer)
 {
   theConsumers.removeElement(imageconsumer);
 }

 public void requestTopDownLeftRightResend(ImageConsumer imageconsumer)
 {
   // nothing
 }

 private void sendPixels(ImageConsumer imageconsumer, int x, int y, int w, int h)
 {
   //int i1 = pixeloffset + pixelscan * j + i; // was offset ??
   imageconsumer.setPixels(x, y, w, h, model, foreGround, 0, screenWidth * 2);
 }

/***
 *
 * Change this memory image into a multi-frame animation or a
 * single-frame static image depending on the animated parameter.
 * <p>This method should be called immediately after the
 * MemoryImageSource is constructed and before an image is
 * created with it to ensure that all ImageConsumers will
 * receive the correct multi-frame data.  If an ImageConsumer
 * is added to this ImageProducer before this flag is set then
 * that ImageConsumer will see only a snapshot of the pixel
 * data that was available when it connected.
 *
 * @param animated true if the image is a multi-frame animation
 *
 ***/
  public synchronized void setAnimated(boolean animated) {
    this.animating = animated;
    if (!animating) {
      Enumeration enum = theConsumers.elements();
      while (enum.hasMoreElements()) {
	ImageConsumer ic = (ImageConsumer) enum.nextElement();
	ic.imageComplete(ImageConsumer.STATICIMAGEDONE);
	if (isConsumer(ic)) {
          ic.imageComplete(ImageConsumer.IMAGEERROR);
        }
      }
      theConsumers.removeAllElements();
    }
  }

  public synchronized void setFullBufferUpdates(boolean flag)
  {
    if(fullbuffers == flag)
      return;
    fullbuffers = flag;
    if(animating) {
      ImageConsumer imageconsumer;
      for(Enumeration enumeration = theConsumers.elements(); enumeration.hasMoreElements(); imageconsumer.setHints(flag ? 6 : 1))
        imageconsumer = (ImageConsumer)enumeration.nextElement();
    }
  }

  public void startProduction(ImageConsumer imageconsumer)
  {
    addConsumer(imageconsumer);
  }
  
  // now some extensions ...
  public void eraseRawTile (int x, int y, int color) 
  {    
  }

  public void addRawTile (int x, int y, RawTile tile) 
  {    
    // erase if no tile
    if (tile==null)  {
      eraseRawTile(x,y,0);
      return;
    }
    //int pos  = offset + y*bufferWidth + x + 21;
    int pos  = y*bufferWidth + x + 22;
    int data[] = tile.data;
    int datapos = 0;
    for (int iy = 0; iy < 44; iy++) {
      int len = rawlen[iy];
      if (pos > 0)
        System.arraycopy(data, datapos, foreGround, pos, len);
      datapos += len;
      if (iy <22) {
        pos += bufferWidth - 1; // moves down a row and a col left
      } else {
        pos += bufferWidth + 1; // moves down a row and a col right
      }            
    }
  }
        
  public void scroll(int scrollX, int scrollY) 
  {
    //offset += scrollX + scrollY*bufferWidth;
    scrollerX += scrollX;
    scrollerY += scrollY;
    // scroll to right
    while (scrollerX >= 44) {
       if (gameWindow.currentX < 768*8 - 1)
         gameWindow.currentX++;   
       if (gameWindow.currentY > 0)
         gameWindow.currentY--;   
       scrollerX -= 44;
    }
    while (scrollerX <= -44) {
      if (gameWindow.currentX > 0)
        gameWindow.currentX--;
      if (gameWindow.currentY < 512 * 8 - 1)
        gameWindow.currentY++;
      scrollerX += 44;
    }
    while (scrollerY >= 44) {
      if (gameWindow.currentX < 768 * 8 - 1)
        gameWindow.currentX++;
      if (gameWindow.currentY < 512 * 8 - 1)
        gameWindow.currentY++;
      scrollerY -= 44;;
    }
    while (scrollerY <= -44) {
      if (gameWindow.currentX > 0)
        gameWindow.currentX--;
      if (gameWindow.currentY > 0)
        gameWindow.currentY--;
      scrollerY += 44;;
    }
  }  
}

