//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.io.*;
import java.util.*;

/***
 * Read/Write options to a ini file
 ***/  
class IniFile {   
  private String    fileName = null;
  private Vector    options  = new Vector();
  private Hashtable hash     = new Hashtable();
   
  IniFile(String setFileName)  {
    fileName   = setFileName;
    File aFile = new File(fileName);
    if (!aFile.exists()) {
      System.out.println("FAILURE");       	
      System.out.println("ERROR: file " + fileName + " not found.");       	
      return;
    }
    try {
      FileReader reader = new FileReader(aFile);
      BufferedReader in = new BufferedReader(reader);
      String line;
parse_loop:
      for(int linepos = 0;; linepos++) {
        line = in.readLine();
        if (line==null)
          break;
        int linelen = line.length();
        int i = 0;
       	  
        // goto begin of statement
        int parampos = 0;
        for(;;i++) {
          if (i==linelen) {
            options.addElement(new Option(null, 0,  null, 0, -1, line, -1));
            continue parse_loop;	
          }
          if (line.charAt(i) != ' ') {
            parampos = i;
            break;
          }
        }
        if (line.charAt(i) == '=') { // equal before parameter
          System.out.println("FAILURE");
          System.out.println("SYNTAX ERROR in " + fileName + " in line " + linepos);
          options.addElement(new Option(null, 0,  null, 0, -1, line, -1));
          continue parse_loop;         		          
        }
        int valuepos = 0;
        int equalpos = -1;
        String param = null;
        String value = null;
        if (line.charAt(i) != '#') { // if not a comment only line          
          // goto equal sign
      	  for(;;i++) {
            if (i == linelen) { // end of line before '=' or '#'
              //param = line.substring(parampos,i).trim();
       	      //if (param.length() > 0) { 
              System.out.println("FAILURE");
       	      System.out.println("SYNTAX ERROR in " + fileName + " in line " + linepos);
              options.addElement(new Option(null, 0,  null, 0, -1, line, -1));
              continue parse_loop;         		
            }
            if (line.charAt(i) == '=') {
       	      equalpos = i;
       	      param = line.substring(parampos,i).trim();
       	      break;
       	    }       	      
       	  }
          // goto start of value
          i++;
          for(;;i++) {
            if (i==linelen) {
              System.out.println("FAILURE");
       	      System.out.println("SYNTAX ERROR in " + fileName + " in line " + linepos);
              options.addElement(new Option(null, 0,  null, 0, -1, line, -1));
              continue parse_loop;	
            }
            if ((line.charAt(i) == '=') || (line.charAt(i) == '#')) {
              System.out.println("FAILURE");
       	      System.out.println("SYNTAX ERROR in " + fileName + " in line " + linepos);
              options.addElement(new Option(null, 0,  null, 0, -1, line, -1));
              continue parse_loop;	
            }
            if (line.charAt(i) != ' ') {
              valuepos = i;
              break;
            }
          }
          for(;;i++) {
            if (i == linelen) { // end of line 
       	      value = line.substring(valuepos,i).trim();
              options.addElement(new Option(param, parampos, value, valuepos, equalpos, null, 0));
              continue parse_loop;         		
            }
            if (line.charAt(i) == '#') {
       	      value = line.substring(valuepos,i).trim();
       	      break;
       	    }       	      
       	  }          
        }       	        	   
        // is there a comment?      
        int commentpos = 0;
        String comment = null;
        if (line.charAt(i) == '#') {
          commentpos = i;
          comment = line.substring(commentpos,line.length()).trim();                 	
          options.addElement(new Option(param, parampos, value, valuepos, equalpos, comment, commentpos));
          continue parse_loop;         		          
        }
        // this should never be reached
        System.out.println("FAILURE");
  	System.out.println("SYNTAX ERROR in " + fileName + " in line " + linepos);
        options.addElement(new Option(null, 0,  null, 0, -1, line, -1));
        continue parse_loop;	        
      }
      in.close();
      reader.close();
    } catch (IOException ex) {
      System.out.println("FAILURE");	
      System.out.println("IO ERROR: while reading " + fileName);       	
      return;
    }
    // now all lines are inside the options Vector, build a hashtable to find paramters quickly
    for(Enumeration en = options.elements(); en.hasMoreElements();) {
      Option option = (Option) en.nextElement();
      if (option.parameter != null) {
        hash.put(option.parameter.toUpperCase(), option);
      }       
    }            
    System.out.println("OK");       	
  }           
  
  String getParameter(String param) 
  {
    Option option = (Option) hash.get(param.toUpperCase());
    if (option == null)     
      return null;
    return option.value;
  }

  void setParameter(String param, String value) 
  {
    Option option = (Option) hash.get(param.toUpperCase());
    if (option == null) { 
      option = new Option(param, 0, value, param.length() + 2, param.length() + value.length() + 2, null, -1);
      options.addElement(option);
      hash.put(param.toUpperCase(), option);      
    } else {
      option.value = value;
    }
  }

  void flush() {
    try {
      File aFile = new File(fileName);
      FileWriter writer = new FileWriter(aFile);
      BufferedWriter out = new BufferedWriter(writer);
      for (Enumeration en = options.elements(); en.hasMoreElements();) {
        Option option = (Option) en.nextElement();
        out.write(option.generateLine()+"\r\n");
      } 
      out.close();
      writer.close();               
    } catch (IOException ex) {
      System.out.println("FAILURE");	
      System.out.println("IO ERROR: while writing " + fileName);       	
      return;
    }   
  }

  int getInteger(String param, int defaultValue) 
  {
    String sValue = getParameter(param);
    int iValue;
    if (sValue == null) {
      System.out.println("Paramater \"" + param + "\" is missing, supposing default: " + defaultValue);
      iValue = defaultValue;
      setParameter(param, String.valueOf(defaultValue));
      flush();
    } else {
      try {
        iValue = Integer.parseInt(sValue);
      } catch (NumberFormatException ex) {
        System.out.println("Paramater \"" + param + " is not a number, setting to default");
        iValue = defaultValue;
        setParameter(param , String.valueOf(defaultValue));
        flush();         
      }               
    } 
    return iValue;
  }

  boolean getBoolean(String param, boolean defaultValue) 
  {
    String sValue = getParameter(param);
    boolean bValue;
    if (sValue == null) {
      if (defaultValue)
        System.out.println("Paramater \"" + param + "\" is missing, supposing default: yes");
      else
        System.out.println("Paramater \"" + param + "\" is missing, supposing default: no");      
      bValue = defaultValue;
      setParameter(param, String.valueOf(defaultValue));
      flush();
    } else {
       char c = sValue.charAt(0);
       if ((c == 'N') || (c == 'n') || (c == 'f') || (c == 'F')) {
         bValue = false;
       } else if ((c == 'Y') || (c == 'y') || (c == 't') || (c == 'T')) {
         bValue = true;
       } else {
        if (defaultValue)
          System.out.println("Paramater \"" + param + "\" is missing, supposing default: yes");
        else
          System.out.println("Paramater \"" + param + "\" is missing, supposing default: no");      
        bValue = defaultValue;
        setParameter(param , " ");
        flush();         
      }               
    } 
    return bValue;
  }


}



/***
 * a class for IniFile only, hold per line info
 ***/   
 class Option {
   public String parameter  = null;
   public int    parampos   = 0;
   public String value      = null;
   public int    valuepos   = 0;
   public int    equalpos   = 0;
   public String comment    = null;   
   public int    commentpos = 0;
   
   Option() 
   { 
     // nothing
   };
   
   Option(String setParameter, int setParampos, 
          String setValue,     int setValuepos,
          int    setEqualpos,
          String setComment,   int setCommentpos)
   {
     parameter  = setParameter;
     parampos   = setParampos;
     value      = setValue;
     valuepos   = setValuepos;
     equalpos   = setEqualpos;
     comment    = setComment;
     commentpos = setCommentpos;
   }
   
   String generateLine() {
     StringBuffer buf = new StringBuffer();
     int pos;
     for (pos = 0; pos < parampos; pos++)
       buf.append(' ');      
     if (parameter!=null) {
       buf.append(parameter);
       pos += parameter.length();
     }
     for (; pos < equalpos; pos++)
       buf.append(' ');
     if (equalpos == pos) {
       buf.append('=');
       pos ++;
     }
     for (; pos < valuepos; pos++)
       buf.append(' ');
     if (value!=null) {
       buf.append(value);
       pos += value.length();
     } 
     for (; pos < commentpos; pos++)
       buf.append(' ');
     if (comment!=null) {
       buf.append(comment);
       pos += comment.length();
     }
     return buf.toString();       	
   }
               
 }