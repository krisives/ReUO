//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.awt.*;
import java.awt.image.*;
//import java.util.*;

/***
 *
 * Holds the data of a map block. 
 *
 ***/  
 class MapBlock {   
   /***
    * where to position the cells on screem
    ***/
   private static int cellPos[][][] = new int[8][8][2]; // 8x8 cells / [0]->x, [1]->y
   
   /***
    * The block id
    ***/
   public int id;
   
   /***
    * Is this block prepared?
    ***/   
   public boolean prepared = false;
   
   /***
    * Here the cell data is saved. <br>
    * 0..7 cells in x-coordinate <br>
    * 0..7 cells in y-coordinate <br>
    ***/
   public MapCell cells[][] = new MapCell[8][8]; 
   
   /***
    * 
    * Constructor: build the array data.
    *
    ***/                                              
   MapBlock() {
     for (int x=0; x < 8; x++)
       for (int y=0; y < 8; y++)
         cells[x][y] = new MapCell();        
   }
                                              
   /***
    * 
    * Builds the cellPos array.
    *
    ***/                                              
   public static void initialize() {
     for (int x=0; x<8; x++) {
       for (int y=0; y<8; y++) {
         cellPos[x][y][0] = 154 - (x - y) * 22;
         cellPos[x][y][1] = (x + y) * 22;
       }
     }
   }  
 }