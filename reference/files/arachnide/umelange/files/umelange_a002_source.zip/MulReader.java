//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.io.*;
import java.awt.*;
import java.awt.image.*;
//import java.util.*;

/** 
 * Read data from the '.mul' files
 ***/  
class MulReader {   
 public  final        int RUN_TILE_OFFSET = 16384;   
	   	
 private RandomAccessFile artDataFile     = null;
 private RandomAccessFile artIndexFile    = null;
 private RandomAccessFile staticDataFile  = null;
 private RandomAccessFile staticIndexFile = null;
 private RandomAccessFile mapFile         = null;
 private RandomAccessFile radarColorFile  = null;
 private RandomAccessFile tileDataFile    = null;
 private String artDataFileName           = null;
 private String artIndexFileName          = null;
 private String staticDataFileName        = null;
 private String staticIndexFileName       = null;
 private String mapFileName               = null;
 private String radarColorFileName        = null;
 private String tileDataFileName          = null;
                                
 MulReader(String uoPath) throws IOException {
   artDataFileName = uoPath + "art.mul";
   System.out.print("  ");
   System.out.print(artDataFileName);
   System.out.print(" ... ");
   artDataFile = new RandomAccessFile(artDataFileName,"r");     
   System.out.println(" OK ");
     
   artIndexFileName = uoPath + "artidx.mul";
   System.out.print("  ");
   System.out.print(artIndexFileName);
   System.out.print(" ... ");
   artIndexFile = new RandomAccessFile(artIndexFileName,"r");     
   System.out.println(" OK ");

   mapFileName = uoPath + "map0.mul";
   System.out.print("  ");
   System.out.print(mapFileName);
   System.out.print(" ... ");
   mapFile = new RandomAccessFile(mapFileName,"r");     
   System.out.println(" OK ");

   radarColorFileName = uoPath + "radarcol.mul";
   System.out.print("  ");
   System.out.print(radarColorFileName);
   System.out.print(" ... ");
   radarColorFile = new RandomAccessFile(radarColorFileName,"r");     
   System.out.println(" OK ");

   staticDataFileName = uoPath + "statics0.mul";
   System.out.print("  ");
   System.out.print(staticDataFileName);
   System.out.print(" ... ");
   staticDataFile = new RandomAccessFile(staticDataFileName,"r");     
   System.out.println(" OK ");
    
   staticIndexFileName = uoPath + "staidx0.mul";
   System.out.print("  ");
   System.out.print(staticIndexFileName);
   System.out.print(" ... ");
   staticIndexFile = new RandomAccessFile(staticIndexFileName,"r");     
   System.out.println(" OK ");

   tileDataFileName = uoPath + "tiledata.mul";
   System.out.print("  ");
   System.out.print(tileDataFileName);
   System.out.print(" ... ");
   tileDataFile = new RandomAccessFile(tileDataFileName,"r");     
   System.out.println(" OK ");
 }
   
 /***
  * called to free resources
  ***/
 public void close() {
    System.out.print("  ");
    System.out.print(artDataFileName);
    System.out.print(" ... ");      
    try {
      artDataFile.close();
      System.out.println("OK");
    } catch (IOException e) {
      System.out.println("Failure");
    }
    System.out.print("  ");
    System.out.print(artIndexFileName);
    System.out.print(" ... ");      
    try {
      artIndexFile.close();
      System.out.println("OK");
    } catch (IOException e) {
      System.out.println("Failure");
    }
    System.out.print("  ");
    System.out.print(mapFileName);
    System.out.print(" ... ");      
    try {
      mapFile.close();
      System.out.println("OK");
    } catch (IOException e) {
      System.out.println("Failure");
    }
    System.out.print("  ");
    System.out.print(staticDataFileName);
    System.out.print(" ... ");      
    try {
      staticDataFile.close();
      System.out.println("OK");
    } catch (IOException e) {
      System.out.println("Failure");
    }
    System.out.print("  ");
    System.out.print(staticIndexFileName);
    System.out.print(" ... ");      
    try {
      staticIndexFile.close();
      System.out.println("OK");
    } catch (IOException e) {
      System.out.println("Failure");
    }
 }
   
 public RawTile readRawTile(int id) 
 {
   RawTile aTile = new RawTile();     
   try {
     artIndexFile.seek(id*12);
     long index = (artIndexFile.readUnsignedByte()      ) + (artIndexFile.readUnsignedByte() <<  8) + 
                  (artIndexFile.readUnsignedByte() << 16) + (artIndexFile.readUnsignedByte() << 24);
      if (index == 0xFFFFFFFF) {
        System.out.println("ERROR: illlegal index of raw-tile read, id:" + id);
        return null;	
      }
      artDataFile.seek(index);       
      for (int i=0; i<RawTile.DATASIZE; i++) {
        int pixel16 = artDataFile.readUnsignedByte() + (artDataFile.readUnsignedByte() << 8);
        int pixel32 = (0xFF000000 |
                      ((((pixel16 >> 10) & 0x1F) * 0xFF / 0x1F) << 16) |
                      ((((pixel16 >> 5) & 0x1F) * 0xFF / 0x1F) << 8) |
                       ((( pixel16 & 0x1F) * 0xFF / 0x1F)));
        aTile.data[i] = pixel32;
      }              
    } catch (IOException e) {
      System.out.println("ERROR: IOException while reading tile in " + artDataFileName);
      System.exit(1);
    }  
    return aTile;   	     
  }
     
 /***
  * reads a MapBlock from map0.mul    
  *
  * @param id  id of the MapBlock to read.
  *
  * @return the MapBlock
  *
  ***/
 
 public MapBlock readMapBlock(int id) 
 {
    MapBlock mblock = new MapBlock();
    mblock.id = id;
    try {
      mapFile.seek(196 * id + 4); // 4 to skip unkown header
      for (int y=0; y<8; y++) {
        for (int x=0; x<8; x++) {
          mblock.cells[x][y].id     = mapFile.readUnsignedByte() + (mapFile.readUnsignedByte() << 8);
          mblock.cells[x][y].height = mapFile.readByte() * 4;
        }
      }                    
    } catch (IOException e) {
      System.out.println("ERROR: IO error in map0.mul");
      System.exit(0);
    }               
   return mblock;   	
 }

   public StaticBlock readStaticBlock(int id) 
   {
     long start = 0, llen = 0;     
     //int unkown = 0;
     int len = 0;
     int[][] cellcount = new int[8][8]; // how many tiles are in each block.
     for (int x = 0; x < 8; x++)
       for (int y = 0; y < 8; y++)
         cellcount[x][y] = 0;
       
     StaticBlock sBlock = new StaticBlock();
     sBlock.id = id;
     try {
      	staticIndexFile.seek(12*id); 
      	start = (long) staticIndexFile.readUnsignedByte() + (staticIndexFile.readUnsignedByte()  <<  8) + 
                (staticIndexFile.readUnsignedByte() << 16) + (staticIndexFile.readUnsignedByte() << 24);
      	llen  = (long) staticIndexFile.readUnsignedByte() + (staticIndexFile.readUnsignedByte()  <<  8) + 
                (staticIndexFile.readUnsignedByte() << 16) + (staticIndexFile.readUnsignedByte() << 24);
        staticIndexFile.readUnsignedByte();
        staticIndexFile.readUnsignedByte();
        staticIndexFile.readUnsignedByte();
        staticIndexFile.readUnsignedByte();
        len   = (int) (llen / 12); // knoxos: I don't think there will ever be more than 65535 tiles in a block ;)
        len   = (int) (llen / 7); 
     } catch (IOException e) {     //         (and even if, I don't care about those that will not be displayed)
       System.out.println("ERROR: IO error in static index file");
       System.exit(0);
     }   
     StaticParticle particles[] = null;  // save the tiles out of order in this array
     try {
       if (start == 0xFFFFFFFF) {
         sBlock.runCount = 0;
       } else {
         staticDataFile.seek(start);
         sBlock.runCount = len; 
         particles = new StaticParticle[len]; // save the tiles out of order in this array
         for (int i = 0; i < len; i++) {
           StaticParticle sparticle = new StaticParticle();
           sparticle.id = staticDataFile.readUnsignedByte() + (staticDataFile.readUnsignedByte() <<  8);
       	   int x = sparticle.x  = staticDataFile.readUnsignedByte();
       	   int y = sparticle.y  = staticDataFile.readUnsignedByte();
       	   cellcount[x][y]++; 
       	   sparticle.h  = staticDataFile.readByte() * 4;
           staticDataFile.readUnsignedByte();
           staticDataFile.readUnsignedByte();
       	   sparticle.flags = readStaticTileData(sparticle.id);
       	   
       	   particles[i] = sparticle;
         }            	
       }       
     } catch (IOException e) {
       System.out.println("ERROR: IO error in static data file");
       System.exit(0);
     }   
            
     // now sort the tiles into the cells
     StaticCell cells[][] = new StaticCell[8][8];
     for (int x = 0; x < 8; x++) {
       for (int y = 0; y < 8; y++) {
         StaticCell sCell = cells[x][y] = new StaticCell();
         sCell.tiles = new StaticParticle[cellcount[x][y]];
         int curcount = 0; // which tile of this cell
         for (int i = 0; i < len; i++) {
           if ((particles[i].x == x) && (particles[i].y == y))
             sCell.tiles[curcount++] = particles[i];
         }
       }
     }
     
     
     // now sort the tiles into by height 
     for (int x = 0; x < 8; x++) {
       for (int y = 0; y < 8; y++) {
         StaticCell sc = cells[x][y];        
         for (int i = 0; i < sc.tiles.length; i++) {
           for (int j = i + 1; j < sc.tiles.length; j++) {
             if (sc.tiles[i].h > sc.tiles[j].h) {
               StaticParticle buf = sc.tiles[i];
               sc.tiles[i] = sc.tiles[j];               
               sc.tiles[j] = buf;                               
             } else if (sc.tiles[i].h == sc.tiles[j].h) {
               if (sc.tiles[i].id < sc.tiles[j].id) {
                 StaticParticle buf = sc.tiles[i];
                 sc.tiles[i] = sc.tiles[j];               
                 sc.tiles[j] = buf;               
               }
             }               
           }
         }
       }
     }
     

     // now sort the tiles by priority
     for (int x = 0; x < 8; x++) {
       for (int y = 0; y < 8; y++) {
         StaticCell sc = cells[x][y];        
         for (int i = 0; i < sc.tiles.length; i++) {
           for (int j = i + 1; j < sc.tiles.length; j++) {
             //if ((((sc.tiles[i].flags & 0x01) == 0) && ((sc.tiles[j].flags & 0x01) != 0)) && (((sc.tiles[i].flags & 0x40) == 0x40) && ((sc.tiles[i].flags & 0xBE) == 0)) ) {
             if ((((sc.tiles[i].flags & 0x01) == 0) && ((sc.tiles[j].flags & 0x01) != 0)) && 
             
             ((((sc.tiles[i].flags & 0x40) == 0x40) && ((sc.tiles[i].flags & 0xBE) == 0)) && (((sc.tiles[j].flags & 0x40) == 0x40) && ((sc.tiles[j].flags & 0xBE) == 0)))) {
                 //System.out.print(".");
                 StaticParticle buf = sc.tiles[i];
                 sc.tiles[i] = sc.tiles[j];               
                 sc.tiles[j] = buf;               
             }
           }
         }
       }
     }
     
     sBlock.cells = cells;
     return sBlock;   	
   }
   
  public Sprite readRunSprite(int id, int bufWidth) 
  { 
     Sprite aSprite = new Sprite();
     try {
       artIndexFile.seek((RUN_TILE_OFFSET + id)*12);
       int index = (artIndexFile.readUnsignedByte()      ) + (artIndexFile.readUnsignedByte() <<  8) + 
                   (artIndexFile.readUnsignedByte() << 16) + (artIndexFile.readUnsignedByte() << 24);
       if (index == 0xFFFFFFFF) {
         System.out.println("ERROR: illlegal index of run-tile read, id:" + id);
         return null;	
       }
       artDataFile.seek(index + 4); // 4 to skip some header (size?)
       int width  = artDataFile.readUnsignedByte() + (artDataFile.readUnsignedByte() <<  8);
       int height = artDataFile.readUnsignedByte() + (artDataFile.readUnsignedByte() <<  8);
       //int nextLineLen = bufWidth - width;
       int lStart[] = new int[height];            
       int data[] = new int[width*height];
       int run[] = new int[height*height];
       for (int i=0; i< height; i++) {
       	 lStart[i] = artDataFile.readUnsignedByte() + (artDataFile.readUnsignedByte() <<  8);
       }
       long dStart = artDataFile.getFilePointer();
       int x = 0;
       int y = 0;
       int rpos = 0;
       int dpos = 0;
       boolean level = false;
       int len = 0;
       artDataFile.seek(dStart + lStart[y]*2); 
       while (y < height) {
         int xoffs = artDataFile.readUnsignedByte() + (artDataFile.readUnsignedByte() <<  8);
         int runby = artDataFile.readUnsignedByte() + (artDataFile.readUnsignedByte() <<  8);
         if (runby != 0) {
           if (level) 
             System.out.println("Error in readRunTile: invalid level");
           // goto foreground;
           level = true;
           run[rpos++] = len + xoffs;
           //if (x!=0) 
           //  x++;
           x += xoffs + runby;
           len = 0;   
           for (int i = 0; i < runby; i++) {
             int pixel16 = artDataFile.readUnsignedByte() + (artDataFile.readUnsignedByte() << 8);
             int pixel32 = (0xFF000000 |
                       ((((pixel16 >> 10) & 0x1F) * 0xFF / 0x1F) << 16) |
                       ((((pixel16 >> 5) & 0x1F) * 0xFF / 0x1F) << 8) |
                        ((( pixel16 & 0x1F) * 0xFF / 0x1F)));           	
             data[dpos++] = pixel32;
           }
           // goto background;
           level = false;
           run[rpos++] = runby ;
         } else {
           if (level) {
             System.out.println("Error in readRunTile: invalid level");
           }           	
           len += bufWidth - x;
           x = 0;
           y++;           
           if (y < height)
             artDataFile.seek(dStart + lStart[y]*2);
         }         
       }       
       run[rpos] = 0;
       aSprite.width  = width;
       aSprite.height = height;
       // cut down arrays to proper fit. (copy them)
       int fdata[] = new int[dpos + 1];
       int frun[]  = new int[rpos + 1];
       System.arraycopy(data, 0, fdata, 0, dpos + 1);
       System.arraycopy(run,  0, frun, 0,  rpos + 1);
  
       aSprite.data   = fdata;
       aSprite.run    = frun;
     } catch (IOException e) {
       System.out.println("ERROR: IOException while reading tile in " + artDataFileName);
       System.exit(1);
     }  
     return aSprite;	
  }
  
  
/*** 
 *
 * Reads the radar colors from radarcol.mul
 *
 ***/
 public int[] readRadarColors() 
 { 
   int colors[] = new int[65536];
   
   try {
     for (int i = 0; i < 65536; i++) {
       int pixel16 = radarColorFile.readUnsignedByte() + (radarColorFile.readUnsignedByte() << 8);
       colors[i] = (0xFF000000 |
                   ((((pixel16 >> 10) & 0x1F) * 0xFF / 0x1F) << 16) |
                    ((((pixel16 >> 5) & 0x1F) * 0xFF / 0x1F) << 8) |
                    ((( pixel16 & 0x1F) * 0xFF / 0x1F)));
     }
   } catch (IOException e) {
     System.out.println("ERROR: IOException while reading tile in " + radarColorFileName);
     System.exit(1);
   }  
   return colors;
 }  

/*** 
 *
 * Reads the tile data from tiledata.mul
 *
 ***/
 public byte readStaticTileData(int id) 
 { 
   int pos = 512*836 + (id >> 5) * 1188 + (id & 0x1F) * 37 + 4;   
   //                      / 32               % 32         // for dword
   byte u1 = 0;
   try {
     tileDataFile.seek(pos);   
     u1 = tileDataFile.readByte();
     /*
     tileDataFile.seek(pos + 17);   
     byte b = -1;
     StringBuffer name = new StringBuffer();
     while (b != 0) {
       name.append((char ) (b = tileDataFile.readByte()));
     }*/
     
     
     //System.out.println("ID:" + id + " u1:" + u1 + " Name:" + name);
   } catch (IOException e) {
     System.out.println("ERROR: IOException while reading " + tileDataFileName);
     System.exit(1);
   }  
   return u1;
 }  

}