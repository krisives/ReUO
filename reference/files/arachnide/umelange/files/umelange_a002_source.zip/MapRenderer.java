//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.util.*;
import java.awt.*;
import java.awt.image.*;
import java.math.*;

public class MapRenderer implements ImageProducer {
 ColorModel model;
 int[] pixels;
 int[] foreGround;
 int pixeloffset;
 int pixelscan;
 Hashtable properties;
 Vector theConsumers;
 boolean animating;
 boolean fullbuffers;
 // special variables
 Sprite aSprite = null;
 public Vector runTiles = new Vector();
 
 private CacheDemon  cacheDemon;  
 private MapWindow   mapWindow;
 private GameWindow  gameWindow;
 
 private int radarColors[];
 
 private int oldx = 0;
 private int oldy = 0;
 private boolean first = true;

 private int offset = 0;

 private int centerbuf[];
   
 static final int bufWidth          = 400;
 static final int bufHeight         = 400;
 static final int bufSize           = bufWidth * bufHeight;

 static final int screenWidth       = 200;
 static final int screenHeight      = 200;

 public MapRenderer(ColorModel colormodel, 
                    CacheDemon setCacheDemon,                     
                    MapWindow setMapWindow
                   ) 
 {
  cacheDemon  = setCacheDemon;
  mapWindow   = setMapWindow;
  radarColors = cacheDemon.getRadarColors();
  theConsumers = new Vector();
  model = colormodel;
  pixels = new int[bufWidth * bufHeight + 2];
  centerbuf = new int[6]; // buffer of the graphic behind the center point.
  properties = new Hashtable();
 }

/**
 * Adds an ImageConsumer to the list of consumers interested in
 * data for this image.
 */
 public synchronized void addConsumer(ImageConsumer ic) 
 {
   if (theConsumers.contains(ic)) 
     return;
   theConsumers.addElement(ic);
   try {
     initConsumer(ic);
     sendPixels(ic, 0, 0, screenWidth, screenHeight);
     if (isConsumer(ic)) {
       ic.imageComplete(animating? ImageConsumer.SINGLEFRAMEDONE
				 : ImageConsumer.STATICIMAGEDONE);
       if (!animating && isConsumer(ic)) {
	 ic.imageComplete(ImageConsumer.IMAGEERROR);
	 removeConsumer(ic);
       }
     }
   } catch (Exception e) {
     if (isConsumer(ic)) 
       ic.imageComplete(ImageConsumer.IMAGEERROR);
   }
 }

 private void initConsumer(ImageConsumer imageconsumer) 
 {
   // knoxos: don't ask me why this is done so strange...
   //         I asume the consumer can cancel it's membership at any point.    
   if(isConsumer(imageconsumer))
     imageconsumer.setDimensions(screenWidth, screenHeight);
   if(isConsumer(imageconsumer))
     imageconsumer.setProperties(properties);
   if(isConsumer(imageconsumer))
     imageconsumer.setColorModel(model);
   if(isConsumer(imageconsumer))
     imageconsumer.setHints(animating ? 
          (fullbuffers ? (ImageConsumer.TOPDOWNLEFTRIGHT | ImageConsumer.COMPLETESCANLINES) : ImageConsumer.RANDOMPIXELORDER) : 
          (ImageConsumer.TOPDOWNLEFTRIGHT | ImageConsumer.COMPLETESCANLINES | ImageConsumer.SINGLEPASS | ImageConsumer.SINGLEFRAME));
 }

 public synchronized boolean isConsumer(ImageConsumer imageconsumer)
 {
   return theConsumers.contains(imageconsumer);
 }

 public void loadMap(int curx , int cury)
 {  
   int newx = + curx + cury;       // knoxos: The equation seems somewhat strange, guess it's not quite right...
   int newy = - curx + cury;       //
   int dely = (newx - oldx) / 2;   //         I just guessed these equetions....
   int delx = (- newy + oldy) / 2; // 
   if ((delx == 0) && (dely == 0))
     return;

   // restore center
   int center = offset + (screenWidth / 2) + (screenHeight / 2) * bufWidth;
   center %= bufSize;
   int centerleft = center - 1;
   if (centerleft < 0)
     centerleft += bufSize;
   int centerright = center + 1;
   if (centerright > bufSize)
     centerleft -= bufSize;
     
   int centerup = center - 1;
   if (centerup < 0)
     centerup += bufSize;
   int centerdown = center + bufWidth;
   if (centerdown > bufSize)
     centerdown -= bufSize;     

   pixels[(center) ]                               = centerbuf[0];
   pixels[(center + bufSize - 1) % bufSize]        = centerbuf[1];
   pixels[(center + 1) % bufSize]                  = centerbuf[2];;
   pixels[(center + bufSize - bufWidth) % bufSize] = centerbuf[3];
   pixels[(center + bufWidth) % bufSize]           = centerbuf[4];

   if (!first)
     offset += (delx) + (dely) * bufWidth;
   while (offset < 0)
     offset += bufWidth * bufHeight;
   while (offset > bufWidth * bufHeight)
     offset -= bufWidth * bufHeight;
   
   int xstart;
   int xend;
   if (first || (Math.abs(delx) > (screenWidth / 4))) {
     xstart = 0;
     xend = screenWidth;    
     System.out.println("game : map teleport detected (x)");
   } else {   
     if (delx > 0) {
       xstart = screenWidth - delx;
       xend   = screenWidth;
     } else {
       xstart = 0;
       xend   = - delx;
     }     
   }
   int i = offset + xstart;
   int xlinefeed = bufWidth - (xend - xstart);
   
   for (int y = 0; y < screenHeight; y++, i+=xlinefeed) {
     for (int x = xstart; x < xend; x++, i++) {
       while (i >= bufWidth * bufHeight)
         i -= bufWidth * bufHeight;
       int px = x - screenWidth / 2;
       int py = y - screenHeight / 2 ; 
       int mapx = curx + px + py;
       int mapy = cury - px + py;
       
       if ((mapx > 0) && (mapx < 768 * 8) && (mapy > 0) && (mapy < 512 * 8)) {
         MapBlock aBlock = cacheDemon.getMapBlockOfRawTile(mapx, mapy, false);
         pixels[i] = radarColors[aBlock.cells[mapx % 8][mapy % 8].id];
       } else {
         pixels[i] = 0x0000FF;
       }
     }
   }  

   int ystart;
   int yend;
   if (first || (Math.abs(dely) > (screenHeight / 4))) {
     ystart = 0;
     yend = screenHeight;    
     System.out.println("game : map teleport detected (y)");
   } else {   
     if (dely > 0) {
       ystart = screenHeight - dely;
       yend   = screenHeight;
     } else {
       ystart = 0;
       yend   = - dely;
     }     
   }
   i = offset + ystart * bufWidth;
   xlinefeed = bufWidth - screenWidth;
   
   for (int y = ystart; y < yend; y++, i+=xlinefeed) {
     for (int x = 0; x < screenWidth; x++, i++) {
       while (i >= bufWidth * bufHeight)
         i -= bufWidth * bufHeight;
       int px = x - screenWidth / 2;
       int py = y - screenHeight / 2 ; 
       int mapx = curx + px + py;
       int mapy = cury - px + py;
       
       if ((mapx > 0) && (mapx < 768 * 8) && (mapy > 0) && (mapy < 512 * 8)) {
         MapBlock aBlock = cacheDemon.getMapBlockOfRawTile(mapx, mapy, false);
         pixels[i] = radarColors[aBlock.cells[mapx % 8][mapy % 8].id];
       } else {
         pixels[i] = 0x0000FF;
       }
     }
   }  
   center =  offset + (screenWidth / 2) + (screenHeight / 2) * bufWidth;
   center %= bufSize;
   centerleft = center - 1;
   if (centerleft < 0)
     centerleft += bufSize;
   centerright = center + 1;
   if (centerright > bufSize)
     centerleft -= bufSize;
     
   centerup = center - 1;
   if (centerup < 0)
     centerup += bufSize;
   centerdown = center + bufWidth;
   if (centerdown > bufSize)
     centerdown -= bufSize;     
     
   centerbuf[0] = pixels[center];
   centerbuf[1] = pixels[centerleft];
   centerbuf[2] = pixels[centerright];
   centerbuf[3] = pixels[centerup];
   centerbuf[4] = pixels[centerdown];

   pixels[center]        = 0x44FF44;
   pixels[centerleft]    = 0x22AA22;
   pixels[centerright]   = 0x22AA22;   
   pixels[centerup]      = 0x22AA22;
   pixels[centerdown]    = 0x22AA22;

   oldx = newx;
   oldy = newy;
   first = false;
   newPixels(0, 0, screenWidth, screenHeight, true);
 }  

/***
 *
 * Send a rectangular region of the buffer of pixels to any
 * ImageConsumers that are currently interested in the data for
 * this image.
 *
 * If the framenotify parameter is true then the consumers are
 * also notified that an animation frame is complete.
 * This method only has effect if the animation flag has been
 * turned on through the setAnimated() method.
 * If the full buffer update flag was turned on with the
 * setFullBufferUpdates() method then the rectangle parameters
 * will be ignored and the entire buffer will always be sent.
 *
 * @param x the x coordinate of the upper left corner of the rectangle
 * of pixels to be sent
 *
 * @param y the y coordinate of the upper left corner of the rectangle
 * of pixels to be sent
 *
 * @param w the width of the rectangle of pixels to be sent
 * @param h the height of the rectangle of pixels to be sent
 * @param framenotify true if the consumers should be sent a
 * SINGLEFRAMEDONE notification
 *
 ***/
 public synchronized void newPixels(int x, int y, int w, int h, boolean framenotify) {
   if (animating) {
     if (fullbuffers) {
       x = y = 0;
       w = screenWidth;
       h = screenHeight;
     } else {
       if (x < 0) {
         w += x;
         x = 0;
       }
       if (x + w > screenWidth) {
         w = screenWidth - x;
       }
       if (y < 0) {
         h += y;
         y = 0;
       }
       if (y + h > screenHeight) {
         h = screenHeight - y;
       }
     }
     if ((w <= 0 || h <= 0) && !framenotify) {
       return;
     }
     Enumeration enum = theConsumers.elements();
     while (enum.hasMoreElements()) {
       ImageConsumer ic = (ImageConsumer) enum.nextElement();
       if (w > 0 && h > 0) {
         sendPixels(ic, x, y, w, h);
       }
       if (framenotify && isConsumer(ic)) {
         ic.imageComplete(ImageConsumer.SINGLEFRAMEDONE);
       }
     }
   }
 }
    
  public synchronized void removeConsumer(ImageConsumer imageconsumer)
  {
    theConsumers.removeElement(imageconsumer);
  }

  public void requestTopDownLeftRightResend(ImageConsumer imageconsumer)
  {
    // nothing
  }

  private void sendPixels(ImageConsumer imageconsumer, int x, int y, int w, int h)
  {
    int pos  = (x + y*bufWidth) + offset;
    int size = (w + h*bufWidth);
    if (pos + size < bufWidth * bufHeight) { // normal send
      imageconsumer.setPixels(x, y, w, h, model, pixels, offset, bufWidth);
    } else {
      // send with wrap around.
      int sizeupper         = bufWidth * bufHeight - pos;       // how much is left on end of buffer?
      int sizeupperLines    = (sizeupper / bufWidth);           // how much whole lines is left on the buffer            
      int sizeupperLastLine = (sizeupper % bufWidth);           // how long is last line on the buffer            
      
      imageconsumer.setPixels(x, y, w, sizeupperLines, model, pixels, offset, bufWidth);
      // one line still missing.       
      imageconsumer.setPixels(x, y + sizeupperLines, w, h - sizeupperLines, model, pixels, bufWidth - sizeupperLastLine, bufWidth);
    }
  }

/***
 *
 * Change this memory image into a multi-frame animation or a
 * single-frame static image depending on the animated parameter.
 * <p>This method should be called immediately after the
 * MemoryImageSource is constructed and before an image is
 * created with it to ensure that all ImageConsumers will
 * receive the correct multi-frame data.  If an ImageConsumer
 * is added to this ImageProducer before this flag is set then
 * that ImageConsumer will see only a snapshot of the pixel
 * data that was available when it connected.
 *
 * @param animated true if the image is a multi-frame animation
 *
 ***/
  public synchronized void setAnimated(boolean animated) {
    this.animating = animated;
    if (!animating) {
      Enumeration enum = theConsumers.elements();
      while (enum.hasMoreElements()) {
	ImageConsumer ic = (ImageConsumer) enum.nextElement();
	ic.imageComplete(ImageConsumer.STATICIMAGEDONE);
	if (isConsumer(ic)) {
          ic.imageComplete(ImageConsumer.IMAGEERROR);
        }
      }
      theConsumers.removeAllElements();
    }
  }


  public synchronized void setFullBufferUpdates(boolean flag)
  {
    if(fullbuffers == flag)
      return;
    fullbuffers = flag;
    if(animating) {
      ImageConsumer imageconsumer;
      for(Enumeration enumeration = theConsumers.elements(); enumeration.hasMoreElements(); imageconsumer.setHints(flag ? 6 : 1))
        imageconsumer = (ImageConsumer)enumeration.nextElement();
    }
  }

  public void startProduction(ImageConsumer imageconsumer)
  {
    addConsumer(imageconsumer);
  }
         
}

