//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.awt.*;
import java.awt.image.*;

/***
 *
 * Holds infomartion of a cell (a rawTile).                                     <br>
 *                                                                              <br>
 *
 * The difference between a rawTile and a cell is that for example  
 * there exist1 10 pieces water as rawTiles, representing how to
 * draw it, but every every block in the ocean has 64 water cells.              <br>
 *                                                                              <br>
 * Hope I explained it cleary, maybe there is a better way... - knoxos          <br>
 *
 *                                                                              <br>
 * A streched tile:                                                             <br>
 *
 * <pre>
 *   stl ... stretch left  side
 *    hl ... height left side
 *         
 *      -/-------/---------------- ** --------------/---------/-
 *       |       |                *|  *.            |         |
 *       |       |               * |    *.          | str     |
 *       |       |              *  |      *.        |         |
 *       |       |             *   |        * ------/         |         
 *       |   stl |            *    |        *                 |
 *       |       |           *     |       *                  |
 *    hl |       |          *      |      *                   | hr
 *       |       |         *       |     *                    |
 *       |       |        *        |    *                     | 
 *       |      -/------- *.       |   *                      |      str ... stretch right side
 *       |                  *.     |  *                       |      hr  ... height right
 *       |                    *.   | *                        |
 *       |                      *. |*                         |
 *      -|----------------------- **--------------------------/-
 *                                     | 
 *                                     V 
 *                                 middle line           
 * </pre>
 *
 * @see drawRawTileStreched from ScreenRenderer
 *  
 ***/                                                     
 class MapCell {   
   /*** the tile id ***/
   public int id;
   
   /*** the height pos ***/
   public int height;
   
   /*** height of tile on the left side ***/
   public int hl;

   /*** height of tile on the right side ***/
   public int hr;

   /*** stretch the corner to this height on the left side ***/
   public int stl;

   /*** stretch the corner to this height on the left side ***/
   public int str;   

   /*** the sprite drawing this cell ***/
   public Sprite sprite = null;   
 }