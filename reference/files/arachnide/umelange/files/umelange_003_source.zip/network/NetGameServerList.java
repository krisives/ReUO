//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package network;

/**
 *
 * A game server entry received on startup
 *  
 */                                                     
public class NetGameServerList {   
   public int    serverIndex  = 0;
   public String serverName   = null;
   public int    percentFull  = 0;
   public int    timezone     = 0;
   public long   pingIP       = 0;
   
  /**
   *
   * Constructor
   *
   * The class creates itself from the data received.
   *
   * @param data     byte array that has been received
   * @param offs     offset where this server element has to be read from.
   *
   */                                                     
   NetGameServerList(int[] data, int offs) 
   {
      serverIndex = data[offs++] << 8 + data[offs++];
      
      StringBuffer sb = new StringBuffer(18);
      int i;
      for (i = 0; i < 32; i++) {
        char c = (char) data[offs++];
        if (c != 0) 
          sb.append(c);
      }
      serverName = sb.toString();
      
      percentFull = data[offs++];
      timezone    = data[offs++];
            
      pingIP = (data[offs++] << 24) | (data[offs++] << 16) | (data[offs++] << 8) | data[offs++];
   }

 }