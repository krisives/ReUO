//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package network;

/**
 *
 * A starting location entry received on gameserver login
 *  
 */                                                     
public class NetStartLocList {   
  int    locIndex  = 0;
  String town      = null;
  String exactName = null;
   
  /**
   *
   * Constructor
   *
   * The class creates itself from the data received.
   *
   * @param data     byte array that has been received
   * @param offs     offset where this server element has to be read from.
   *
   */                                                     
   NetStartLocList(int[] data, int offs) 
   {
      locIndex = data[offs++];
      
      StringBuffer sb = new StringBuffer(31);
      int i;
      for (i = 0; i < 31; i++) {
        char c = (char) data[offs++];
        if (c == 0) 
          break;
        sb.append(c);
      }
      offs += 30 - i; // skip remaining bytes
      town = sb.toString();

      sb.setLength(0);
      for (i = 0; i < 31; i++) {
        char c = (char) data[offs++];
        if (c == 0) 
          break;
        sb.append(c);
      }
      offs += 30 - i; // skip remaining bytes
      
      exactName = sb.toString();      
   }

 }