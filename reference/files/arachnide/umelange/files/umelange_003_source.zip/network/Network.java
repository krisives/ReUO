//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package network;

import java.io.*;
import java.net.*;
import java.awt.*;
import Main;

/** 
 *
 * The Network class.
 * 
 * This class implements the world in case of OSI/UOX3 mode
 */  
public class Network {        
  public static final int NORTH           = 0;
  public static final int NORTH_EAST      = 1;
  public static final int EAST            = 2;
  public static final int SOUTH_EAST      = 3;
  public static final int SOUTH           = 4;
  public static final int SOUTH_WEST      = 5;
  public static final int WEST            = 6;
  public static final int NORTH_WEST      = 7;
  
  private static final int NET_IDLE        = 0;
  private static final int NET_FIRST       = 1;

  private static final int MAX_PACKET_SIZE = 1024;

  private static final int SEND_BUFFER_SIZE = 10;

  private static final byte umIdentKey[] = { 0, 2, Main.MAJOR & 0xF, (Main.MINOR & 0xF << 4) | Main.BUILD};
        
  private static final byte packet_null[] = 
    { 
      0, 0, 0, 0, 0, 0,  0, 0, 0, 0,  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0,  0, 0, 0, 0,  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0,  0, 0, 0, 0,  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0, 0,  0, 0, 0, 0,  0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    };

 /**
  * Login Request Packet.
  * Size = 62 bytes
  */ 
  private static final byte packet_x80[] = 
    { 
      (byte) 0x80, 
      0, 0, 0, 0, 0,  0, 0, 0, 0, 0,  0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0,  0, 0, 0, 0, 0,  0, 0, 0, 0, 0,                    
      0, 0, 0, 0, 0,  0, 0, 0, 0, 0,  0, 0, 0, 0, 0, 
      0, 0, 0, 0, 0,  0, 0, 0, 0, 0,  0, 0, 0, 0, 0,                    
      (byte) 0xff
    };

 /**
  * Hardware specification packet.
  * Size = 62 bytes
  */ 
  private static final byte packet_xA4[] = 
    {
      (byte) 0xa4, (byte) 0x03, (byte) 0x00, (byte) 0x00, (byte) 0x01,  // .....
      (byte) 0x55, (byte) 0x6C, (byte) 0x74, (byte) 0x69, (byte) 0x6D,  // Ultim
      (byte) 0x61, (byte) 0x74, (byte) 0x65, (byte) 0x20, (byte) 0x4D,  // ate M
      (byte) 0x65,                                                      // e----
      
      (byte) 0x6C, (byte) 0x61, (byte) 0x6E, (byte) 0x67, (byte) 0x65,  // lange
      (byte) 0x20, (byte) (Main.MAJOR + 0x30), (byte) 0x2E, (byte) (Main.MINOR + 0x30), (byte) 0x2E,  //  0.0.
      (byte) (Main.BUILD + 0x30), (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00,  // 1
      (byte) 0x00,
      
      (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0xf6, 
      (byte) 0x00, (byte) 0x16, (byte) 0x63, (byte) 0xf6, (byte) 0x5e,
      (byte) 0xf6, (byte) 0x5e, (byte) 0xf6, (byte) 0x5e, (byte) 0xf6,
      (byte) 0x5e,
      
      (byte) 0xd5, (byte) 0x5a, (byte) 0xd5, (byte) 0x5a, (byte) 0xd5, 
      (byte) 0x5a, (byte) 0xd5, (byte) 0x5a, (byte) 0xf5, (byte) 0x5e,
      (byte) 0xd5, (byte) 0x5a, (byte) 0xd5, (byte) 0x5a, (byte) 0xd5,
      (byte) 0x5a,
      
      (byte) 0xd5, (byte) 0x5a, (byte) 0xd5, (byte) 0x5a, (byte) 0xd4, 
      (byte) 0x00, (byte) 0xd4, (byte) 0x5a, (byte) 0xa5, (byte) 0x14,
      (byte) 0xef, (byte) 0x3d, (byte) 0x31, (byte) 0x46, (byte) 0xee, 
      (byte) 0x3d,
      
      (byte) 0x08, (byte) 0x21, (byte) 0x4f, (byte) 0x00, (byte) 0xff, 
      (byte) 0xff, (byte) 0xff, (byte) 0xff, (byte) 0x4c, (byte) 0xf8,
      (byte) 0xf5, (byte) 0x00, (byte) 0x88, (byte) 0x88, (byte) 0x4d,
      (byte) 0x00,
      
      (byte) 0x20, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0xe0, 
      (byte) 0x00, (byte) 0x70, (byte) 0x00, (byte) 0xe0, (byte) 0xa8,
      (byte) 0x70, (byte) 0x00, (byte) 0x80, (byte) 0x6b, (byte) 0x51,
      (byte) 0x00,
      
      (byte) 0xd8, (byte) 0x59, (byte) 0xc8, (byte) 0x00, (byte) 0x50, 
      (byte) 0xc0, (byte) 0x6f, (byte) 0x81, (byte) 0x40, (byte) 0x00,
      (byte) 0x00, (byte) 0x00, (byte) 0x9c, (byte) 0x84, (byte) 0xf7,
      (byte) 0xbf,
      
      (byte) 0x00, (byte) 0xc0, (byte) 0x6f, (byte) 0x81, (byte) 0x40, 
      (byte) 0x00, (byte) 0x7f, (byte) 0x07, (byte) 0xff, (byte) 0xff,
      (byte) 0xff, (byte) 0xff, (byte) 0xc4, (byte) 0x00, (byte) 0x00,
      (byte) 0x00,
      
      (byte) 0x20, (byte) 0x00, (byte) 0x00, (byte) 0x03, (byte) 0xf5,
    };                

 /**
  * Login Request Packet.
  * Size = 62 bytes
  */ 
  private static final byte packet_x5D[] = 
    { 
      (byte) 0x5D,                                          // command
      (byte) 0xED, (byte) 0xED, (byte) 0xED, (byte) 0xED,   // pattern
      
      0, 0, 0, 0, 0,  0, 0, 0, 0, 0,  0, 0, 0, 0, 0,        // char name
      0, 0, 0, 0, 0,  0, 0, 0, 0, 0,  0, 0, 0, 0, 0,                    
      
      0, 0, 0, 0, 0,  0, 0, 0, 0, 0,  0, 0, 0, 0, 0,        // char password
      0, 0, 0, 0, 0,  0, 0, 0, 0, 0,  0, 0, 0, 0, 0,                    
      
      0, 0, 0, 0,                                           // slot
       
      0, 0, 0, 0                                            // client ip
    };

  private int  rpacket[]    =  null;
  private int  rlen         =     0;
           
 /**
  * The game socket.
  */
  private Socket gsocket = null;
  
 /*
  * Outgoing data stream
  */  
  private DataOutputStream out = null;
        
 /**
  * Incoming data stream, directly from network
  */  
  private InputStream base_in = null;

 /**
  * Incoming data stream, filtered stream (by decompressor)
  */  
  private DataInputStream in = null;

 /**
  * Pointer to the current receiver.
  */  
  private Receiver receiver;

 /**
  * Pointer to the current sender.
  */  
  private Sender sender;
  
 /**
  * This class will receive all network events;
  */  
  private NetListener netListener = null;

 /**
  *
  * Inner class the receive thread
  *
  */
  class Receiver extends Thread {        
    public boolean running = false;
      
    /** 
     *
     * Constuctor
     *
     */  
     Receiver() {
       super("netrv :");
     }    
        
     public void run() {
       running = true;
       System.out.println("netrv: Receiver started.");
       while (running) {
         try {
           int command = in.readUnsignedByte(); // this command will block the receiver thread
                                                // until a command is really received.
           rpacket[0] = command;
           //System.out.println("Command received: " + command);
           switch (command) {          
             case 0x11 :
               {
                 // Stat window info (66 bytes) 
                 in.readUnsignedByte(); // packet length not needed
                 in.readUnsignedByte(); // packet length not needed
                 int creatureId = (in.readUnsignedByte() << 24) |
                                  (in.readUnsignedByte() << 16) |
                                  (in.readUnsignedByte() << 8) |
                                   in.readUnsignedByte();
                 StringBuffer playerName = new StringBuffer();
                 for (int i = 0; i < 30; i++) {
                   char c = (char) in.readUnsignedByte();
                   if (c != 0)
                     playerName.append(c);                 
                 }
                 int curHp = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte();
                 int maxHp = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte();
                 int flag  = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte();  
                 int sex   =  in.readUnsignedByte();
                 int str   = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte();  
                 int dex   = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte();  
                 int intl  = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte();  
                 int curStm  = (in.readUnsignedByte() << 8) | // stamina
                                in.readUnsignedByte();  
                 int maxStm  = (in.readUnsignedByte() << 8) | // stamina
                                in.readUnsignedByte();  
                 int curMana = (in.readUnsignedByte() << 8) | 
                                in.readUnsignedByte();  
                 int maxMana = (in.readUnsignedByte() << 8) | 
                                in.readUnsignedByte();  
                 int gold = (in.readUnsignedByte() << 24) |
                            (in.readUnsignedByte() << 16) |
                            (in.readUnsignedByte() << 8) |
                             in.readUnsignedByte();
                 int armorClass = (in.readUnsignedByte() << 8) | 
                                   in.readUnsignedByte();  
                 int weight = (in.readUnsignedByte() << 8) | 
                               in.readUnsignedByte();     
                 netListener.recvStatWindow(creatureId, playerName.toString(), curHp, maxHp, flag, sex, str, dex, intl, curStm, maxStm, curMana, maxMana, gold, armorClass, weight);
                 break;
               }    
             case 0x1A : 
               {
                 // Put Object (Variable # of bytes) 
                 int len = (in.readUnsignedByte() << 8) |
                            in.readUnsignedByte();
                 System.out.print("put object len: " + len);
                 int clen = 3;
                 int itemid = (in.readUnsignedByte() << 24) |
                              (in.readUnsignedByte() << 16) |
                              (in.readUnsignedByte() << 8) |
                               in.readUnsignedByte();
                 clen += 4;
                 int model = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte();
                 clen += 2;
                 if ((itemid & 0x80000000) != 0)  {
                   int itemcount = (in.readUnsignedByte() << 8) |
                                    in.readUnsignedByte();
                   // or model # for corpses
                   clen += 2;
                 }
                 if ((model & 0x8000) != 0) {
                   model += in.readUnsignedByte();
                   clen ++;
                 }
                 int xLoc     = (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 clen += 2;
                 int yLoc     = (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 clen += 2;
                 int dir = -1;
                 if ((xLoc & 0x8000) != 0) {
                   dir = in.readUnsignedByte();
                   clen ++;
                 }
                 int zLoc     = (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 clen += 2;
                 int dye = -1;
                 if ((yLoc & 0x8000) != 0) {
                   dye = (in.readUnsignedByte() << 8) |
                          in.readUnsignedByte();
                   clen += 2;
                 }
                 int flag = -1;
                 if ((yLoc & 0x4000) != 0) {
                   //flag = in.readUnsignedByte();
                   //clen ++;
                 }
                 System.out.println("   grabbed: " + clen);
                 //netListener.drawOject(objid, model, skincolor, xLoc & 0x8000, yLoc, zLoc, dir, dir2, dye, flag, notoriety, itemid, model, pos, hue);
                 // not forwarding yet
                 break;
               }
             case 0x1B : 
               {
                 // Char Location and body type (37 bytes) 
                 int playerid = (in.readUnsignedByte() << 24) |
                                (in.readUnsignedByte() << 16) |
                                (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown
                 int bodyType = (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 int xLoc     = (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 int yLoc     = (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 int zLoc     = (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 int dir      = in.readUnsignedByte();
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown                
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown
                 int mode = in.readUnsignedByte(); // mode
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown                
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown
                 in.readUnsignedByte(); // unknown
                 netListener.setCharLocation(playerid, bodyType, xLoc, yLoc, zLoc, dir, mode);
                 break;
               }
               
             case 0x1C :
               { // Send Speech (Variable # of bytes) 
                 int len = (in.readUnsignedByte() << 8) |
                            in.readUnsignedByte();
                 int itemid = (in.readUnsignedByte() << 24) |
                              (in.readUnsignedByte() << 16) |
                              (in.readUnsignedByte() << 8) |
                               in.readUnsignedByte();
                 int model = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte();
                 int type = in.readUnsignedByte();
                 int textcolor = (in.readUnsignedByte() << 8) |
                                  in.readUnsignedByte();
                 in.readUnsignedByte();
                 int font = in.readUnsignedByte();
                 StringBuffer namesb = new StringBuffer();
                 for (int i = 0; i < 30; i++) {
                    char c = (char) in.readUnsignedByte();
                    if (c != 0) 
                      namesb.append(c);
                 }
                 StringBuffer message = new StringBuffer();                 
                 for (int i = 0; i < len - 44; i++) {
                    char c = (char) in.readUnsignedByte();
                    if (c != 0) 
                      message.append(c);
                 }
                 netListener.recvSpeech(itemid, model, type, textcolor, font, namesb.toString(), message.toString());
                 break;
               }                 
               
             case 0x1D :
               {
                 // Delete object (5 bytes) 
                 int objid = (in.readUnsignedByte() << 24) |
                             (in.readUnsignedByte() << 16) |
                             (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte();
                 netListener.deleteObject(objid);
                 break;
               }                      
             case 0x20 : 
               {
                 // Draw creature (19 bytes)                
                 int creatureid = (in.readUnsignedByte() << 24) |
                                  (in.readUnsignedByte() << 16) |
                                  (in.readUnsignedByte() << 8) |
                                   in.readUnsignedByte();
                 int bodyType = (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 in.readUnsignedByte();
                 int skinColor = (in.readUnsignedByte() << 8) |
                                  in.readUnsignedByte();
                 int mode      =  in.readUnsignedByte();
                 int xLoc      = (in.readUnsignedByte() << 8) |
                                  in.readUnsignedByte();
                 int yLoc      = (in.readUnsignedByte() << 8) |
                                  in.readUnsignedByte();
                 in.readUnsignedByte();
                 in.readUnsignedByte();
                 int dir       =  in.readUnsignedByte();
                 int zLoc      =  in.readUnsignedByte();
                 netListener.drawCreature(creatureid, bodyType, skinColor, xLoc, yLoc, zLoc, dir, mode);
                 break;                                  
               }
             case 0x21 : 
               { // Character Move Reject (8 bytes) 
                 int sequence =  in.readUnsignedByte();
                 int xLoc     =  (in.readUnsignedByte() << 8) |
                                  in.readUnsignedByte();
                 int yLoc     =  (in.readUnsignedByte() << 8) |
                                  in.readUnsignedByte();
                 int dir      =   in.readUnsignedByte();
                 int zLoc     =   in.readUnsignedByte();
                 netListener.moveReject(sequence, xLoc, yLoc, zLoc, dir);
                 break;
               }
               
             case 0x22 :
               {
                 // Character Move ACK (3 bytes) 
                 int  sequence =  in.readUnsignedByte();
                 in.readUnsignedByte(); // unused;
                 netListener.moveAck(sequence);
                 break;
               }               

             case 0x2E : 
               {
                 // Worn Items (15 bytes) 
                 int itemid = (in.readUnsignedByte() << 24) |
                              (in.readUnsignedByte() << 16) |
                              (in.readUnsignedByte() << 8) |
                               in.readUnsignedByte();
                 int model  = (in.readUnsignedByte() << 8) |
                               in.readUnsignedByte();
                 in.readUnsignedByte();   // null char
                 int location = in.readUnsignedByte();
                 int playerid = (in.readUnsignedByte() << 24) |
                                (in.readUnsignedByte() << 16) |
                                (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 int color   = (in.readUnsignedByte() << 8) |
                                in.readUnsignedByte();
                 netListener.wornItem(itemid, model, location, playerid, color);
                 break;
               }
             
             case 0x3c :
               {
                 // Items in Container (Variable # of bytes) 
                 int len = (in.readUnsignedByte() << 8) |
                            in.readUnsignedByte();
                 int items = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte();
                 for (int i = 0; i < items; i++) {
                   int itemid = (in.readUnsignedByte() << 24) |
                                (in.readUnsignedByte() << 16) |
                                (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                   int model = (in.readUnsignedByte() << 8) |
                                in.readUnsignedByte();
                   in.readByte(); // unkown
                   int stackcount = (in.readUnsignedByte() << 8) |
                                     in.readUnsignedByte();
                   int xLoc = (in.readUnsignedByte() << 8) |
                               in.readUnsignedByte();
                   int yLoc = (in.readUnsignedByte() << 8) |
                               in.readUnsignedByte();
                   int countainerid = (in.readUnsignedByte() << 24) |
                                      (in.readUnsignedByte() << 16) |
                                      (in.readUnsignedByte() << 8) |
                                       in.readUnsignedByte();
                   int color = (in.readUnsignedByte() << 8) |
                                in.readUnsignedByte();
                   // not sended yet                   
                 }
                 break;                   
               }  
             case 0x4F :
               {
                  // Overall Light Level (2 bytes) 
                  int level = in.readUnsignedByte();
                  netListener.setLightLevel(level);
                  break;
               }               
               
             case 0x54 :
               {
                  // Sound Effect (12 bytes) 
                  in.readByte();
                  in.readByte(); // sound model?
                  in.readByte();
                  in.readByte(); // speed volume?
                  in.readByte();
                  int xLoc = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte();
                  int yLoc = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte();
                  in.readByte();
                  in.readByte();
                  in.readByte();
                  in.readByte();
                  int zLoc = in.readByte();
                  // is currently not send...
                  break;
               }

             case 0x55 :
               {
                  // Redraw all (1 bytes) 
                  netListener.redrawRequest();
                  break;
               }               

             case 0x5B :
               {
                  // Time (4 bytes) 
                  int hour =    in.readUnsignedByte();
                  int min  =    in.readUnsignedByte();
                  int sec  =    in.readUnsignedByte();
                  netListener.recvTime(hour, min, sec);
                  break;
               }       
               
             case 0x65 : 
               {
                 // Change Weather (4 bytes) 
                 int type =    in.readUnsignedByte();
                 int amount = (in.readUnsignedByte() << 8) |
                               in.readUnsignedByte();
                 netListener.changeWeather(type, amount);
                 break;
               }
               
             case 0x69 : 
               {
                 // Change Text/Emote Color (5 bytes) 
                 int len = (in.readUnsignedByte() << 8) |
                            in.readUnsignedByte();
                 int index = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte();
                 netListener.changeTextColor(index);
                 break;
               }

             case 0x6D : 
               {
                 // Play Music (3 bytes) 
                 int musicID = (in.readUnsignedByte() << 8) |
                                in.readUnsignedByte();
                 netListener.playMusic(musicID);
                 break;
               }
             case 0x72 :
               {
                 // Request Mode Change (5 bytes) 
                 int flag = in.readUnsignedByte();
                 in.readUnsignedByte(); // unkown
                 in.readUnsignedByte(); // unkown
                 in.readUnsignedByte(); // unkown
                 netListener.requestModeChange(flag);
                 break;
               }  
               
             case 0x77 :
               {
                 // Send Player (17 bytes) 
                 int playerid = (in.readUnsignedByte() << 24) |
                                (in.readUnsignedByte() << 16) |
                                (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 int model = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte(); //item hex # - 0x0190 for human male
                 int xLoc     =  (in.readUnsignedByte() << 8) |
                                  in.readUnsignedByte();
                 int yLoc     =  (in.readUnsignedByte() << 8) |
                                  in.readUnsignedByte();
                 int zLoc     =   in.readUnsignedByte();
                 int dir      =   in.readUnsignedByte();
                 int color = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte(); 
                 int mode     =   in.readUnsignedByte();
                    // 0x00 - normal 
                    // 0x40 - attack mode 
                    // 0x80 - hidden? 
                 int noto     =   in.readByte();
                 netListener.sendPlayer(playerid, model, xLoc, yLoc, zLoc, dir, color, mode, noto);
                 break;
               }            
             case 0x78 : 
               {
                 // Draw object (Variable # of bytes) 
                 int len = (in.readUnsignedByte() << 8) |
                            in.readUnsignedByte();
                 int clen = 3;
                 System.out.print("draw object len: " + len);
                 int objid = (in.readUnsignedByte() << 24) |
                             (in.readUnsignedByte() << 16) |
                             (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte(); 
                 clen += 4;                                                                             
                 int model = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte();
                 clen += 2;                                                                             
                 int xLoc = (in.readUnsignedByte() << 8) |
                             in.readUnsignedByte();
                 clen += 2;                                                                             
                 int yLoc = (in.readUnsignedByte() << 8) |
                             in.readUnsignedByte();
                 clen += 2;                                                                             
                 int dir = 0;
                 /*
                 if ((xLoc & 0x8000) != 0) {
                   System.out.print(" XLOC");
                   clen ++; 
                   dir = in.readUnsignedByte();
                 }
                 */
                 int zLoc = in.readUnsignedByte();
                 clen ++; 
                 int dir2 = in.readUnsignedByte();
                 clen ++; 
                 int dye  = (in.readUnsignedByte() << 8) |
                             in.readUnsignedByte();
                 clen += 2; 
                 int flag = in.readUnsignedByte();
                 clen ++; 
                 int notoriety  = (in.readUnsignedByte() << 8) |
                                   in.readUnsignedByte();
                 clen += 2; 
                 notoriety = (notoriety ^ 0xFFFF) + 1;
                 /*int itemid = (in.readUnsignedByte() << 24) |
                              (in.readUnsignedByte() << 16) |
                              (in.readUnsignedByte() << 8) |
                               in.readUnsignedByte();
                 clen += 4; */
                 int model2 = 0;
                 int pos   = 0;
                 int hue   = 0;
                 int itemid = 0;
                 /*
                 while (true) {
                   //System.out.print(" ITEMID");
                   itemid = (in.readUnsignedByte() << 24) |
                            (in.readUnsignedByte() << 16) |
                            (in.readUnsignedByte() << 8) |
                             in.readUnsignedByte();
                   clen += 4; 
                   if (itemid == 0)
                     break;
                   model2 = (in.readUnsignedByte() << 8) |
                             in.readUnsignedByte();
                   clen += 2; 
                   pos    =  in.readUnsignedByte();
                   clen ++; 
                   if ((model2 & 0x8000) != 0) {
                     System.out.print(" MODEL");
                     hue = (in.readUnsignedByte() << 8) |
                            in.readUnsignedByte();                        
                     clen += 2;
                   }
                 }
                 */
                 while (clen < len) {
                   in.readByte();
                   clen++;      
                 }
                 System.out.println("   grabbed: " + clen);
                 netListener.drawOject(objid, model, xLoc & 0x8000, yLoc, zLoc, dir, dir2, dye, flag, notoriety, itemid, model, pos, hue);
                 break;
               }                                                                                  
             case 0x82 : 
                 // Login Denied
                 // fixed length size.
                 int reason = in.readUnsignedByte(); 
                 netListener.loginDenied(reason);
                 break;

             case 0x89 : 
               {
                 // Corpse clothing (7 + count * 5 # of bytes) 
                 int len = (in.readUnsignedByte() << 8) |
                            in.readUnsignedByte();
                 int modelid = (in.readUnsignedByte() << 24) |
                               (in.readUnsignedByte() << 16) |
                               (in.readUnsignedByte() << 8) |
                                in.readUnsignedByte();
                 for (;;) {
                   int layer = in.readUnsignedByte();
                   if (layer == 0) 
                     break;
                   int objectid = (in.readUnsignedByte() << 24) |
                                  (in.readUnsignedByte() << 16) |
                                  (in.readUnsignedByte() << 8) |
                                   in.readUnsignedByte();
                 }
                 // in not trasmitted now
                 break;
               }
                                
             case 0x8C : 
               {
                 // Connect to game server
                 // fixed length size.
                 String gameserver = "" + in.readUnsignedByte() + '.' + 
                                          in.readUnsignedByte() + '.' + 
                                          in.readUnsignedByte() + '.' +
                                          in.readUnsignedByte();
                 int gameport   = (in.readUnsignedByte() << 8) |
                                   in.readUnsignedByte();
                 int newkey     = (in.readUnsignedByte() << 24) |
                                  (in.readUnsignedByte() << 16) |
                                  (in.readUnsignedByte() << 8) |
                                   in.readUnsignedByte();
                 netListener.connectGameServer(gameserver, gameport, newkey);
                 break;
              }
             case 0xA1 :
              {
                 // Update Current Hitpoints (9 bytes) 
                 int playerid = (in.readUnsignedByte() << 24) |
                                (in.readUnsignedByte() << 16) |
                                (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte(); 
                 int maxhp    = (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 int curhp    = (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 netListener.updatehp(playerid, maxhp, curhp);
                 break;
              } 
             case 0xA2 :
              {
                 // Update Update Current Mana (9 bytes) 
                 int playerid = (in.readUnsignedByte() << 24) |
                                (in.readUnsignedByte() << 16) |
                                (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte(); 
                 int maxMana  = (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 int curMana  = (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 netListener.updateMana(playerid, maxMana, curMana);
                 break;
              } 
              
             case 0xA3 :
              {
                 // Update Update Current Stamina (9 bytes) 
                 int playerid = (in.readUnsignedByte() << 24) |
                                (in.readUnsignedByte() << 16) |
                                (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte(); 
                 int maxStamina  = (in.readUnsignedByte() << 8) |
                                    in.readUnsignedByte();
                 int curStamina  = (in.readUnsignedByte() << 8) |
                                    in.readUnsignedByte();
                 netListener.updateStamina(playerid, maxStamina, curStamina);
                 break;
              } 
              
             case 0xA6 : 
              {
                 // Tips/Notice window (Variable # of bytes) 
                 int len = (in.readUnsignedByte() << 8) |
                            in.readUnsignedByte();
                 int flag = in.readUnsignedByte();
                 in.readUnsignedByte();
                 in.readUnsignedByte();
                 int tipnr = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte();
                 int msgSize = (in.readUnsignedByte() << 8) |
                                in.readUnsignedByte();
                                
                 StringBuffer message = new StringBuffer();                 
                 for (int i = 0; i < len - 10; i++) {
                    char c = (char) in.readUnsignedByte();
                    if (c != 0) 
                      message.append(c);
                 }
                 netListener.noticeWindow(flag, tipnr, message.toString());
                 break;
               }                              

             case 0xA8 : 
               {
                 // Game Server List (Variable # of bytes) 
                 int b1 = rpacket[1] = in.readUnsignedByte();
                 int b2 = rpacket[2] = in.readUnsignedByte();                                  
                 int len = (b1 << 8) | b2;
                 for (int i = 3; i < len; i++) {       // again this will block the thread until whole 
                   rpacket[i] = in.readUnsignedByte(); // package is received.
                 }
                 int servers = ((rpacket[4] << 8) | rpacket[5]);
                 NetGameServerList list[] = new NetGameServerList[servers];
                 for (int i=0; i < servers; i++) {
                    list[i] = new NetGameServerList(rpacket, 6 + i* 40);
                 }
                 netListener.receivedGameServerList(rpacket[3], list);
                 break;
               }
             case 0xA9 : 
               {
                 // Characters / Starting Locations (varibale packet size.)
                 int b1 = rpacket[1] = in.readUnsignedByte();
                 int b2 = rpacket[2] = in.readUnsignedByte();
                 int len = (b1 << 8) | b2;
                 //for(int i = 0; i < len; i++)                 
                 //  System.out.println(i + ":" +  rpacket[i]);
                 //System.out.println("len :" + len);
                 for (int i = 3; i < len; i++) {       
                   rpacket[i] = in.readUnsignedByte(); 
                 }                 
                 //System.out.println("chars :" + rpacket[3]);
                 String charNames[] = new String[5];
                 String charPasswords[] = new String[5];
                 int offs = 4;
                 StringBuffer sb = new StringBuffer(30);
                 for (int i = 0; i < 5; i++) {
                   //System.out.println("Offset :" + offs);
                   sb.setLength(0);
                   int j;
                   for (j = 0; j < 30; j++) {
                     char c = (char) rpacket[offs++];
                     if (c == 0) 
                       break;
                     sb.append(c);
                   }                   
                   offs += 29 - j; // skip remaining bytes
                   charNames[i] = sb.toString();
   
                   //System.out.println("Offset :" + offs);
                   sb.setLength(0);
                   // no the password
                   for (j = 0; j < 30; j++) {
                     char c = (char) rpacket[offs++];
                     if (c == 0) 
                       break;
                     sb.append(c);
                   }                   
                   offs += 29 - j; // skip remaining bytes
                   charPasswords[i] = sb.toString();
                 }
                 //System.out.println("Character 1 name :" + charNames[0]);
                 //System.out.println("Character 2 name :" + charNames[1]);
                 System.out.println("Offse: " +  offs);
                 int startLocCount = rpacket[offs++];
                 NetStartLocList startLocList[] = new NetStartLocList[startLocCount];
                 //System.out.println("Starting locations :" + startLocCount);
                 System.out.println("startLocCount: " +  startLocCount);
                                  
                 for (int i = 0; i < startLocCount; i++) {
                    startLocList[i] = new NetStartLocList(rpacket, offs);
                    offs += 63;
                 }
                 //for (int i = 0; i < startLocCount; i++) 
                 //  System.out.println("Starting loc #" + i + " id:" + startLocList[i].locIndex + " town: " + startLocList[i].town + " town: " + startLocList[i].exactName );                                  
                 netListener.receivedCharList(rpacket[3], charNames, charPasswords, startLocList);
                 break;
               } 
             case 0xAE : 
               {
                 // Unicode speech. (var size)
                 int len = (in.readUnsignedByte() << 8) |
                            in.readUnsignedByte();
                 int playerid = (in.readUnsignedByte() << 24) |
                                (in.readUnsignedByte() << 16) |
                                (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 int model = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte(); 
                 int type  =  in.readUnsignedByte(); 
                 int textcolor = (in.readUnsignedByte() << 8) |
                                  in.readUnsignedByte(); 
                 int font  = (in.readUnsignedByte() << 8) |
                              in.readUnsignedByte(); 
                 int language = (in.readUnsignedByte() << 24) |
                                (in.readUnsignedByte() << 16) |
                                (in.readUnsignedByte() << 8) |
                                 in.readUnsignedByte();
                 StringBuffer name = new StringBuffer();
                 // name
                 boolean strend = false;
                 for (int i = 0; i < 30; i++) {
                   char c = (char) in.readUnsignedByte();
                   if (c == 0)
                     strend = true;
                   if (!strend) 
                     name.append(c);
                 }                   
                 int msglen = ((len - 48) >> 1);                 
                 StringBuffer message = new StringBuffer();
                 strend = false;
                 for (int i = 0; i < msglen; i++) {
                   char c = (char) ((in.readUnsignedByte() << 8) |
                                     in.readUnsignedByte());                                      
                   if (c == 0) 
                     strend = true;
                   if (!strend)
                     message.append(c);                        
                 }
                 netListener.recvSpeech(playerid, model, type, textcolor, font, name.toString(), message.toString());
                 break;
               }               
             default : 
                 System.out.println("netrv: unkown message received. char: 0x" + Integer.toHexString(command));            
           }
         } catch (IOException e) {
           if (running) {
             System.out.println("netrv: IOException during data receive: " + e.getMessage());
             System.exit(1);
           }
           // if not running this is a normal error condition, caused by closing
           // the socket while waiting for an answer, silently discard this thread
           // then.
         }
         //catch (InterruptedException e) {}
        }
        System.out.println("netrv: Receiver stopped.");
     }        
  } 
          
 /**
  *
  * Inner class the send thread
  *
  */
  class Sender extends Thread {        
    public boolean running = false;
    private String server;
    private int port;
    private boolean compressed;

   /**
    *
    * This is the buffer holding the next packets to send. 
    *
    */
    private byte     spackets[][] =  null;
    private int      splen[]      =  null;
    private boolean  spready[]    =  null;
   /**
    * Begin of the ring buffer 
    */
    private int  sbuf_begin   =     0;
   
   /**
    * End of ring buffer of ready to send packages.
    */    
    private int  sbuf_ready   =     0;
   
   /**
    * End of ring buffer.
    */
    private int  sbuf_end     =     0;
      
    /** 
     *
     * Constuctor
     *
     */  
     Sender(String setServer, int setPort, boolean setCompressed) {
       super("nets  :");
       server = setServer;
       port   = setPort;
       compressed = setCompressed;
       spackets = new byte[SEND_BUFFER_SIZE][MAX_PACKET_SIZE];
       splen    = new int[SEND_BUFFER_SIZE];
       spready  = new boolean[SEND_BUFFER_SIZE];
       for (int i = 0; i <SEND_BUFFER_SIZE; i++) {
         splen[i]   = 0;
         spready[i] = false; 
       }
     }    
               
   /**
    * Take a packet out of the pool,
    * to load data into it
    * 
    * @param  len of the packet. 
    *        (the returned array can be larger, but only
    *         len bytes will be sent.
    *
    * @return the packet
    *
    */  
    public synchronized byte[] getPacket(int len) 
    {
      int ebuf = sbuf_end;
      int nbuf = ebuf + 1;
      if (nbuf == SEND_BUFFER_SIZE)
        nbuf= 0; 
      if (nbuf == sbuf_begin) {// buffer is full
        System.out.println("nets  : WARNING buffer is full.");
        return null;
      }
      sbuf_end = nbuf;
      spready[ebuf] = false;
      splen[ebuf] = len;
      return spackets[ebuf];
    }

   /**
    * Put a packet back into the pool and mark it as ready to send.
    *
    * @param the packet to send.
    */  
    public synchronized void confirmPacket(byte packet[]) 
    {
      // set the package ready.
      if (packet == null) {
        System.out.println("nets  : ERROR: confiming NULL packet.");
        return;
      }
      int nbuf = sbuf_ready;
      //System.out.print("entring dangerous loop ... ");
      // this may hang if a packet is transmited
      // if it is not part of the pool.
      // well you simple had a bad day if this happens.
      while (spackets[nbuf]!=packet) 
        if (++nbuf == SEND_BUFFER_SIZE)
          nbuf = 0;
      //System.out.print(" done going to second ... ");
      
      spready[nbuf] = true;      
      // shift on ready pointer      
      int sbufLoopStart = sbuf_ready;
      while (spready[sbuf_ready]) {
        if (++sbuf_ready == SEND_BUFFER_SIZE)
          sbuf_ready = 0;          
        if (sbufLoopStart == sbuf_ready) { // all is ready! buffer overflow
          System.out.println("netsender : Buffer overflow! breaking loop ... ");
          break;
        }          
      }
      
      //System.out.println("survived");
      interrupt(); // interrupt sending thread sleeping.
    }
        
    /**
     *
     * Scrap last packet that has been sent
     */  
    synchronized private void scrapPacket() {      
      spready[sbuf_begin] = false;
      if (++sbuf_begin == SEND_BUFFER_SIZE) {
        sbuf_begin = 0; 
      }
    }
                   
    public void run() {
      running = true;
      System.out.println("nets  : Sender started, connecting ...");
      try {
        gsocket = new Socket(server, port);
        out     = new DataOutputStream(gsocket.getOutputStream());
        if (compressed) {
          base_in = gsocket.getInputStream();
          Decompressor dstream = new Decompressor(base_in);
          in      = new DataInputStream(dstream);                                
        } else {
          base_in = gsocket.getInputStream();
          in      = new DataInputStream(base_in);
        }
      } catch (UnknownHostException e) {
        netListener.connectError("Cannot resolve server.");
        running = false;
        return;
      } catch (IOException e) {
        netListener.connectError(e.getMessage());
        running = false;
        return;
      }           
      // Start network receiver thread
      receiver = new Receiver();             
      receiver.start();      
      
      while (running) {
        try {
          while (sbuf_begin != sbuf_ready) {
            out.write(spackets[sbuf_begin], 0, splen[sbuf_begin]);
            out.flush();
            scrapPacket();            
          }
          sleep(10000); // sleep 10 seconds or wait to be interrupted
        } catch (IOException e) {
          System.out.println("nets : IOException during data send: " + e.getMessage());
          System.exit(1);
        } catch (InterruptedException e) {
          // nothing
        }
      }
      System.out.println("nets  : Sender stopped.");
    }        
  } 

 /** 
  *
  * Constuctor
  * 
  */  
  public Network() {
    rpacket = new int[MAX_PACKET_SIZE];
  }

 /**
  *
  * Connect to the server
  *
  * @param Server     Server ip or DNS address.
  * @param port       Port to connect to
  * @param boolean    Compressed stream?
  *
  */
  public void connect(String server, int port, boolean compress)
  {
     sender = new Sender(server, port, compress);
     sender.start();
  }

 /**
  *
  * Send the default seed to the server
  *
  */
  public void sendSeed()
  {
     byte[] packet = sender.getPacket(4);
     System.arraycopy(umIdentKey, 0, packet, 0, 4);
     sender.confirmPacket(packet); 
  }       

 /**
  *
  * Send a non default seed to the server
  *
  */
  public void sendSeed(int key)
  {
     byte[] packet = sender.getPacket(4);
     packet[0] = (byte) ((key & 0xFF000000) >> 24);
     packet[1] = (byte) ((key & 0x00FF0000) >> 16);
     packet[2] = (byte) ((key & 0x0000FF00) >> 8);
     packet[3] = (byte) ((key & 0x000000FF));
     sender.confirmPacket(packet); 
  }       

        
 /**
  * Sends a login request packet 0x80
  * @param account    Account name
  * @param password   Password
  *
  */
  public void sendLoginRequest(String Account, String Password) 
  {  
    byte[] packet = sender.getPacket(62);

    System.arraycopy(packet_x80, 0, packet, 0,  62);
    byte abytes[] = Account.getBytes();
    byte pbytes[] = Password.getBytes();
    
    int alen = abytes.length;
    int plen = pbytes.length;
    
    if ((alen > 30) || (plen > 30)) {
       System.err.println("net  : Error in packet 80, Account or Password to long.");
       System.exit(1);
    } 
    if ((alen == 0) || (plen == 0)) {
       System.err.println("net  : Error in packet 80, Account or Password missing.");
       System.exit(1);
    } 
    
    System.arraycopy(abytes, 0, packet,  1, alen);   // fill in acount name
    System.arraycopy(pbytes, 0, packet, 31, plen);   // fill in password
   
    sender.confirmPacket(packet);    
  }


 /**
  * Sends a login request for game server packet 0x91
  * @param account    Account name
  * @param password   Password
  *
  */
  public void sendGameLogin(String Account, String Password, int key) 
  {  
    byte[] packet = sender.getPacket(65);
    System.arraycopy(packet_null, 0, packet, 0,  65);

    packet[0] = (byte) 0x91;
    packet[1] = (byte) ((key & 0xFF000000) >> 24);
    packet[2] = (byte) ((key & 0x00FF0000) >> 16);
    packet[3] = (byte) ((key & 0x0000FF00) >>  8);
    packet[4] = (byte) ((key & 0x000000FF));
    byte abytes[] = Account.getBytes();
    byte pbytes[] = Password.getBytes();
    
    int alen = abytes.length;
    int plen = pbytes.length;
    
    if ((alen > 30) || (plen > 30)) {
       System.out.println("net  : Error in packet 80, Account or Password to long.");
       System.exit(1);
    } 
    if ((alen == 0) || (plen == 0)) {
       System.out.println("net  : Error in packet 80, Account or Password missing.");
       System.exit(1);
    } 
    
    System.arraycopy(abytes, 0, packet,  5, alen);   // fill in acount name
    System.arraycopy(pbytes, 0, packet, 35, plen);   // fill in password
   
    sender.confirmPacket(packet);
  }

 /**
  *
  * Sends the welcome reply (packet_xA4)
  *
  */
  public void sendWelcomeReply() 
  {  
    byte[] packet = sender.getPacket(packet_xA4.length);
    System.arraycopy(packet_xA4, 0, packet, 0, packet_xA4.length);
    sender.confirmPacket(packet);
  }  

 /**
  * Sends a server selector packet. (packet_xA0)
  *
  * @param server     server to select
  * 
  */
  public void sendServerSelector(int server) 
  {  
    byte[] packet = sender.getPacket(3);
    packet[0] = (byte) 0xA0;
    packet[1] = (byte) ((server & 0xFF00) >> 8);
    packet[2] = (byte)  (server & 0x00FF);
    sender.confirmPacket(packet);
  }

 /**
  * Sends a character login packet. (packet_x5d)
  *
  * @param server     server to select
  * 
  */
  public void sendCharLogin(int slot, String name) 
  {  
    byte[] packet = sender.getPacket(packet_x5D.length);
    System.arraycopy(packet_x5D, 0, packet, 0, packet_x5D.length);
        
    byte nbytes[] = name.getBytes();  
    int nlen = nbytes.length;
    
    if (nlen > 30)  {
       System.out.println("net  : Error in packet 5d, Character name to long.");
       System.exit(1);
    } 
    if (nlen == 0) {
       System.out.println("net  : Error in packet 5d, Character name missing.");
       System.exit(1);
    }     
    System.arraycopy(nbytes, 0, packet,  5, nlen);   // fill in acount name
    
    packet[65] = (byte) ((slot & 0xFF000000) >> 24);   // fill in slot info
    packet[66] = (byte) ((slot & 0x00FF0000) >> 16);
    packet[67] = (byte) ((slot & 0x0000FF00) >>  8);
    packet[68] = (byte) ((slot & 0x000000FF));

    try {
      System.arraycopy(InetAddress.getLocalHost().getAddress(), 0, packet, 69, 4); // fill in my IP
    } catch (UnknownHostException e) {
      System.out.println("net  : Fatal error, local host is unkown ?????");
      System.exit(1);
    }
    
    sender.confirmPacket(packet);
  }
        
 /**
  * terminates any connection, without logout!
  */
  public void disconnect() 
  {  
    try {
      if (sender != null) {
        sender.running = false;
        sender.interrupt();
      }
      if (receiver != null) {
        receiver.running = false;         
        receiver.interrupt();
      }

      in.close();
      base_in.close();
      out.close();
      gsocket.close();    
      base_in  = null;
      in       = null;
      out      = null;
      gsocket  = null;
      sender   = null;
      receiver = null;
    } catch (IOException e) {
       System.err.println("net  : IOException whle termination: " + e.getMessage());
       // no further action since this already a termination situation.
    }
  }

  public void setNetListener(NetListener nl)
  {
    netListener = nl;
  }
  
  public void walk(int direction, int sequence, boolean run)
  {
    byte[] packet = sender.getPacket(7);
    packet[0] = 0x02;
    if (run)
      packet[1] = (byte) (0x80 | direction);
    else
      packet[1] = (byte) direction;
    packet[2] = (byte) sequence;
    packet[3] = 0; // crypt info?
    packet[4] = 0;
    packet[5] = 0;
    packet[6] = 0;
    sender.confirmPacket(packet);
  }

  public void requestPlayerStatus(int id)
  {
    // 0x34 Packet
    byte[] packet = sender.getPacket(10);
    packet[0] = (byte) 0x34; // cmd
    packet[1] = (byte) 0xed; // pattern
    packet[2] = (byte) 0xed;
    packet[3] = (byte) 0xed;
    packet[4] = (byte) 0xed;
    packet[5] = (byte) 0x04; // type
    packet[6] = (byte) ((id & 0xFF000000) >> 24); // player id 1
    packet[7] = (byte) ((id & 0x00FF0000) >> 16); // player id 2
    packet[8] = (byte) ((id & 0x0000FF00) >>  8); // player id 3
    packet[9] = (byte) ((id & 0x000000FF));       // player id 4
    sender.confirmPacket(packet);
  }

  public void talkRequest(int type, int color, int font, String message)
  {
    // 0x03 Packet
    int msglen = message.length();
    int len = 9 + msglen;
    byte[] packet = sender.getPacket(len);
    byte[] mbytes = message.getBytes();  
    packet[0] = (byte) 0x03; // cmd
    packet[1] = (byte) ((len & 0xFF00) >> 8); // length
    packet[2] = (byte) (len & 0x00FF);        // length
    packet[3] = (byte) type; // type
    packet[4] = (byte) ((color & 0xFF00) >> 8); // color
    packet[5] = (byte)  (color & 0x00FF);       // color
    packet[6] = (byte) 0x00; // font high
    packet[7] = (byte) font; // font low
    System.arraycopy(mbytes, 0, packet, 8, msglen); 
    packet[8 + msglen] = (byte) 0x00; // null terminate    
    sender.confirmPacket(packet);
  }

}