//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package network;

import java.io.*;
import java.util.*;

import map.*;

import reflection.*;
import CacheDemon;

/**
 *
 * This class implements a "world" that consists on a remote UOX server.
 *  
 */                                                     
public class NetWorld implements NetListener, World {   
 private static final int MAX_WALK_BUF = 5;  
 public int xPos = -1, yPos = -1, zPos = -1;
 public int dir  = -1;
 
 private String server;
 private int port;
 private int key;
 private Reflection reflection;
 private Vector creatures = new Vector();

 private int  walkBuf = 0;
    
 private int  walkSequence = -1;
 private int  playerid;

 /**
  * Pointer to the network threads
  */
  private Network network;
  
  private CacheDemon cacheDemon;
  
 /**
  *
  * Constrcutor
  *
  * @param setNetwork   the network to use.
  *
  */
  public NetWorld(Network network, CacheDemon cacheDemon) 
  {
    this.network    = network;   
    this.cacheDemon = cacheDemon;
    network.setNetListener(this);
  }
        

  public void receivedGameServerList(int flag, NetGameServerList[] servers) 
  {
    System.out.println("Invalid package received in current state (game server list)");
  }
   
  public void loginDenied(int reason)
  {
    System.out.println("Invalid package received in current state (login denied)");
  }

  public void connectGameServer(String server, int port, int key)
  {
     System.out.println("Invalid package received in current state (connect game server)");
  }
    
  public void connectError(String errorMessage)
  {
    System.out.println("Invalid package received in current state (connect error)");
  }
 
  public void receivedCharList(int charCount, String charNames[], String charPasswords[], NetStartLocList startLocList[])
  {
    System.out.println("Invalid package received in current state (received char list)");
  }

  public void setCharLocation(int playerid, int bodyType, int xLoc, int yLoc, int zLoc, int dir, int mode)
  {
    System.out.println("(received char location)");
    this.playerid = playerid;
    xPos = xLoc;
    yPos = yLoc;
    zPos = zLoc;    
    dir  = dir;
    if (reflection != null)
      reflection.teleport(xLoc, yLoc, zLoc);
  } 
       
  public void wornItem(int itemId, int model, int location, int playerId, int color)
  {
    System.out.println("(received worn item)");        
  }
       
  public void drawCreature(int creatureid, int bodyType, int skinColor, int xLoc, int yLoc, int zLoc, int dir, int mode)
  {
    System.out.println("(received draw creature)");                
  }
       
  public void recvStatWindow(int creatureid, String playername, int curHp, int maxHp, int flag, int sex, int str, int dex, int intl, int curStm, int maxStm, int curMana, int maxMana, int gold, int armorClass, int weight)
  {
    if (creatureid == playerid) { // this is me
      System.out.println("(received stat window) for myself");                
      return;
    }    
    NetCreature creature = null;
    for (int i = 0; i < creatures.size(); i++) {
      if (((NetCreature) creatures.elementAt(i)).netid == creatureid) {
        creature =  (NetCreature) creatures.elementAt(i);
      }        
    }
    if (creature == null) {
      System.out.println("ERROR: Creature does not exist");                
      return;        
    }        
    creature.name = playername;
    creature.reflectid = reflection.addCreature(playername, creature.x, creature.y, creature.z);    
    reflection.systemMessage(playername + " is approaching.", 0x4040FF);
    System.out.println("(received stat window) playername: " + playername);                
  }
       
  public void deleteObject(int objid)
  {
    System.out.println("(received delete object)");
  }
       
  public void drawOject(int objid, int model, int xLoc, int yLoc, int zLoc, int dir, int dir2, int dye, int flag, int notoriety, int itemid, int model2, int pos, int hue)
  {
     System.out.print("(received draw object) ");
     if (objid == playerid) {
       System.out.println("(that was me!) ");        
       return;
     }     
     boolean found = false;
     for (int i = 0; i < creatures.size(); i++) {
       if (((NetCreature) creatures.elementAt(i)).netid == objid) {
         found = true;
         break;
       }        
     }
     if (found) {
       System.out.print("(creature already there) ");        
       return;
     }
     NetCreature creature = new NetCreature();
     creature.netid = objid;
     creature.x     = xLoc;
     creature.y     = yLoc;
     creature.z     = zLoc;
     creatures.addElement(creature);
     network.requestPlayerStatus(objid);     
     System.out.println();
  }
        
  public void changeWeather(int type, int amount)
  {
    System.out.println("(received change weather)");                
    switch (type) {
      case 0 : 
         reflection.systemMessage("The suns shines again.", 0x40FF40);
         break;
      case 1 : 
         reflection.systemMessage("It begins to rain.", 0x40FF40);
         break;
      case 2 : 
         reflection.systemMessage("It begins to snow.", 0x40FF40);
         break;                  
      default : 
         System.out.println("ERROR: Unkown wheather type received!");                
         break;
    }
  }
        
  public void requestModeChange(int flag)
  {
    System.out.println("(received request mode change)");                
  }
                
  public void changeTextColor(int index)
  {
    System.out.println("(recv change text color)");
  }
  
  public void redrawRequest()
  {
    System.out.println("(recv redraw request)");
  }   
   
  public void setLightLevel(int level)
  {
    System.out.println("(recv set light level)");
  }
        
  public void recvTime(int hour, int min, int sec)
  {
     System.out.println("(recv time)");
  }

  public void recvSpeech(int itemid, int model, int type, int textcolor, int font, String name, String message)
  {
     if (model == 257) { // System message
       System.out.println("(recv system speech)");
       if (reflection != null) {        
         reflection.systemMessage(message, 0xFFFFFF);
       }
       return;
     }
     System.out.println("(recv non system speech) color = 0x" + Integer.toHexString(textcolor));
     // search creature
     NetCreature creature = null;
     for (int i = 0; i < creatures.size(); i++) {
       if (((NetCreature) creatures.elementAt(i)).netid == itemid) {
         creature = (NetCreature) creatures.elementAt(i);
         break;
       }        
     }     
     if (creature == null) {
       if (itemid == playerid) { // this was me speaking
         reflection.systemMessage("You: " + message, 0xFFFFFF);
         return;
       } else {
         System.out.println("NetWorld: ERROR, creature id not found." + model);        
         return;
       }
     }    
     
     if (reflection != null)
       reflection.creatureSpeak(creature.reflectid, message, 0xFFFF00);
  }

  public void noticeWindow(int flag, int tipnr, String message)
  {
     System.out.println("(recv notice window)");     
  }

  public void playMusic(int musicID)
  {
     System.out.println("(recv play music)");
  }

 /**
  * from Reflection
  */
  public synchronized int walk(int direction, boolean run) 
  {
    //System.out.println("Walk, World:  X: " + xPos + " Y: " + yPos + " Z: " + zPos);
    //System.out.println("Walk, Reflect X: " + reflection.xPos + " Y: " + reflection.yPos + " Z: " + reflection.zPos);
    if (walkBuf == MAX_WALK_BUF) {
      System.out.println("networld, walk request denied due of lag.");
      return 256;
    }
    if (direction != dir) {
      // just turned over face
      walkBuf++;
      dir = direction;
      if (++walkSequence == 0x100)
        walkSequence = 0;    
      network.walk(direction, walkSequence, run);                          
      return 256; // walk deny
    }        
    // real walking
    int newx;
    int newy;
    int newz;
    switch (direction) {
      case Reflection.UP    : newy = yPos + 1; newx = xPos - 1; break;
      case Reflection.NORTH : newy = yPos - 1; newx = xPos;     break;
      case Reflection.RIGHT : newy = yPos + 1; newx = xPos + 1; break;
      case Reflection.EAST  : newy = yPos;     newx = xPos + 1; break;
      case Reflection.DOWN  : newy = yPos - 1; newx = xPos + 1; break;
      case Reflection.SOUTH : newy = yPos + 1; newx = xPos;     break;
      case Reflection.LEFT  : newy = yPos - 1; newx = xPos - 1; break;
      case Reflection.WEST  : newy = yPos;     newx = xPos - 1; break;
      default :
        newx = 0; newy = 0; // just to make compiler happy
        System.out.println("INTERNAL FATAL, unkown direction");
        System.exit(-1);
    }
    StaticCell sCell = cacheDemon.getStaticCell(newx, newy);
    MapCell mCell = cacheDemon.getMapCell(newx, newy, false);
    newz = mCell.zpos >> 2;
    
    // first check for floats, not falling down to deepest
    for (int i = 0; i < sCell.tiles.length; i++) {
      StaticParticle apart = sCell.tiles[i];
      StaticTileData tiledata = apart.tiledata;
      if ((apart.z <= zPos) && ((tiledata.flags & 0x00020000) != 0)) {
        //System.out.println("NetWorld: floating due to tile 0x" + Integer.toHexString(apart.id));
        newz = apart.z + tiledata.height;
      } else {
        //System.out.println("NetWorld: NOT floating due to tile 0x" + Integer.toHexString(apart.id) + " at height " + apart.z);                
      }
    } 

    // not check for climbs
    int climbon = -1;
    for (int i = 0; i < sCell.tiles.length; i++) {
      StaticParticle apart = sCell.tiles[i];
      StaticTileData tiledata = apart.tiledata;
      if ((apart.z >= newz) && (apart.z <= newz + 16)) {      
        if ((tiledata.flags & 0x00040000) != 0) {
          //System.out.println("NetWorld: climbing due to tile 0x" + Integer.toHexString(apart.id));
          newz = apart.z + tiledata.height;
          climbon = i;
          continue;
        }
      }
    } 
    
    // finally look if something there blocking
    for (int i = 0; i < sCell.tiles.length; i++) {
      if (i == climbon)
        continue;
      StaticParticle apart = sCell.tiles[i];
      StaticTileData tiledata = apart.tiledata;
      if ((apart.z >= newz) && (apart.z <= newz + 16)) {      
        if ((tiledata.flags & 0x40000000) != 0) {
          System.out.println("NetWorld: walk blocked due to tile 0x" + Integer.toHexString(apart.id) + " at height " + apart.z);
          return 256; // walk deny
        }
      }
    } 
    // no blocking send to network
    yPos = newy;
    xPos = newx;
    zPos = newz;
    if (++walkSequence == 0x100)
      walkSequence = 0;    
    network.walk(direction, walkSequence, run);                          
    /*
    switch (direction) {
      case Reflection.UP    : yPos++; xPos--; break;
      case Reflection.NORTH : yPos++;         break;
      case Reflection.RIGHT : yPos++; xPos++; break;
      case Reflection.EAST  : xPos++;         break;
      case Reflection.DOWN  : yPos--; xPos++; break;
      case Reflection.SOUTH : yPos--;         break;
      case Reflection.LEFT  : yPos--; xPos--; break;
      case Reflection.WEST  : xPos--;         break;
    }
    */
    return zPos; // walk allow
  }
   
  public void moveReject(int sequence, int xLoc, int yLoc, int zLoc, int dir)
  {
     System.out.println("(move reject)");
     // reset walk buffer and teleport
     walkBuf      =  0;
     walkSequence = -1;     
     xPos = xLoc;
     yPos = yLoc;
     zPos = zLoc;
     if (reflection != null)
       reflection.teleport(xLoc, yLoc, zLoc);
  }

  public void moveAck(int sequence)
  {
     System.out.println("(move ack)");
     if (walkBuf > 0)
       walkBuf--;
  }
    
  public void sendPlayer(int playerid, int model, int xLoc, int yLoc, int zLoc, int dir, int color, int mode, int noto)
  {
     System.out.print("(recv send player)");
     NetCreature creature = null;     
     for (int i = 0; i < creatures.size(); i++) {
       if (((NetCreature) creatures.elementAt(i)).netid == playerid) {
         creature = (NetCreature) creatures.elementAt(i);
         break;
       }        
     }
     if (creature == null) {
       System.out.println("(ERROR unkown creature!) ");        
       return;
     }
     creature.x = xLoc;
     creature.y = yLoc;
     creature.z = zLoc;   
     if (creature.reflectid != -1)
       reflection.updateCreature(creature.reflectid, xLoc, yLoc, zLoc);       
     System.out.println();
  }

  public void updatehp(int playerid, int maxhp, int curhp)
  {
     System.out.println("(recv update hp)");        
  }

  public void updateMana(int playerid, int maxMana, int curMana)
  {
     System.out.println("(recv update mana)");
  }

  public void updateStamina(int playerid, int maxStamina, int curStamina)
  {
     System.out.println("(recv update stamina)");
  }    

  // reflection system start up
  public void setReflection(Reflection reflection) 
  {
    this.reflection = reflection;
  }

  public void interrupt()
  {
    // nothing
  }
 
  public int getZpos()
  {
    return zPos;     
  }
  
 /**
  * called form reflection
  */
  public void talkRequest(String message)
  {
    network.talkRequest(0, 0x02b2, 3, message);
  }
 
}

class NetCreature {
  int netid;
  int reflectid = -1;
  String name;          
  int x;
  int y; 
  int z;
}