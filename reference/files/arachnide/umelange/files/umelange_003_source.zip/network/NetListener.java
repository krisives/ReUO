//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package network;

/**
 *
 * Interface that is used for classes that want to receive network packets.
 *  
 */                                                     
public interface NetListener {                   
  /**
   * Login denied -  packed 0x82 
   *
   * @param reason   A integer descripting the reason
   *   
   */
   public void loginDenied(int reason);

  /**
   * Connect to game server -  packed 0x8C
   *
   * @param server   New server to connect to.
   * @param port     Port to connect to.
   * @param key      New encryption key.
   *   
   */
   public void connectGameServer(String server, int port, int key);
   
  /**
   * A packed 0xA8 has been received, telling about the game servers
   *
   * @param flag     The flag that has been received.
   * @param servers  The list of the game servers received.
   *   
   */
   public void receivedGameServerList(int flag, NetGameServerList servers[]);
   
   
  /**
   * An error occured during connect.
   *
   * @param flag     The flag that has been received.
   * @param servers  The list of the game servers received.
   *   
   */
   public void connectError(String errorMessage);

  /**
   * Received charactler list. (0xA9 packet)
   *
   * @param flag     The flag that has been received.
   * @param servers  The list of the game servers received.
   *   
   */
   public void receivedCharList(int charCount, String charNames[], String charPasswords[], NetStartLocList startLocList[]);
   
  /**
   * Received charactler list. (0x1B packet)
   *
   * @param playerId     ???
   * @param bodyType     ???
   * @param xLoc         x location
   * @param yLoc         y location
   * @param zLoc         z location
   * @param dir          direction looking
   * @param mode         normal, attack, hidden
   *   
   */
   public void setCharLocation(int playerId, int bodyType, int xLoc, int yLoc, int zLoc, int dir, int mode);

  /**
   * Received a worn item. (0x2E packet)
   *
   * @param itemId       ???
   * @param model        ???
   * @param location
   * @param playerId 
   * @param color
   *
   */
   public void wornItem(int itemId, int model, int location, int playerId, int color);

  /**
   * Received a draw creature. (0x20 packet)
   *
   * @param creatureid
   * @param bodyType
   * @param skinColor
   * @param xLoc
   * @param yLoc
   * @param zLoc
   * @param dir
   * @param mode
   *
   */
   public void drawCreature(int creatureid, int bodyType, int skinColor, int xLoc, int yLoc, int zLoc, int dir, int mode);
   
  /**
   * Received a stat window creature. (0x11 packet)
   *
   * @param playername      the players name
   * @param curHp           current hit points
   * @param maxHp           maximal hit points
   * @param flag            ???
   * @param sex             0..male   1..female
   * @param str             strength
   * @param dex             dexterenty
   * @param intl            inteligence
   * @param curStm          current stamina
   * @param maxStm          maximum stamina
   * @param curMana         current mana
   * @param maxMana         maximum mana
   * @param gold            gold on player
   * @param armorClass      armor class
   * @param weight          weight of player
   *
   */      
   public void recvStatWindow(int creatureId, String playername, int curHp, int maxHp, int flag, int sex, int str, int dex, int intl, int curStm, int maxStm, int curMana, int maxMana, int gold, int armorClass, int weight);
   
   
  /**
   * Received a delete object command. (0x1d packet)
   *
   * @param objid           object to delete
   *
   */      
   public void deleteObject(int objid);
   
   
  /**
   * Received a draw object command. (0x78 packet)
   *
   * this packed is very very weired....
   *
   */      
   public void drawOject(int objid, int model, int xLoc, int yLoc, int zLoc, int dir, int dir2, int dye, int flag, int notoriety, int itemid, int model2, int pos, int hue);
  
  
  /**
   * Change weather. (0x65 packet)
   *  
   * @param type     type of weather 
   * @param amount   amount of weather
   */
   public void changeWeather(int type, int amount);
  
  /**
   * Request mode change. (0x72 packet)
   *  
   * @param flag     0 normal
   *                 1 fighting
   */  
   public void requestModeChange(int flag);
 
  /**
   * Set overall light level. (0x4F packet)
   *  
   * @param level      0 day
   *                   9 night
   *                0x7f overall
   */  
   public void setLightLevel(int level);

  /**
   * Change text color. (0x69 packet)
   *  
   *  use unkown
   */  
   public void changeTextColor(int index);

  /**
   * Redraw-all request (0x55 packet)
   *  
   * no parmaters
   *
   */  
   public void redrawRequest();

  /**
   * Time (0x5B packet)
   *  
   * @param hour
   * @param min
   * @param sec
   *
   */  
   public void recvTime(int hour, int min, int sec);

  /**
   * received speech (0x1C packet)
   *  
   * @param itemid   who says it
   * @param model    ???
   * @param type     0x00 - Regular 
   *                 0x02 - Emote 
   *                 0x06 - System 
   *                 0x09 - Yell 
   * @param textcolor   
   * @param font
   * @param name     name of speaker?
   * @param message
   *
   */  
   public void recvSpeech(int itemid, int model, int type, int textcolor, int font, String name, String message);


  /**
   * notice/tips window (0xA6 packet)
   *  
   * @param flag
   * @param tipnr
   * @param message
   *
   */  
   public void noticeWindow(int flag, int tipnr, String message);

  /**
   * notice/tips window (0x6D packet)
   *  
   * @param flag
   * @param tipnr
   * @param message
   *
   */  
   public void playMusic(int musicID);

  /**
   * rejected move
   *  
   * @param sequence
   * @param xLoc
   * @param yLoc
   * @param zLoc
   * @param dir
   *
   */  
   public void moveReject(int sequence, int xLoc, int yLoc, int zLoc, int dir);   

  /**
   * accepted move
   *  
   * @param sequence
   * @param xLoc
   * @param yLoc
   * @param zLoc
   * @param dir
   *
   */  
   public void moveAck(int sequence);

 
  /**
   * a char on screen has moved
   *  
   * @param playerid
   * @param model
   * @param xLoc
   * @param yLoc
   * @param zLoc
   * @param dir
   * @param color
   * @param mode
   * @param noto
   *
   */  
   public void sendPlayer(int playerid, int model, int xLoc, int yLoc, int zLoc, int dir, int color, int mode, int noto);

  /**
   * update hitpoints
   *  
   * @param playerid
   * @param maxhp
   * @param curhp
   *
   */  
   public void updatehp(int playerid, int maxhp, int curhp);

  /**
   * update mana
   *  
   * @param playerid
   * @param maxMana
   * @param curMana
   *
   */  
   public void updateMana(int playerid, int maxMana, int curMana);

  /**
   * update stamina
   *  
   * @param playerid
   * @param maxStamina
   * @param curStamina
   *
   */  
   public void updateStamina(int playerid, int maxStamina, int curStamina);
 }