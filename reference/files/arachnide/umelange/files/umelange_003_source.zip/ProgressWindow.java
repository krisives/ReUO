//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.*;

/**
 *
 * This is the window where running mode is gathered. <br>
 *
 */

public class ProgressWindow extends Frame {      
 Label progress;        
 int maxsteps = 0;
 int cstep    = 0;
        
 public ProgressWindow(int maxsteps) 
 {    
   //Create the top-level container and add contents to it.
   super("Ultimate Melange 0.0.3 - Creating classicUO.skin");
   this.maxsteps = maxsteps;
   
   //setResizable(false);
   //setBackground(Color.lightGray);
   
   //setSize(320,240);
   setLayout(new GridLayout(6, 0));
   progress = new Label("0% finished", Label.CENTER);
   Label Label1 = new Label("Creating classicUO.skin ...", Label.CENTER);
   Label Label2 = new Label("This may take some minutes and will take approximately 45MB harddisk space", Label.CENTER);
   Label Label3 = new Label("The skin file is an optimized data file for static sprites of art.mul ...", Label.CENTER);
   Label Label4 = new Label("If you cancled this job, delete classicUO.skin for proper operation.", Label.CENTER);
   Label Label5 = new Label("", Label.CENTER);
   add(Label1);   
   add(Label2);   
   add(Label3);   
   add(Label4);   
   add(Label5);   
   add(progress);   

   pack();
   validate();
   setVisible(true);
 }

 public void step() {
   cstep++;
   progress.setText(((cstep * 100) / maxsteps) + "% finished");
 }
}


