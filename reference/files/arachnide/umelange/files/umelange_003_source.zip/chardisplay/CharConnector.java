/****************************************************************
  File: CharConnector.java

  Description:
     Implementation of a 3D panel.

  Author: Axk

  Last change:  AXK  30 Jun 100   12:05 pm

****************************************************************/
package chardisplay;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.text.*;

import network.*;
import reflection.*;
import CacheDemon;
import IniFile;
import Main;

/***
 *
 ***/
class CharConnector implements NetListener {
  CharPanel cPanel;
 /**
  * CacheDemon is not used itself by this class,
  * but needed to create game interface.
  */
  CacheDemon cacheDemon;
  private final static int SCREEN_WELCOME                  = 0;
  private final static int SCREEN_LOGIN                    = 1;
  private final static int SCREEN_CONNECTING               = 2; 
  private final static int SCREEN_LOGIN_MESSAGE            = 3;
  private final static int SCREEN_SERVER_SELECTION         = 4;
  private final static int SCREEN_SERVER_SELECTION_MESSAGE = 5;
  private final static int SCREEN_CONNECTING_GAMESERVER    = 6; 
  private final static int SCREEN_CHAR_SELECTION           = 7; 
  private final static int SCREEN_STARTING_GAME            = 8;
  
  private int currentScreen = SCREEN_WELCOME;
  private int focus         = 0;
  private NetGameServerList[] servers;
  
  private boolean shift = false;
  
  private StringBuffer server;
  private StringBuffer port;
  private StringBuffer account;
  private StringBuffer password;
  
  private int charCount;
  private String charNames[];

  private IniFile iniFile;

 /**
  * Pointer to the network threads
  */
  Network network;

  public CharConnector(CharPanel charPanel, CacheDemon setCacheDemon, IniFile setIniFile, String setServer, int setPort, String setAccount, String setPassword)
  {
    cPanel     = charPanel;
    iniFile    = setIniFile;
    cacheDemon = setCacheDemon; // not really used by this class, but needed to create game interface
    server     = new StringBuffer(setServer);
    port       = new StringBuffer(new Integer(setPort).toString());
    account    = new StringBuffer(setAccount);
    password   = new StringBuffer(setPassword);
    
    //setLocation(50,50);
    cPanel.addKeyListener( new KeyListener() {
      public void keyTyped (KeyEvent e )
      {
        // nothing
      }
      public void keyPressed  (KeyEvent e ) {
        int  key = e.getKeyCode();
        char c   = e.getKeyChar();
        if (key == KeyEvent.VK_SHIFT)
          shift = true;
        if ((int) e.getKeyChar() == KeyEvent.VK_BACK_SPACE ) {
          StringBuffer sb = null;
          switch (focus) {
            case 0: sb = server; break;
            case 1: sb = port; break;
            case 2: sb = account; break;
            case 3: sb = password; break;
          }
          if (sb != null) {
            if (sb.length() > 0)
              sb.setLength(sb.length() - 1);
            drawScreen();
          }
        }
        if ((int) e.getKeyChar() == KeyEvent.VK_TAB ) {
          if (currentScreen == SCREEN_LOGIN) {
            if (!shift) {
              if (++focus >= 5)
                focus = 0;            
            } else {
              if (--focus < 0)
                focus = 4;            
              //System.out.println("FOCUS: " + focus);
            }
            drawScreen();
          }
        }
        if (currentScreen == SCREEN_LOGIN) {
          switch (focus) {
            case 0: // Server 
                if (Character.isLetterOrDigit(c) || (c=='.') || (c=='_') || (c=='-')) {             
                  server.append(c);      
                  drawScreen();                
                }
                break;
            case 1: // Port
                if (Character.isDigit(c)) {             
                  port.append(c);      
                  drawScreen();                
                }
                break;
            case 2: // Account
                if ((c >= 32 ) && (c <=127)) {             
                  account.append(c);      
                  drawScreen();                
                }
                break;
            case 3: // Password
                if ((c >= 32 ) && (c <=127)) {             
                  password.append(c);      
                  drawScreen();                
                }
                break;
          }
        }
        if ((int) e.getKeyCode() == KeyEvent.VK_UP ) {                
          switch (currentScreen) {
            case SCREEN_SERVER_SELECTION:
                if (focus > 0)
                  focus--;
                drawScreen();
                break;
            case SCREEN_CHAR_SELECTION:
                if (focus > 0)
                  focus--;
                drawScreen();
                break;
          }
        }
        if ((int) e.getKeyCode() == KeyEvent.VK_DOWN ) {
          switch (currentScreen) {
            case SCREEN_SERVER_SELECTION:
                if (servers != null)
                  if (focus < (servers.length - 1))
                    focus++;
                  drawScreen();
                break;
            case SCREEN_CHAR_SELECTION:
                if (focus < (charCount - 1))
                  focus++;
                drawScreen();
                break;
          }
        }
        if ((int) e.getKeyCode() == KeyEvent.VK_RIGHT ) {
          //System.out.println("RIGHT PRESSED: ");
          //cPanel.repaint();
        }
        if ((int) e.getKeyCode() == KeyEvent.VK_LEFT ) {
          //System.out.println("LEFT PRESSED: ");
          //cPanel.repaint();
        }
        if ((int) e.getKeyCode() == KeyEvent.VK_ENTER ) {
          switch (currentScreen) {
            case SCREEN_LOGIN_MESSAGE :
            case SCREEN_WELCOME :
               currentScreen = SCREEN_LOGIN;
               drawScreen();               
               break;                          
            case SCREEN_SERVER_SELECTION_MESSAGE  :
               currentScreen = SCREEN_SERVER_SELECTION;
               drawScreen();               
               break;                                      
            case SCREEN_LOGIN :
               if (focus == 4) {
                 int iport = 2593;
                 currentScreen = SCREEN_CONNECTING;
                 try {
                   iport = Integer.parseInt(port.toString());
                 } catch (NumberFormatException ex) {
                   System.out.println("char: Port is an integer taking default 2593");
                 }
                 iniFile.setParameter("Server", server.toString());
                 iniFile.setParameter("Port", port.toString());
                 iniFile.setParameter("Account", account.toString());
                 iniFile.setParameter("Password",password.toString());
                 iniFile.flush();
                 cPanel.deleteArea(26,10,26,4);
                 cPanel.doubleRect(26,10,52,14,0xFFFF00,true);
                 cPanel.putString(32,12,"Connecting ...");
                 cPanel.redraw();
                 network = new Network();
                 firstLogin(server.toString(), iport, account.toString(), password.toString());
               } else {
                 focus++;
                 drawScreen();
               }     
               break;           
            case SCREEN_SERVER_SELECTION :
                currentScreen = SCREEN_CONNECTING_GAMESERVER;
                cPanel.deleteArea(22,10,30,4);
                cPanel.doubleRect(22,10,56,14,0xFFFF00,true);
                cPanel.putString(25,12,"Connecting to game server ...");
                cPanel.redraw();               
                network.sendServerSelector(focus + 1);                
                break;
                
            case SCREEN_CHAR_SELECTION :
                currentScreen = SCREEN_STARTING_GAME;
                cPanel.deleteArea(28,10,25,4);
                cPanel.doubleRect(28,10,51,14,0xFFFF00,true);
                cPanel.putString(31,12,"Starting game ...");
                cPanel.redraw();               
                // game start
                NetWorld world = new NetWorld(network, cacheDemon);
                Display display = new CharDisplay(cPanel, cacheDemon);
                Main.startGame(world,display);
                network.sendCharLogin(focus, charNames[focus]);
                break;                
                
            default:     
          }
        }
      }

      public void keyReleased (KeyEvent e )
      {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_SHIFT)
          shift = false;
      }
    });

    drawScreen();
  }

  private void drawScreen()
  {
    cPanel.clrscr();
    switch (currentScreen) {
      case SCREEN_WELCOME :            
          for (int x = 0; x < 80; x++) {
            for (int y = 0; y < 24; y++) {
              if (y < 10) {
                if (CharWelcomeScreen.chars[y][x]==0x2593) {        
                  cPanel.putChar(x,y,CharWelcomeScreen.chars[y][x], 0xFF1F1F);
                } else if (CharWelcomeScreen.chars[y][x]==0x2592) {        
                  cPanel.putChar(x,y,CharWelcomeScreen.chars[y][x], 0xA02020);
                } else
                  cPanel.putChar(x,y,CharWelcomeScreen.chars[y][x]);
              } else {
                if (CharWelcomeScreen.chars[y][x]==0x2593) {        
                  cPanel.putChar(x,y,CharWelcomeScreen.chars[y][x], 0xB88838);
                } else if (CharWelcomeScreen.chars[y][x]==0x2592) {        
                  cPanel.putChar(x,y,CharWelcomeScreen.chars[y][x], 0x735523);
                } else
                  cPanel.putChar(x,y,CharWelcomeScreen.chars[y][x]);
              } 
           }
         }
         cPanel.doubleRect(2,20,16,22, 0xFF8080, false);
         cPanel.putString(4,21,"PRESS ENTER");         
         break;
      case SCREEN_LOGIN :            
         cPanel.doubleRect(3,1,75,3, false);
         cPanel.doubleRect(3,3,75,21, false);
         cPanel.putString(28,2,"Login configuration", 0x00FFFF);

         cPanel.putString(7,6,"Server:");
         if (focus == 0)
           cPanel.singleRect(19,5,69,7, 0xFF8080, false);
         else
           cPanel.singleRect(19,5,69,7,  false);
         cPanel.putString(21,6,server.toString());
               
         cPanel.putString(7,9,"Port:");
         if (focus == 1)
           cPanel.singleRect(19,8,69,10, 0xFF8080, false);
         else
           cPanel.singleRect(19,8,69,10, false);
         cPanel.putString(21,9,port.toString());

  
         cPanel.putString(7,12,"Account:");
         if (focus == 2)
           cPanel.singleRect(19,11,69,13, 0xFF8080,  false);
         else
           cPanel.singleRect(19,11,69,13, false);
         cPanel.putString(21,12,account.toString());

         cPanel.putString(7,15,"Password:");
         if (focus == 3)
           cPanel.singleRect(19,14,69,16, 0xFF8080, false);
         else
           cPanel.singleRect(19,14,69,16, false);
         cPanel.putString(21,15,password.toString());
               
         if (focus == 4)
           cPanel.putString(70,19,">>>", 0xFFFF00);
         else
           cPanel.putString(70,19,">>>", 0x808000);
         break;
      case SCREEN_SERVER_SELECTION :
         cPanel.doubleRect(3,1,75,3, false);
         cPanel.doubleRect(3,3,75,21, false);
         cPanel.doubleRect(7,3,71,21, false);
         cPanel.putString(28,2,"Gameserver selection", 0x00FFFF);
         cPanel.putString( 4,4 + focus,">>>", 0xFFFF00);
         cPanel.putString(72,4 + focus,"<<<", 0xFFFF00);
        
         for(int i = 0; i < servers.length; i++) {
           cPanel.putString((80 - servers[i].serverName.length()) / 2,4 + i,servers[i].serverName);
         }                          
         break;
      case SCREEN_CHAR_SELECTION :
         cPanel.doubleRect(3,1,75,3, false);
         cPanel.doubleRect(3,3,75,21, false);
         cPanel.doubleRect(7,3,71,21, false);
         cPanel.putString(28,2,"Character selection", 0x00FFFF);
         cPanel.putString( 4,4 + focus,">>>", 0xFFFF00);
         cPanel.putString(72,4 + focus,"<<<", 0xFFFF00);
        
         for(int i = 0; i < charCount; i++) {
           cPanel.putString((80 - charNames[i].length()) / 2,4 + i,charNames[i]);
         }                          
         break;
    }
    cPanel.redraw();
  }


 private void firstLogin(String server, int port, String account, String password)
 {
   network.setNetListener(this);
   network.connect(server, 2593, false);
   network.sendSeed();
   network.sendLoginRequest(account, password);
 }

 public void receivedGameServerList(int flag, NetGameServerList[] getServers) 
 {
   network.sendWelcomeReply(); // Send the hardware "statics" package back to the server
   currentScreen = SCREEN_SERVER_SELECTION;
   focus = 0;
   servers = getServers;
   for (int i = 0; i < servers.length; i++) {
     int ip1 = (int) (servers[i].pingIP & 0xFF000000) >> 24;
     if (ip1 < 0) ip1 = (ip1 ^ 0xFF) - 1;      
     int ip2 = (int) (servers[i].pingIP & 0x00FF0000) >> 16;
     if (ip2 < 0) ip2 = (ip2 ^ 0xFF) - 1;      
     int ip3 = (int) (servers[i].pingIP & 0x0000FF00) >>  8;
     if (ip3 < 0) ip3 = (ip3 ^ 0xFF) - 1;      
     int ip4 = (int) (servers[i].pingIP & 0x000000FF);
     if (ip4 < 0) ip4 = (ip4 ^ 0xFF) - 1;      
     System.out.println("" + servers[i].serverIndex + " :" + servers[i].serverName + " IP:" + 
                        ip1 + '.' + ip2 + '.' + ip3 + '.' + ip4);
   }
   drawScreen();
 }
    
 public void loginDenied(int reason)
 {
   switch (currentScreen) {
     case SCREEN_CONNECTING  :
       {
         currentScreen = SCREEN_LOGIN_MESSAGE;
         focus = 0;
         String message;
         switch (reason) {
           case 0x00 : message = "Unknown user.";           break;
           case 0x01 : message = "Account already in use."; break;
           case 0x02 : message = "Account disabled.";       break;
           case 0x03 : message = "Password bad";            break;
           case 0x04 : 
           default   : message = "Communications failed.";  break;
         }
         
         int xpos = (80 - message.length() - 6) / 2;
         int len  = message.length() + 6;
         cPanel.deleteArea(xpos,8,len,8);
         cPanel.doubleRect(xpos,8,xpos+len,16,0xFF4040,true);
         cPanel.putString(xpos + 3,10,message);
         cPanel.singleRect(37, 13, 43, 15, 0xFF8080, true);
         cPanel.putString(39,14,"OK");
         cPanel.redraw();
         break;
      }
     case SCREEN_CONNECTING_GAMESERVER  :
      {
         currentScreen = SCREEN_SERVER_SELECTION_MESSAGE;
         focus = 0;
         String message;
         switch (reason) {
           case 0x00 : message = "Unknown user.";           break;
           case 0x01 : message = "Account already in use."; break;
           case 0x02 : message = "Account disabled.";       break;
           case 0x03 : message = "Password bad";            break;
           case 0x04 : 
           default   : message = "Communications failed.";  break;
         }
         
         int xpos = (80 - message.length() - 6) / 2;
         int len  = message.length() + 6;
         cPanel.deleteArea(xpos,8,len,8);
         cPanel.doubleRect(xpos,8,xpos+len,16,0xFF4040,true);
         cPanel.putString(xpos + 3,10,message);
         cPanel.singleRect(37, 13, 43, 15, 0xFF8080, true);
         cPanel.putString(39,14,"OK");
         cPanel.redraw();
         break;
       }           
     default :
         System.out.println("Invalid package received in current state (login denied) {screen:" + currentScreen + "}");
         break;                
   } 
 }

 public void connectGameServer(String server, int port, int key)
 {
   System.out.println("Gameserverconnect received. Server:" + server);  
   network.disconnect();
   network.connect(server,port, true);
   network.sendSeed();
   network.sendGameLogin(account.toString(), password.toString(), key);
 }

 public void connectError(String errorMessage)
 {
   switch (currentScreen) {
     case SCREEN_CONNECTING  :
      {
         currentScreen = SCREEN_LOGIN_MESSAGE;
         focus = 0;
         int xpos = (80 - errorMessage.length() - 6) / 2;
         int len  = errorMessage.length() + 6;
         cPanel.deleteArea(xpos,8,len,8);
         cPanel.doubleRect(xpos,8,xpos+len,16,0xFF4040,true);
         cPanel.putString(xpos + 3,10,errorMessage);
         cPanel.singleRect(37, 13, 43, 15, 0xFF8080, true);
         cPanel.putString(39,14,"OK");
         cPanel.redraw();
         break;
      }            
     case SCREEN_CONNECTING_GAMESERVER :
      {
         currentScreen = SCREEN_SERVER_SELECTION_MESSAGE;
         focus = 0;
         int xpos = (80 - errorMessage.length() - 6) / 2;
         int len  = errorMessage.length() + 6;
         cPanel.deleteArea(xpos,8,len,8);
         cPanel.doubleRect(xpos,8,xpos+len,16,0xFF4040,true);
         cPanel.putString(xpos + 3,10,errorMessage);
         cPanel.singleRect(37, 13, 43, 15, 0xFF8080, true);
         cPanel.putString(39,14,"OK");
         cPanel.redraw();
         break;
      }       
     default :
         System.out.println("Invalid package received in current state (connect error) at screen:" + currentScreen);
         break;                
   } 
        
 }

 public void receivedCharList(int charCount, String charNames[], String charPasswords[], NetStartLocList startLocList[])
 {
   switch (currentScreen) {
     case SCREEN_CONNECTING_GAMESERVER  :
         currentScreen = SCREEN_CHAR_SELECTION;
         focus = 0;
         int realCharCount = 0;
         while (realCharCount < charCount) {
            if (charNames[realCharCount].length() > 0)
              realCharCount++;
            else
              break;
         }
         this.charCount = realCharCount;
         this.charNames = charNames;
         drawScreen();
         break;                  
     default :
         System.out.println("Invalid package received in current state (received char list)");
         break;                
   }         
 }

 public void setCharLocation(int playerId, int bodyType, int xLoc, int yLoc, int zLoc, int dir, int mode)
 {
    System.out.println("Invalid package received in current state. (set character location)");
 }

 public void wornItem(int itemId, int model, int location, int playerId, int color)
 {
    System.out.println("Invalid package received in current state. (worn item)");        
 }
 
 public void drawCreature(int creatureid, int bodyType, int skinColor, int xLoc, int yLoc, int zLoc, int dir, int mode)
 {
    System.out.println("Invalid package received in current state. (draw creature)");                
 }

 public void recvStatWindow(int creatureId, String playername, int curHp, int maxHp, int flag, int sex, int str, int dex, int intl, int curStm, int maxStm, int curMana, int maxMana, int gold, int armorClass, int weight)
 {
    System.out.println("Invalid package received in current state. (stat window)");                
 }

 public void deleteObject(int objid)
 {
    System.out.println("Invalid package received in current state. (delete object)");
 }
 
 public void drawOject(int objid, int model, int xLoc, int yLoc, int zLoc, int dir, int dir2, int dye, int flag, int notoriety, int itemid, int model2, int pos, int hue)
 {
    System.out.println("Invalid package received in current state. (draw object)");        
 }

 public void changeWeather(int type, int amount)
 {
    System.out.println("Invalid package received in current state. (change weather)");                
 }
 
 public void requestModeChange(int flag)
 {
    System.out.println("Invalid package received in current state. (requestModeChange)");                
 }
 
 public void setLightLevel(int level)
 {
    System.out.println("Invalid package received in current state. (set light level)");
 }

 public void changeTextColor(int index)
 {
    System.out.println("Invalid package received in current state. (change text color)");
 }

 public void redrawRequest()
 {
    System.out.println("Invalid package received in current state. (redraw request)");
 }

 public void recvTime(int hour, int min, int sec)
 {
    System.out.println("Invalid package received in current state. (time)");
 }

 public void recvSpeech(int itemid, int model, int type, int textcolor, int font, String name, String message)
 {
    System.out.println("Invalid package received in current state. (received speech)");
 }

 public void noticeWindow(int flag, int tipnr, String message)
 {
    System.out.println("Invalid package received in current state. (notice window)");
 }

 public void playMusic(int musicID)
 {
    System.out.println("Invalid package received in current state. (play music)");
 }

 public void moveReject(int sequence, int xLoc, int yLoc, int zLoc, int dir)
 {
    System.out.println("Invalid package received in current state. (move reject)");
 }

 public void moveAck(int sequence)
 {
    System.out.println("Invalid package received in current state. (move ack)");
 }

 public void sendPlayer(int playerid, int model, int xLoc, int yLoc, int zLoc, int dir, int color, int mode, int noto)
 {
    System.out.println("Invalid package received in current state. (send player)");
 }
 
 public void updatehp(int playerid, int maxhp, int curhp)
 {
    System.out.println("Invalid package received in current state. (update hp)");
 }
 
 public void updateMana(int playerid, int maxMana, int curMana)
 {
    System.out.println("Invalid package received in current state. (update mana)");
 }

 public void updateStamina(int playerid, int maxStamina, int curStamina)
 {
    System.out.println("Invalid package received in current state. (update stamina)");
 } 
 
}