//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
package chardisplay;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.text.*;

import reflection.*;
import map.*;
import CacheDemon;

/***
 *
 ***/
class CharDisplay implements Display, Runnable {
 /**
  * Pointer to the character panel
  */
  private CharPanel display;

 /**
  * Pointer to the character panel
  */
  private Thread  heartBeat;
  
 /**
  * Pointer to the cache demon 
  */
  private CacheDemon cacheDemon;
  
 /**
  * Current x coordinate of the player in the world.
  */     
  //int           currentX  = 1472;  //Britain
  //int           currentX  = 10;  //Britain

 /**
  * Current y coordinate of the player in the world.
  */     
  //int           currentY  = 10;

  public boolean running = true;;
  
  private Reflection reflection;
  
  private StringBuffer typeMessage = new StringBuffer();
  
  private int mecolor   = 0x8080FF;
  private int colorglow = 0x010100;
  
  private final int maxcolor = 0xB0B0FF;
  private final int mincolor = 0x6060FF;

  public CharDisplay(CharPanel display, CacheDemon cacheDemon)
  {
    this.display    = display;
    this.cacheDemon = cacheDemon;

    CharStaticTiles.init();
    //setLocation(50,50);
    display.addKeyListener( new KeyListener() {
      public void keyTyped (KeyEvent e )
      {
        // nothing
      }
      
      public void keyPressed  (KeyEvent e ) {
        if (reflection == null)
          return;
        int keycode = e.getKeyCode();
        switch (keycode) {
          case KeyEvent.VK_RIGHT :
            if (reflection.walk(reflection.EAST, false)) {
              drawScreen();
            }
            break;
          case KeyEvent.VK_LEFT :
            if (reflection.walk(reflection.WEST, false)) {
              drawScreen();
            }
            break;
          case KeyEvent.VK_DOWN :
            if (reflection.walk(reflection.SOUTH, false)) {
              drawScreen();
            }
            break;            
          case KeyEvent.VK_UP :
            if (reflection.walk(reflection.NORTH, false)) {
              drawScreen();
            }           
            break;            
          case KeyEvent.VK_BACK_SPACE :
            if (typeMessage.length() > 0) {
              typeMessage.setLength(typeMessage.length() - 1);
            }
            drawScreen();
            break;
          case KeyEvent.VK_ENTER :
            if (typeMessage.length() > 0) {
              reflection.talkRequest(typeMessage.toString());
              typeMessage.setLength(0);
            }
            break;
        }
        char ch = e.getKeyChar();
        if (Character.isLetterOrDigit(ch) || 
            ch == ' ' || ch == '/' || ch == '.' || ch == '-' ||
            ch == '!' || ch == '"' || ch == '$' || ch == '%' || 
            ch == '(' || ch == ')' || ch == '[' || ch == ']' ||
            ch == '{' || ch == '}' || ch == '=' || ch == '\'' ||
            ch == '#' || ch == '+' || ch == '*' || ch == '>' ||
            ch == '^' || ch == '�' || ch == '|' || ch == '<' || 
            ch == '?') {
          //
          typeMessage.append(ch);
          drawScreen();
        }
      }

      public void keyReleased (KeyEvent e )
      {
        // nothing
      }
    });

    //drawScreen();
    // start displays heartBeat
    if (heartBeat == null) {
      heartBeat = new Thread(this, "CharDisplay Heartbeat");
      heartBeat.start();
    }
  }

  private void drawScreen()
  {
    display.clrscr();
    display.doubleRect(0,  0,79,18, 0xA0A0A0, false);
    display.doubleRect(0, 18,79,23, 0xA0A0A0, false);
    display.doubleRect(69,14,79,18, 0xA0A0A0, false);
    int currentX = reflection.xPos;
    int currentY = reflection.yPos;
    int currentZ = reflection.zPos;
    String curXstr = String.valueOf(currentX);
    String curYstr = String.valueOf(currentY);
    String curZstr = String.valueOf(currentZ);
    display.putString(71,15,"X:");
    display.putString(78-curXstr.length(),15,curXstr);
    display.putString(71,16,"Y:");
    display.putString(78-curYstr.length(),16,curYstr);
    display.putString(71,17,"Z:");
    display.putString(78-curZstr.length(),17,curZstr);
    
    StaticCell meCell = cacheDemon.getStaticCell(currentX , currentY);        
    boolean blendout = false; 
    // look if tiles are above players cell
    for (int i = 0; i < meCell.tiles.length; i++) {
      if (meCell.tiles[i].z > currentZ)
        blendout = true;
        //System.out.println("height: " + (meCell.tiles[i].h >> 2));        
    }
    int headview = 127; // sky is limit, if not blending
    if (blendout)
      headview = currentZ + 16;
    //System.out.println("Headview: " + headview);
    
    for (int y = 1; y < 18; y++) {
      int rightlimit = y > 13 ? 69 : 79;
      for (int x = 1; x < rightlimit; x++) {
        StaticCell sCell = cacheDemon.getStaticCell(x + currentX - 39, y + currentY - 9);        
        MapCell mCell = cacheDemon.getMapCell(x + currentX - 39, y + currentY - 9, false);
        if (sCell.tiles.length == 0) {
          if (mCell.id < CharMapTiles.tiles.length) {
             display.putChar(x,y,(char) CharMapTiles.tiles[mCell.id][0], CharMapTiles.tiles[mCell.id][1]);                                
          } else {
            display.putChar(x,y,' ');               
          }
        } else {
          int icell;
          for (icell = sCell.tiles.length - 1; icell >= 0; icell--) {
            if ((sCell.tiles[icell].z) <= headview)    
              break;
          }                
          if (icell < 0) {
            if (mCell.id < CharMapTiles.tiles.length) {
               display.putChar(x,y,(char) CharMapTiles.tiles[mCell.id][0], CharMapTiles.tiles[mCell.id][1]);                                
            } else {
              display.putChar(x,y,' ');               
            }
          } else {
            int staticChar[] = (int[]) CharStaticTiles.tiles.get(new Integer(sCell.tiles[icell].id));
            if (staticChar == null) {                
              System.out.println("couldn't find static nr. 0x" + Integer.toHexString(sCell.tiles[icell].id));
              display.putChar(x,y,'?',0xFFFFFF);
            } else {                
             display.putChar(x,y, (char) staticChar[0], staticChar[1]);
            } 
          }
        }
      }
    }
    int msgcount = reflection.systemMessageCount();
    if (msgcount > 4)
      msgcount = 4;
    boolean messageTyping = false;
    if (typeMessage.length() > 0) {
      messageTyping = true;
      if (msgcount == 4)
        msgcount = 3;
    }
    for (int i = 0; i < msgcount; i++) {
      SysMessage sysmsg = reflection.getSystemMessage(i);
      if (messageTyping)
        display.putString(2, 21 - i,sysmsg.text , sysmsg.color);         
      else
        display.putString(2, 22 - i,sysmsg.text , sysmsg.color);         
    }
    if (messageTyping) {
      display.putString(2, 22, "> say ", 0xFFFF80);
    display.putString(8, 22, typeMessage.toString(), 0xFFFF00);
    }
    drawCreatures();
    
    display.redraw();
  }

 public void drawCreatures() 
 {
    int currentX = reflection.xPos;
    int currentY = reflection.yPos;
    int creaturecount = reflection.creatureCount();
    //System.out.println("Creature count:" + creaturecount );
    Creature creature = new Creature();
    for (int i = 0; i < creaturecount; i++) {        
      reflection.getCreature(i, creature);
      if (creature.name == null) {
        System.out.println("WARNING creature name null.");                
      } else {
        if ((creature.x > currentX - 39) && (creature.x < currentX + 39) &&
            (creature.y > currentY -  9) && (creature.y < currentY + 9)) {
           display.putChar(creature.x - currentX + 39, creature.y - currentY + 9, creature.name.charAt(0), mecolor);
        }
      }
    }
    display.putChar(39,9,'@', mecolor);        
 }

 public void run() 
 {
   Thread myThread = Thread.currentThread();
   Random ran      = new Random();
   long started    = System.currentTimeMillis();
   
   // wait for reflection to be defined, do nothing till then.
   while ((reflection == null) && running) {
     try {      
       Thread.sleep(1000);       
     } catch (InterruptedException e){
       // the VM doesn't want this thread to sleep anymore,
       // so get back to work
     }        
   }
      
   while (running) {
     try {      
       Thread.sleep(50);
       // glowing stuff
       mecolor += colorglow;
       if (mecolor >= maxcolor) {
         colorglow = - colorglow;
       }
       if (mecolor <= mincolor) {
         colorglow = - colorglow;
       }
       
       if (reflection.updated()) {
         //currentX = reflection.xPos;
         //currentY = reflection.yPos;
         drawScreen();         
       } else {
         drawCreatures();
         display.redraw();
       }
     } catch (InterruptedException e){
       // the VM doesn't want this thread to sleep anymore,
       // so get back to work
     }        
   }
 }

 public void setReflection(Reflection reflection) 
 {
   this.reflection = reflection;
 }
 
 public void interrupt()
 {
   heartBeat.interrupt();
 }
}


