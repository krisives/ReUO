//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package chardisplay;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.text.*;

import stasis.*;

import ModeSelectorWindow;
import IniFile;
import CacheDemon;
import Main;

/***
 *
 ***/
public class CharWindow extends Frame {
  CharPanel display;
  CharConnector charConnector;
  
  public CharWindow(IniFile iniFile, int world, CacheDemon cacheDemon, String server, int port, String account, String password)
  {
    super("CharWindow");
    display = new CharPanel(80,24);
    display.shape(640,480);
    Dimension size = display.getSize();
    if (world == ModeSelectorWindow.WORLD_UO_NETWORK) {
      charConnector = new CharConnector(display, cacheDemon, iniFile, server, port, account , password);
    } 
    setLayout(new BorderLayout(0,0));
    add(display);
    pack();
    Insets insets = getInsets();
    setSize(insets.left + insets.right  + size.width,
            insets.top  + insets.bottom + size.height);
    setResizable(false);
    Toolkit tools = Toolkit.getDefaultToolkit();
    Dimension screen = tools.getScreenSize();

    setLocation((screen.width - 640) / 2,(screen.height - 480) / 2);

    addWindowListener(new WindowAdapter() {
        public void windowClosing(WindowEvent e) {
          Main.logout();
        }
    });

    CharDisplay charDisplay = new CharDisplay(display, cacheDemon);
    if (world == ModeSelectorWindow.WORLD_STASIS) {
      StasisWorld sworld = new StasisWorld(cacheDemon);
      Main.startGame(sworld,charDisplay);
    }
   
    setVisible(true);
    setLocation((screen.width - 640) / 2,(screen.height - 480) / 2);
  }

}
