/**
 * CharPanel -- a simple character display
 * --
 * $Id: CharDisplay.java,v 1.29 1999/03/20 17:02:34 marcus Exp $
 * $timestamp: Thu Jul 24 15:19:18 1997 by Matthias L. Jugel :$
 *
 * This file is part of "The Java Telnet Applet".
 *
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * "The Java Telnet Applet" is distributed in the hope that it will be 
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 */
package chardisplay;

import java.awt.image.*;
import java.awt.*;

/**
 * A simple character display.
 * @author  Matthias L. Jugel, Marcus Mei�ner
 */
public class CharPanel extends Panel
{
  /**
   * If you need the runtime version, just ask this variable.
   */
  public String version = "Revision: 0.00 (for UMelange) Date: 2000/06/28";
  /**
   * Enable debug messages. This is final static to prevent unused
   * code to be compiled.
   */
  public final static int debug = 0;
  
  private Dimension size;          /* rows and columns */
  private Insets insets;           /* size of the border */
  private boolean raised;          /* indicator if the border is raised */

  private char charArray[][];      /* contains the characters */
  private int charAttributes[][];  /* contains character attrs */
  private int bufSize, maxBufSize; /* buffer sizes */

  private int windowBase;          /* where the start displaying */
  private int screenBase;          /* the actual screen start */
  private int topMargin;           /* top scroll margon */
  private int bottomMargin;        /* bottom scroll margon */
  private Scrollbar scrollBar;     /* the scroll bar */
  private String scrBarPos;        /* the scroll bar position */

  private Font normalFont;         /* normal font */
  private FontMetrics fm;          /* current font metrics */
  private int charWidth;           /* current width of a char */
  private int charHeight;          /* current height of a char */
  private int charDescent;         /* base line descent */

  private Point selectBegin, selectEnd;  /* selection coordinates */
  private TextArea selection;
  private Frame selectFrame;

  private SoftFont  sf = new SoftFont();

  private boolean screenLocked = false;         /* screen needs to be locked */
                                                /* because of paint requests */
                                                /* during other operations */
  private boolean update[];
  
  private final static int   FOREGROUND_STD = 0x00D8D8D8;
  /*
  private final static int COLOR_FG_STD  = 7;
  private final static int COLOR_FG_BOLD = 3;
  private final static int COLOR_BG_STD  = 0;
  private final static int COLOR         = 0x7f8;
  private final static int COLOR_FG      = 0x78;
  private final static int COLOR_BG      = 0x780;
*/

  /**
   * Underline character.
   */ 
  public final static int UNDERLINE  = 0x01000000;
  /**
   * Invert character.
   */ 
  public final static int INVERT     = 0x02000000;
  private Image    offscreenImage    = null;
  private Graphics offscreenGraph    = null; 

  private void InitializeCharDisplay(int width, int height, 
                                     String fontname, int fsize)
  {
    System.err.println("CharDisplay: screen size: ["+width+","+height+"]");
    normalFont = new Font(fontname, Font.BOLD, fsize);
    setFont(normalFont);
    fm = getFontMetrics(normalFont);
    if(fm != null)
    {
      charWidth = fm.charWidth('@');
      charHeight = fm.getHeight();
      charDescent = fm.getDescent();
    }

    size = new Dimension(width, height);
   
    charArray = new char[size.height][size.width];
    charAttributes = new int[size.height][size.width];
    bufSize = size.height;
    maxBufSize = 2 * size.height;

    windowBase = 0;
    screenBase = 0;
    topMargin = 0;
    bottomMargin = size.height - 1;

    update = new boolean[size.height + 1];
    for(int i = 1; i <= size.height; i++) update[i] = true;

    selectBegin = new Point(0,0);
    selectEnd = new Point(0,0);

    setLayout(null);
  }
  
  /**
   * Create a character display with size 80x24 and Font "Courier", size 12.
   */
  public CharPanel()
  {
    InitializeCharDisplay(80, 24, "Courier", 12);
  }

  /**
   * Create a character display with specific size, Font is "Courier", size 12.
   */
  public CharPanel(int width, int height)
  {
    InitializeCharDisplay(width, height, "Courier", 12);
  }

  /**
   * Create a character display with 80x24 and specific font and font size.
   */
  public CharPanel(String fname, int fsize)
  {
    InitializeCharDisplay(80, 24, fname, fsize);
  }

  /**
   * Create a character display with specific size, font and font size.
   */
  public CharPanel(int width, int height, String fname, int fsize)
  {
    InitializeCharDisplay(width, height, fname, fsize);
  }
  
  /**
   * Put a character on the screen with normal font and outline.
   * The character previously on that position will be overwritten.
   * You need to call redraw() to update the screen.
   * @param c x-coordinate (column)
   * @param l y-coordinate (line)
   * @param ch the character to show on the screen
   * @see #insertChar
   * @see #deleteChar
   * @see #redraw
   */
  public void putChar(int c, int l, char ch)
  {
    putChar(c, l, ch, FOREGROUND_STD);
  }

  /**
   * Put a character on the screen with specific font and outline.
   * The character previously on that position will be overwritten.
   * You need to call redraw() to update the screen.
   * @param c x-coordinate (column)
   * @param l y-coordinate (line)
   * @param ch the character to show on the screen
   * @param attributes the character attributes
   * @see #BOLD
   * @see #UNDERLINE
   * @see #INVERT
   * @see #NORMAL
   * @see #insertChar
   * @see #deleteChar
   * @see #redraw
   */  

  public void putChar(int c, int l, char ch, int attributes)
  {
    c = checkBounds(c, 0, size.width - 1);
    l = checkBounds(l, 0, size.height - 1);
    charArray[screenBase + l][c] = ch;
    charAttributes[screenBase + l][c] = attributes;
    markLine(l, 1);
  }

  /**
   * Get the character at the specified position.
   * @param c x-coordinate (column)
   * @param l y-coordinate (line)
   * @see #putChar
   */
  public char getChar(int c, int l)
  {
    c = checkBounds(c, 0, size.width - 1);
    l = checkBounds(l, 0, size.height - 1);
    return charArray[l][c];
  }

  /**
   * Get the attributes for the specified position.
   * @param c x-coordinate (column)
   * @param l y-coordinate (line)
   * @see #putChar
   */
  public int getAttributes(int c, int l)
  {
    c = checkBounds(c, 0, size.width - 1);
    l = checkBounds(l, 0, size.height - 1);
    return charAttributes[l][c];
  }

  /**
   * Insert a character at a specific position on the screen.
   * All character right to from this position will be moved one to the right.
   * You need to call redraw() to update the screen.
   * @param c x-coordinate (column)
   * @param l y-coordinate (line)
   * @param ch the character to insert
   * @param attributes the character attributes
   * @see #BOLD
   * @see #UNDERLINE
   * @see #INVERT
   * @see #NORMAL
   * @see #putChar
   * @see #deleteChar
   * @see #redraw
   */
  public void insertChar(int c, int l, char ch, int attributes)
  {
    c = checkBounds(c, 0, size.width - 1);
    l = checkBounds(l, 0, size.height - 1);
    System.arraycopy(charArray[screenBase + l], c, 
         charArray[screenBase + l], c + 1, size.width - c - 1);
    System.arraycopy(charAttributes[screenBase + l], c, 
         charAttributes[screenBase + l], c + 1, size.width - c - 1);
    putChar(c, l, ch, attributes);
  }

  /**
   * Delete a character at a given position on the screen.
   * All characters right to the position will be moved one to the left.
   * You need to call redraw() to update the screen.
   * @param c x-coordinate (column)
   * @param l y-coordinate (line)
   * @see #putChar
   * @see #insertChar
   * @see #redraw
   */
  public void deleteChar(int c, int l)
  {
    c = checkBounds(c, 0, size.width - 1);
    l = checkBounds(l, 0, size.height - 1);
    if(c < size.width - 1)
    {
      System.arraycopy(charArray[screenBase + l],      c + 1, charArray[screenBase + l],      c, size.width - c - 1);
      System.arraycopy(charAttributes[screenBase + l], c + 1, charAttributes[screenBase + l], c, size.width - c - 1);
    }
    putChar(size.width - 1, l, (char)0);
  }

  /**
   * Put a String at a specific position. Any characters previously on that 
   * position will be overwritten. You need to call redraw() for screen update.
   * @param c x-coordinate (column)
   * @param l y-coordinate (line)
   * @param s the string to be shown on the screen
   * @see #BOLD
   * @see #UNDERLINE
   * @see #INVERT
   * @see #NORMAL
   * @see #putChar
   * @see #insertLine
   * @see #deleteLine
   * @see #redraw
   */  
  public void putString(int c, int l, String s)
  {
    putString(c, l, s, FOREGROUND_STD);
  }
  
  /**
   * Put a String at a specific position giving all characters the same
   * attributes. Any characters previously on that position will be 
   * overwritten. You need to call redraw() to update the screen.
   * @param c x-coordinate (column)
   * @param l y-coordinate (line)
   * @param s the string to be shown on the screen
   * @param attributes character attributes
   * @see #BOLD
   * @see #UNDERLINE
   * @see #INVERT
   * @see #NORMAL
   * @see #putChar
   * @see #insertLine
   * @see #deleteLine
   * @see #redraw
   */
  public void putString(int c, int l, String s, int attributes)
  {
    for(int i = 0; i < s.length() && c + i < size.width; i++)
      putChar(c + i, l, s.charAt(i), attributes);
  }

  public void clrscr()
  {
    deleteArea(0,0, size.width, size.height);
  }

  /**
   * Delete a rectangular portion of the screen.
   * You need to call redraw() to update the screen.
   * @param c x-coordinate (column)
   * @param l y-coordinate (row)
   * @param w with of the area in characters
   * @param h height of the area in characters
   * @see #deleteChar
   * @see #deleteLine
   * @see redraw
   */
  public void deleteArea(int c, int l, int w, int h)
  {
    c = checkBounds(c, 0, size.width - 1);
    l = checkBounds(l, 0, size.height - 1);

    char cbuf[] = new char[w];
    int abuf[] = new int[w];
    
    for(int i = 0; i < h && l + i < size.height; i++)
    {
      System.arraycopy(cbuf, 0, charArray[screenBase + l + i], c, w);
      System.arraycopy(abuf, 0, charAttributes[screenBase + l + i], c, w);
    }
    markLine(l, h);
  }

  /**
   * Set scrollback buffer size.
   * @param amount new size of the buffer
   */
  public void setBufferSize(int amount)
  {
    screenLocked = true;

    if(amount < size.height) amount = size.height;
    if(amount < maxBufSize)
    {
      char cbuf[][] = new char[amount][size.width];
      int abuf[][] = new int[amount][size.width];
      System.arraycopy(charArray, bufSize - amount, cbuf, 0, amount);
      System.arraycopy(charAttributes, bufSize - amount, abuf, 0, amount);
      charArray = cbuf;
      charAttributes = abuf;
    }
    maxBufSize = amount;
 
    screenLocked = false;

    repaint();
  }

  /**
   * Retrieve current scrollback buffer size.
   * @see #setBufferSize
   */
  public int getBufferSize()
  {
    return bufSize;
  }

  /**
   * Retrieve maximum buffer Size.
   * @see #getBufferSize
   */
  public int getMaxBufferSize()
  {
    return maxBufSize;
  }

  /**
   * Set the current window base. This allows to view the scrollback buffer.
   * @param line the line where the screen window starts
   * @see setBufferSize
   * @see getBufferSize
   */
  public void setWindowBase(int line)
  {
    if(line > screenBase) line = screenBase;
    else if(line < 0) line = 0;
    windowBase = line;
    repaint();
  }

  /**
   * Get the current window base.
   * @see setWindowBase
   */
  public int getWindowBase()
  {
    return windowBase;
  }

  /**
   * Change the size of the screen. This will include adjustment of the 
   * scrollback buffer.
   * @param columns width of the screen
   * @param columns height of the screen
   */
  public void setWindowSize(int width, int height)
  {
    char cbuf[][];
    int abuf[][];
    int bsize = bufSize;

    if(width < 1 || height < 1) return;

    screenLocked = true;
    
    super.update(getGraphics());
    
    if(height > maxBufSize) 
      maxBufSize = height;
    if(height > bufSize)
    {
      bufSize = height;
      screenBase = 0;
      windowBase = 0;
    }

    cbuf = new char[bufSize][width];
    abuf = new int[bufSize][width];
    
    for(int i = 0; i < bsize && i < bufSize; i++)
    {
      System.arraycopy(charArray[i], 0, cbuf[i], 0, 
           width < size.width ? width : size.width);
      System.arraycopy(charAttributes[i], 0, abuf[i], 0, 
           width < size.width ? width : size.width);
    }
    charArray = cbuf;
    charAttributes = abuf;
    size = new Dimension(width, height);
    topMargin = 0;
    bottomMargin = height - 1;

    //offscreenImage = createImage(width, height);
    //offscreenGraph = offscreenImage.getGraphics();

    update = new boolean[height + 1];    
    for(int i = 0; i <= height; i++) update[i] = true;
    screenLocked = false;
  }
  
  /**
   * Get amount of rows on the screen.
   */
  public int getRows()
  {
    return size.height;
  }

  /**
   * Get amount of columns on the screen.
   */
  public int getColumns()
  {
    return size.width;
  }

  /**
   * Set the border thickness and the border type.
   * @param thickness border thickness in pixels, zero means no border
   * @param raised a boolean indicating a raised or embossed border
   */
  public void setBorder(int thickness, boolean raised)
  {
    if(thickness == 0) insets = null;
    else insets = new Insets(thickness+1, thickness+1, 
                             thickness+1, thickness+1);
    this.raised = raised;
  }

  /**
   * Set the scrollbar position. valid values are "East" or "West".
   * @param position the position of the scrollbar
   */
  public void setScrollbar(String position)
  {
    add(scrollBar = new Scrollbar());
    scrollBar.setValues(windowBase, size.height, 0, bufSize - size.height);
    scrBarPos = position;
  }
  
  /**
   * Mark lines to be updated with redraw().
   * @param l starting line
   * @param n amount of lines to be updated
   * @see #redraw
   */
  public void markLine(int l, int n)
  {
    l = checkBounds(l, 0, size.height - 1);
    for(int i = 0; i < n && l + i < size.height; i++) 
      update[l + i + 1] = true;
  }
  
  /**
   * Redraw marked lines.
   * @see #markLine
   */
  public void redraw()
  {
    update[0] = true;
    repaint();
  }

  /**
   * Update the display. to reduce flashing we have overridden this method.
   */
  public void update(Graphics g)
  {
    paint(g);
  }
  
  /**
   * Paint the current screen. All painting is done here. Only lines that have
   * changed will be redrawn!
   */
  public synchronized void paint(Graphics onscreenGraph)
  {
    if (offscreenGraph == null) {
      Dimension dsize = getSize();
      offscreenImage = createImage(dsize.width, dsize.height);
      //offscreenImage = createImage(400, 400);
      offscreenGraph = offscreenImage.getGraphics();
    }

    Graphics g = offscreenGraph;
    if(screenLocked) return;

    Color bg = Color.black;
    Color fg = Color.white;

    g.setFont(normalFont);

    for(int l = 0; l < size.height; l++)
    {
      if(update[0] && !update[l + 1]) continue;
      update[l + 1] = false;
      for(int c = 0; c < size.width; c++)
      {
        int addr = 0;
        int currAttr = charAttributes[windowBase + l][c];

        fg = new Color(currAttr & 0x00FFFFFF);
        bg = Color.black;

        if((currAttr & INVERT) != 0) {
          Color swapc = bg; bg=fg;fg=swapc;
        }

        if (sf.inSoftFont(charArray[windowBase + l][c])) {
          g.setColor(bg);	
          g.fillRect(c * charWidth, l * charHeight, charWidth, charHeight);
          g.setColor(fg);	
          sf.drawChar(g,charArray[windowBase + l][c], c*charWidth, l*charHeight, charWidth, charHeight);
          if((currAttr & UNDERLINE) != 0)
            g.drawLine(c * charWidth, (l+1) * charHeight - charDescent / 2,
                       c * charWidth, (l+1) * charHeight - charDescent / 2);
          continue;
        }

	      // determine the maximum of characters we can print in one go
        while(c + addr < size.width &&
              charAttributes[windowBase + l][c + addr] == currAttr &&
              !sf.inSoftFont(charArray[windowBase + l ][c+addr]))
        {
          if(charArray[windowBase + l][c + addr] < ' ')
             charArray[windowBase + l][c + addr] = ' ';
          addr++;
        }
        
        // clear the part of the screen we want to change (fill rectangle)
        g.setColor(bg);
        g.fillRect(c * charWidth, l * charHeight, addr * charWidth, charHeight);
        g.setColor(fg);
        
        // draw the characters
        g.drawChars(charArray[windowBase + l], c, addr, 
                    c * charWidth, (l+1) * charHeight - charDescent);

        if((currAttr & UNDERLINE) != 0)
          g.drawLine(c * charWidth,
                     (l+1) * charHeight - charDescent / 2,
                     c * charWidth + addr * charWidth,
                     (l+1) * charHeight - charDescent / 2);
        
        c += addr - 1;
      }
    }

    if(windowBase <= selectBegin.y || windowBase <= selectEnd.y) {
      int beginLine = selectBegin.y - windowBase;
      int endLine = selectEnd.y - selectBegin.y;
      if(beginLine < 0) {
        endLine += beginLine;
        beginLine = 0;
      }
      if(endLine > size.height) endLine = size.height - beginLine;
       
      g.setXORMode(Color.black);
      g.fillRect(selectBegin.x * charWidth,
                 beginLine * charHeight,
                 (endLine == 0 ? (selectEnd.x - selectBegin.x) : 
                  (size.width - selectBegin.x)) 
                 * charWidth,
                 charHeight);
      if(endLine > 1)
        g.fillRect(0,
                   (beginLine + 1) * charHeight,
                   size.width * charWidth, 
                   (endLine - 1) * charHeight);
      if(endLine > 0)
        g.fillRect(0,
                   (beginLine + endLine) * charHeight,
                   selectEnd.x * charWidth, 
                   charHeight);
      g.setPaintMode();
    }

    if(insets != null) {
      g.setColor(getBackground());
      for(int i = insets.top - 1; i >= 0; i--)
        g.draw3DRect(- i, - i,
                     charWidth  * size.width + 1 + i * 2,
                     charHeight * size.height + 1 + i * 2,
                     raised);
    }

    onscreenGraph.drawImage(offscreenImage, 0, 0, null);
    update[0] = false;
  }

  private int checkBounds(int value, int lower, int upper)
  {
    if(value < lower) return lower;
    if(value > upper) return upper;
    return value;
  }

  /**
   * Reshape character display
   */
  public void shape(int w, int h)
  {
    int xborder = 0, yborder = 0;
    
    if(insets != null) {
      w -= (xborder = insets.left + insets.right);
      h -= (yborder = insets.top + insets.bottom);
    }
    if(scrollBar != null) { w -= 15;}

    Font tmpFont = normalFont;
    String fontName = normalFont.getName();
    fm = getFontMetrics(normalFont);
    if(fm != null)
    {
      charWidth = fm.charWidth('@');
      charHeight = fm.getHeight();
    }
    
    int height = h / size.height;
    int width = w / size.width;
      
    fm = getFontMetrics(normalFont = new Font(fontName, Font.PLAIN, charHeight));
      
    // adapt current font size (from small up to best fit)
    if(fm.getHeight() < height || fm.charWidth('@') < width)
      do {
        fm = getFontMetrics(normalFont = new Font(fontName, Font.PLAIN,
                                                  ++charHeight));
      } while(fm.getHeight() < height ||
              fm.charWidth('@') < width);
      
    // now check if we got a font that is too large
    if(fm.getHeight() > height || fm.charWidth('@') > width)
      do {
        fm = getFontMetrics(normalFont = new Font(fontName, Font.PLAIN,
                                                  --charHeight));
      } while(charHeight > 1 &&
              (fm.getHeight() > height ||
               fm.charWidth('@') > width));

    if(charHeight <= 1)
    {
      System.err.println("CharDisplay: error during resize, resetting");
      normalFont = tmpFont;
      System.err.println("CharDisplay: disabling font/screen resize");
    }

    setFont(normalFont);
    fm = getFontMetrics(normalFont);
    charWidth = fm.charWidth('@');
    charHeight = fm.getHeight();
    charDescent = fm.getDescent();
    if(scrollBar != null) {
      int xoffset = (super.getSize().width - size.width * charWidth - 15) / 2;
      int yoffset = (super.getSize().height - size.height * charHeight) / 2;
      if(scrBarPos.equals("West"))
        scrollBar.setBounds(xoffset - (xborder / 2), yoffset - yborder / 2,
                            15, size.height * charHeight + yborder);
      else
        scrollBar.setBounds(xoffset + (xborder / 2) + size.width * charWidth,
                            yoffset - yborder / 2, 15,
                            size.height * charHeight + yborder);
    }
  }

  /**
   * Return the real size in points of the character display.
   * @return Dimension the dimension of the display
   * @see java.awt.Dimension
   */
  public Dimension getSize()
  {
    int xborder = 0, yborder = 0;
    if(insets != null) {
      xborder = insets.left + insets.right;
      yborder = insets.top + insets.bottom;
    }
    if(scrollBar != null) xborder += 15;
    
    return new Dimension(size.width  * charWidth  + xborder,
                         size.height * charHeight + yborder);
  }

  /**
   * Return the preferred Size of the character display.
   * This turns out to be the actual size.
   * @return Dimension dimension of the display
   * @see size
   */
  public Dimension getPreferredSize()
  {
    return getSize();
  }

  /**
   * The insets of the character display define the border.
   * @return Insets border thickness in pixels
   */
  public Insets getInsets()
  {
    return insets == null ? super.getInsets() : insets;
  }

  // Here start the specific extensions.

  private static final char INVALID[] =
  {
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,

         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0
  };

  public char mergeTable[][] = {
  /* 0x2500 - horz line*/
  {
    0x2500,      0, 0x253C,      0,      0,       0,      0,      0,      0,      0,      0,      0, 0x252C,      0,     0,     0,
    0x252C,      0,      0,      0, 0x2534,       0,      0,      0, 0x2534,      0,      0,      0, 0x253C,      0,     0,     0,
         0,      0,      0,      0, 0x254C,       0,      0,      0,      0,      0,      0,      0, 0x252C,      0,     0,     0,
         0,      0,      0,      0, 0x2534,       0,      0,      0,      0,      0,      0,      0, 0x253C,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,

         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0
  },
  /* 0x2501 - thick horz line */ INVALID,
  /* 0x2502 - vertical line   */
  {
    0x253C,      0, 0x2502,      0,      0,       0,      0,      0,      0,      0,      0,      0, 0x251C,      0,     0,     0,
    0x2524,      0,      0,      0, 0x251C,       0,      0,      0, 0x2524,      0,      0,      0, 0x251C,      0,     0,     0,
         0,      0,      0,      0, 0x2524,       0,      0,      0,      0,      0,      0,      0, 0x253C,      0,     0,     0,
         0,      0,      0,      0, 0x253C,       0,      0,      0,      0,      0,      0,      0, 0x253C,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,

         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0
  },
  /* 0x2503 - thick vertical line   */ INVALID,
  /* 0x2504 - some dashed horz line */ INVALID,
  /* 0x2505 - some dashed horz line */ INVALID,
  /* 0x2506 - some dashed vert line */ INVALID,
  /* 0x2507 - some dashed vert line */ INVALID,
  /* 0x2508 - some dashed horz line */ INVALID,
  /* 0x2509 - some dashed horz line */ INVALID,
  /* 0x250A - some dashed vert line */ INVALID,
  /* 0x250B - some dashed vert line */ INVALID,
  /* 0x250C - right to down cornor*/
  {
    0x252C,      0, 0x251C,      0,      0,       0,      0,      0,      0,      0,      0,      0, 0x250C,      0,     0,     0,
    0x252C,      0,      0,      0, 0x251C,       0,      0,      0,      0,      0,      0,      0, 0x253C,      0,     0,     0,
         0,      0,      0,      0, 0x253C,       0,      0,      0,      0,      0,      0,      0, 0x252C,      0,     0,     0,
         0,      0,      0,      0, 0x253C,       0,      0,      0,      0,      0,      0,      0, 0x253C,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,

         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0
  },
  /* 0x250D right to down cornor with thick right*/ INVALID,
  /* 0x250E right to down cornor with thick down*/  INVALID,
  /* 0x250F thick right to down cornor */ INVALID,

  /* 0x2510 - left to down corner */
  {
    0x252C,      0, 0x2524,      0,      0,       0,      0,      0,      0,      0,      0,      0, 0x252C,      0,     0,     0,
    0x2510,      0,      0,      0, 0x253C,       0,      0,      0, 0x2524,      0,      0,      0, 0x253C,      0,     0,     0,
         0,      0,      0,      0, 0x2524,       0,      0,      0,      0,      0,      0,      0, 0x252C,      0,     0,     0,
         0,      0,      0,      0, 0x253C,       0,      0,      0,      0,      0,      0,      0, 0x253C,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,

         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0
  },
  /* 0x2511 */ INVALID,
  /* 0x2512 */ INVALID,
  /* 0x2513 */ INVALID,
  /* 0x2514 - right to up corner*/
  {
    0x2534,      0, 0x251C,      0,      0,       0,      0,      0,      0,      0,      0,      0, 0x251C,      0,     0,     0,
    0x253C,      0,      0,      0, 0x2514,       0,      0,      0, 0x2534,      0,      0,      0, 0x251C,      0,     0,     0,
         0,      0,      0,      0, 0x253C,       0,      0,      0,      0,      0,      0,      0, 0x253C,      0,     0,     0,
         0,      0,      0,      0, 0x2534,       0,      0,      0,      0,      0,      0,      0, 0x253C,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,

         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0
  },
  /* 0x2515 */ INVALID,
  /* 0x2516 */ INVALID,
  /* 0x2517 */ INVALID,
  /* 0x2518 - left to up corner*/
  {
    0x2534,      0, 0x2524,      0,      0,       0,      0,      0,      0,      0,      0,      0, 0x253C,      0,     0,     0,
    0x2524,      0,      0,      0, 0x2534,       0,      0,      0, 0x2518,      0,      0,      0, 0x253C,      0,     0,     0,
         0,      0,      0,      0, 0x2524,       0,      0,      0,      0,      0,      0,      0, 0x253C,      0,     0,     0,
         0,      0,      0,      0, 0x2534,       0,      0,      0,      0,      0,      0,      0, 0x253C,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,

         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0
  },
  /* 0x2519 */ INVALID,
  /* 0x251A */ INVALID,
  /* 0x251B */ INVALID,
  /* 0x251C */ INVALID,
  /* 0x251D */ INVALID,
  /* 0x251E */ INVALID,
  /* 0x251F */ INVALID,

  /* 0x2520 */ INVALID,
  /* 0x2521 */ INVALID,
  /* 0x2522 */ INVALID,
  /* 0x2523 */ INVALID,
  /* 0x2524 */ INVALID,
  /* 0x2525 */ INVALID,
  /* 0x2526 */ INVALID,
  /* 0x2527 */ INVALID,
  /* 0x2528 */ INVALID,
  /* 0x2529 */ INVALID,
  /* 0x252A */ INVALID,
  /* 0x252B */ INVALID,
  /* 0x252C */ INVALID,
  /* 0x252D */ INVALID,
  /* 0x252E */ INVALID,
  /* 0x252F */ INVALID,

  /* 0x2530 */ INVALID,
  /* 0x2531 */ INVALID,
  /* 0x2532 */ INVALID,
  /* 0x2533 */ INVALID,
  /* 0x2534 */ INVALID,
  /* 0x2535 */ INVALID,
  /* 0x2536 */ INVALID,
  /* 0x2537 */ INVALID,
  /* 0x2538 */ INVALID,
  /* 0x2539 */ INVALID,
  /* 0x253A */ INVALID,
  /* 0x253B */ INVALID,
  /* 0x253C */ INVALID,
  /* 0x253D */ INVALID,
  /* 0x253E */ INVALID,
  /* 0x253F */ INVALID,

  /* 0x2540 */ INVALID,
  /* 0x2541 */ INVALID,
  /* 0x2542 */ INVALID,
  /* 0x2543 */ INVALID,
  /* 0x2544 */ INVALID,
  /* 0x2545 */ INVALID,
  /* 0x2546 */ INVALID,
  /* 0x2547 */ INVALID,
  /* 0x2548 */ INVALID,
  /* 0x2549 */ INVALID,
  /* 0x254A */ INVALID,
  /* 0x254B */ INVALID,
  /* 0x254C */ INVALID,
  /* 0x254D */ INVALID,
  /* 0x254E */ INVALID,
  /* 0x254F */ INVALID,

  /* 0x2550 - double horz line*/
  {
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,

    0x2550, 0x256C,      0,      0, 0x2566,       0,      0, 0x2566,      0,      0, 0x2569,      0,      0, 0x2569,     0,     0,
    0x256C,      0,      0, 0x256C,      0,       0, 0x2566,      0,      0, 0x2569,      0,      0, 0x256C,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0
  },
  /* 0x2551 - double vert line*/
  {
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,

    0x256C, 0x2551,      0,      0, 0x2560,       0,      0, 0x2563,      0,      0, 0x2560,      0,      0, 0x2563,     0,     0,
    0x2560,      0,      0, 0x2563,      0,       0, 0x256C,      0,      0, 0x256C,      0,      0, 0x256C,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0
  },
  /* 0x2552 */ INVALID,
  /* 0x2553 */ INVALID,
  /* 0x2554 - double right to down corner*/
  {
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,

    0x2566, 0x2560,      0,      0, 0x2554,       0,      0, 0x2566,      0,      0, 0x2560,      0,      0, 0x256C,     0,     0,
    0x2560,      0,      0, 0x256C,      0,       0, 0x2566,      0,      0, 0x256C,      0,      0, 0x256C,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0
  },
  /* 0x2555 */ INVALID,
  /* 0x2556 */ INVALID,
  /* 0x2557 - double left to down corner */
  {
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,

    0x2566, 0x2563,      0,      0, 0x2566,       0,      0, 0x2557,      0,      0, 0x256C,      0,      0, 0x2563,     0,     0,
    0x256C,      0,      0, 0x2563,      0,       0, 0x2566,      0,      0, 0x256C,      0,      0, 0x256C,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0
  },
  /* 0x2558 */ INVALID,
  /* 0x2559 */ INVALID,
  /* 0x255A - double right to up corner*/
  {
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,

    0x2569, 0x2560,      0,      0, 0x2560,       0,      0, 0x256C,      0,      0, 0x255A,      0,      0, 0x2569,     0,     0,
    0x2560,      0,      0, 0x256C,      0,       0, 0x256C,      0,      0, 0x2569,      0,      0, 0x256C,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0
  },
  /* 0x255B */ INVALID,
  /* 0x255C */ INVALID,
  /* 0x255D - double left to up corner*/
  {
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0,

    0x2569, 0x2563,      0,      0, 0x256C,       0,      0, 0x2563,      0,      0, 0x2569,      0,      0, 0x255D,     0,     0,
    0x256C,      0,      0, 0x2563,      0,       0, 0x256C,      0,      0, 0x2569,      0,      0, 0x256C,      0,     0,     0,
         0,      0,      0,      0,      0,       0,      0,      0,      0,      0,      0,      0,      0,      0,     0,     0
  },
  /* 0x255E */ INVALID,
  /* 0x255F */ INVALID,

  /* 0x2560 */ INVALID,
  /* 0x2561 */ INVALID,
  /* 0x2562 */ INVALID,
  /* 0x2563 */ INVALID,
  /* 0x2564 */ INVALID,
  /* 0x2565 */ INVALID,
  /* 0x2566 */ INVALID,
  /* 0x2567 */ INVALID,
  /* 0x2568 */ INVALID,
  /* 0x2569 */ INVALID,
  /* 0x256A */ INVALID,
  /* 0x256B */ INVALID,
  /* 0x256C */ INVALID,
  /* 0x256D */ INVALID,
  /* 0x256E */ INVALID,
  /* 0x256F */ INVALID,

  /* 0x2570 */ INVALID,
  /* 0x2571 */ INVALID,
  /* 0x2572 */ INVALID,
  /* 0x2573 */ INVALID,
  /* 0x2574 */ INVALID,
  /* 0x2575 */ INVALID,
  /* 0x2576 */ INVALID,
  /* 0x2577 */ INVALID,
  /* 0x2578 */ INVALID,
  /* 0x2579 */ INVALID,
  /* 0x257A */ INVALID,
  /* 0x257B */ INVALID,
  /* 0x257C */ INVALID,
  /* 0x257D */ INVALID,
  /* 0x257E */ INVALID,
  /* 0x257F */ INVALID,
 };

  private void putMergeChar(int x, int y, char c2, int attr1)
  {
    char c1   = getChar(x, y);
    int attr2 = getAttributes(x, y);
    int attr;
    if (attr1 != attr2 ) {
     attr = ((((attr1 & 0x0000FF) + (attr2 & 0x0000FF)) / 2) & 0x0000FF) |
            ((((attr1 & 0x00FF00) + (attr2 & 0x00FF00)) / 2) & 0x00FF00) |
            ((((attr1 & 0xFF0000) + (attr2 & 0xFF0000)) / 2) & 0xFF0000);
    } else
     attr = attr1;

    if (!((c1>=0x2500) && (c1<=0x257F) && (c2>=0x2500) && (c2<=0x257F))) {
      putChar(x, y, c2, attr1);
      return;
    }
    int i1 = c1 & 0x7F;
    int i2 = c2 & 0x7F;
    char c = mergeTable[i2][i1];
    if (c == 0)
      putChar(x, y, c2, attr1);
    else
      putChar(x, y, c, attr);
  }

  public void singleRect(int x1, int y1, int x2, int y2, boolean overwrite)
  {
    singleRect(x1, y1, x2, y2, FOREGROUND_STD, overwrite);
  }

  public void singleRect(int x1, int y1, int x2, int y2, int attr, boolean overwrite)
  {
    if (!overwrite) {
      // upper left corner
      putMergeChar(x1,y1,(char) 0x250C, attr);
      // upper right corner
      putMergeChar(x2,y1,(char) 0x2510, attr);
      // lower left corner
      putMergeChar(x1,y2,(char) 0x2514, attr);
      // lower right corner
      putMergeChar(x2,y2,(char) 0x2518, attr);
      // upper & lower line
      for (int i = x1 + 1; i < x2; i++) {
        putMergeChar(i,y1,(char) 0x2500, attr);
        putMergeChar(i,y2,(char) 0x2500, attr);
      }
      // left & right line
      for (int i = y1 + 1; i < y2; i++) {
        putMergeChar(x1,i,(char) 0x2502, attr);
        putMergeChar(x2,i,(char) 0x2502, attr);
      }
    } else {
      // upper left corner
      putChar(x1,y1,(char) 0x250C, attr);
      // upper right corner
      putChar(x2,y1,(char) 0x2510, attr);
      // lower left corner
      putChar(x1,y2,(char) 0x2514, attr);
      // lower right corner
      putChar(x2,y2,(char) 0x2518, attr);
      // upper & lower line
      for (int i = x1 + 1; i < x2; i++) {
        putChar(i,y1,(char) 0x2500, attr);
        putChar(i,y2,(char) 0x2500, attr);
      }
      // left & right line
      for (int i = y1 + 1; i < y2; i++) {
        putChar(x1,i,(char) 0x2502, attr);
        putChar(x2,i,(char) 0x2502, attr);
      }
    }
  }


  public void doubleRect(int x1, int y1, int x2, int y2, boolean overwrite)
  {
    doubleRect(x1, y1, x2, y2, FOREGROUND_STD, overwrite);
  }

  public void doubleRect(int x1, int y1, int x2, int y2, int attr, boolean overwrite)
  {
    if (!overwrite) {
      // upper left corner
      putMergeChar(x1,y1,(char) 0x2554, attr);
      // upper right corner
      putMergeChar(x2,y1,(char) 0x2557, attr);
      // lower left corner
      putMergeChar(x1,y2,(char) 0x255A, attr);
      // lower right corner
      putMergeChar(x2,y2,(char) 0x255D, attr);
      // upper & lower line
      for (int i = x1 + 1; i < x2; i++) {
        putMergeChar(i,y1,(char) 0x2550, attr);
        putMergeChar(i,y2,(char) 0x2550, attr);
      }
      // left & right line
      for (int i = y1 + 1; i < y2; i++) {
        putMergeChar(x1,i,(char) 0x2551, attr);
        putMergeChar(x2,i,(char) 0x2551, attr);
      }
    } else {
      // upper left corner
      putChar(x1,y1,(char) 0x2554, attr);
      // upper right corner
      putChar(x2,y1,(char) 0x2557, attr);
      // lower left corner
      putChar(x1,y2,(char) 0x255A, attr);
      // lower right corner
      putChar(x2,y2,(char) 0x255D, attr);
      // upper & lower line
      for (int i = x1 + 1; i < x2; i++) {
        putChar(i,y1,(char) 0x2550, attr);
        putChar(i,y2,(char) 0x2550, attr);
      }
      // left & right line
      for (int i = y1 + 1; i < y2; i++) {
        putChar(x1,i,(char) 0x2551, attr);
        putChar(x2,i,(char) 0x2551, attr);
      }
    }
  }
}

