//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package map;

import java.io.*;
import java.awt.*;
import java.awt.image.*;

/** 
 *
 * Read data from the original client, the '.mul' files
 *
 * For format of these files please also see at UOInside: <br>
 *
 * <a href>http://dkbush.cablenet-va.com/alazane/file_formats.html</a>
 *
 */  
public class MulMapReader {   
 public  final int RUN_TILE_OFFSET = 16384;   
	   	
 private RandomAccessFile staticDataFile  = null;
 private RandomAccessFile staticIndexFile = null;
 private RandomAccessFile mapFile         = null;
 private RandomAccessFile tileDataFile    = null;
 private String staticDataFilename        = null;
 private String staticIndexFilename       = null;
 private String mapFilename               = null;
 private String tileDataFilename          = null;
                                
 public MulMapReader(String uoPath) throws IOException {
   mapFilename = uoPath + "map0.mul";
   System.out.print("  ");
   System.out.print(mapFilename);
   System.out.print(" ... ");
   mapFile = new RandomAccessFile(mapFilename,"r");     
   System.out.println(" OK ");

   staticDataFilename = uoPath + "statics0.mul";
   System.out.print("  ");
   System.out.print(staticDataFilename);
   System.out.print(" ... ");
   staticDataFile = new RandomAccessFile(staticDataFilename,"r");     
   System.out.println(" OK ");
    
   staticIndexFilename = uoPath + "staidx0.mul";
   System.out.print("  ");
   System.out.print(staticIndexFilename);
   System.out.print(" ... ");
   staticIndexFile = new RandomAccessFile(staticIndexFilename,"r");     
   System.out.println(" OK ");

   tileDataFilename = uoPath + "tiledata.mul";
   System.out.print("  ");
   System.out.print(tileDataFilename);
   System.out.print(" ... ");
   tileDataFile = new RandomAccessFile(tileDataFilename,"r");     
   System.out.println(" OK ");
 }
   
/**
 *
 * Called to free resources, close the files.
 *
 */
 public synchronized void close() 
 {
    System.out.print("  ");
    System.out.print(mapFilename);
    System.out.print(" ... ");      
    try {
      mapFile.close();
      System.out.println("OK");
    } catch (IOException e) {
      System.out.println("Failure");
    }
    System.out.print("  ");
    System.out.print(staticDataFilename);
    System.out.print(" ... ");      
    try {
      staticDataFile.close();
      System.out.println("OK");
    } catch (IOException e) {
      System.out.println("Failure");
    }
    System.out.print("  ");
    System.out.print(staticIndexFilename);
    System.out.print(" ... ");      
    try {
      staticIndexFile.close();
      System.out.println("OK");
    } catch (IOException e) {
      System.out.println("Failure");
    }
 }
       
/***
 *
 * Reads a map block from map0.mul into memory.
 *
 * @param id  id of the MapBlock to read.
 *
 * @return the MapBlock
 *
 ***/
 
 public synchronized MapBlock readMapBlock(int id) 
 {
    MapBlock mblock = new MapBlock();
    mblock.id = id;
    try {
      mapFile.seek(196 * id + 4); // 4 to skip unkown header
      for (int y=0; y<8; y++) {
        for (int x=0; x<8; x++) {
          mblock.cells[x][y].id     = mapFile.readUnsignedByte() + (mapFile.readUnsignedByte() << 8);
          mblock.cells[x][y].zpos   = mapFile.readByte() << 2;
        }
      }                    
    } catch (IOException e) {
      System.out.println("ERROR: IO error in map0.mul: " + e.getMessage());
      System.exit(0);
    }               
   return mblock;   	
 }

/***
 *
 * Reads a static block into memory. 
 * The sorting algorithm is known to be wrong! However he makes 99% right
 * knoxos: I don't seem to able to figure out the absolute find right way.
 *
 * @param id  id of the MapBlock to read.
 *
 * @return the static block
 *
 ***/
 public synchronized StaticBlock readStaticBlock(int id) 
 {
   long start = 0, llen = 0;     
   //int unkown = 0;
   int len = 0;
   int[][] cellcount = new int[8][8]; // how many tiles are in each block.
   for (int x = 0; x < 8; x++)
     for (int y = 0; y < 8; y++)
       cellcount[x][y] = 0;
       
   StaticBlock sBlock = new StaticBlock();
   sBlock.id = id;
   try {
     staticIndexFile.seek(12*id); 
     start = (long) staticIndexFile.readUnsignedByte() + (staticIndexFile.readUnsignedByte()  <<  8) + 
             (staticIndexFile.readUnsignedByte() << 16) + (staticIndexFile.readUnsignedByte() << 24);
     llen  = (long) staticIndexFile.readUnsignedByte() + (staticIndexFile.readUnsignedByte()  <<  8) + 
             (staticIndexFile.readUnsignedByte() << 16) + (staticIndexFile.readUnsignedByte() << 24);
     staticIndexFile.readUnsignedByte();
     staticIndexFile.readUnsignedByte();
     staticIndexFile.readUnsignedByte();
     staticIndexFile.readUnsignedByte();
     len   = (int) (llen / 12); // knoxos: I don't think there will ever be more than 65535 tiles in a block ;)
     len   = (int) (llen / 7); 
   } catch (IOException e) {     //         (and even if, I don't care about those that will not be displayed)
     System.out.println("ERROR: IO error in static index file: " + e.getMessage());
     System.exit(0);
   }   
   StaticParticle particles[] = null;  // save the tiles out of order in this array
   try {
     if (start == 0xFFFFFFFF) {
       //sBlock.runCount = 0;
     } else {
       staticDataFile.seek(start);
       //sBlock.runCount = len; 
       particles = new StaticParticle[len]; // save the tiles out of order in this array
       for (int i = 0; i < len; i++) {
         StaticParticle sparticle = new StaticParticle();
         sparticle.id = staticDataFile.readUnsignedByte() + (staticDataFile.readUnsignedByte() <<  8);
         int x = sparticle.x  = staticDataFile.readUnsignedByte();
     	 int y = sparticle.y  = staticDataFile.readUnsignedByte();
       	 cellcount[x][y]++; 
       	 sparticle.z  = staticDataFile.readByte();
         staticDataFile.readUnsignedByte();
         staticDataFile.readUnsignedByte();
       	 sparticle.tiledata = readStaticTileData(sparticle.id);       	 
       	 particles[i] = sparticle;
       }            	
     }       
   } catch (IOException e) {
     System.out.println("ERROR: IO error in static data file:" + e.getMessage());
     System.exit(0);
   }   
            
   // now sort the tiles into the cells
   StaticCell cells[][] = new StaticCell[8][8];
   for (int x = 0; x < 8; x++) {
     for (int y = 0; y < 8; y++) {
       StaticCell sCell = cells[x][y] = new StaticCell();
       sCell.tiles = new StaticParticle[cellcount[x][y]];
       int curcount = 0; // which tile of this cell
       for (int i = 0; i < len; i++) {
         if ((particles[i].x == x) && (particles[i].y == y))
           sCell.tiles[curcount++] = particles[i];
       }
     }
   }     
     
   // now sort the tiles into by height 
   for (int x = 0; x < 8; x++) {
     for (int y = 0; y < 8; y++) {
       StaticCell sc = cells[x][y];        
       for (int i = 0; i < sc.tiles.length; i++) {
         for (int j = i + 1; j < sc.tiles.length; j++) {
           if (sc.tiles[i].z > sc.tiles[j].z) {
             StaticParticle buf = sc.tiles[i];
             sc.tiles[i] = sc.tiles[j];               
             sc.tiles[j] = buf;                               
           } else if (sc.tiles[i].z == sc.tiles[j].z) {
             if (sc.tiles[i].id < sc.tiles[j].id) {
               StaticParticle buf = sc.tiles[i];
               sc.tiles[i] = sc.tiles[j];               
               sc.tiles[j] = buf;               
             }
           }               
         }
       }
     }
   }
     
   // now sort the tiles by priority
   for (int x = 0; x < 8; x++) {
     for (int y = 0; y < 8; y++) {
       StaticCell sc = cells[x][y];        
       for (int i = 0; i < sc.tiles.length; i++) {
         for (int j = i + 1; j < sc.tiles.length; j++) {
           //if ((((sc.tiles[i].flags & 0x01) == 0) && ((sc.tiles[j].flags & 0x01) != 0)) && (((sc.tiles[i].flags & 0x40) == 0x40) && ((sc.tiles[i].flags & 0xBE) == 0)) ) {
           StaticTileData tiledata = sc.tiles[i].tiledata;
           if (((sc.tiles[j].tiledata.flags & 0x00000200) == 0) &&  
               ((sc.tiles[i].tiledata.flags & 0x00000200) != 0)) {
               StaticParticle buf = sc.tiles[i];
               sc.tiles[i] = sc.tiles[j];               
               sc.tiles[j] = buf;               
           }
         }
       }
     }
   }
     
   sBlock.cells = cells;
   return sBlock;   	
 }
        
/*** 
 *
 * Reads the tile data from tiledata.mul
 *
 ***/
 public synchronized StaticTileData readStaticTileData(int id) 
 { 
   int pos = 512*836 + (id >> 5) * 1188 + (id & 0x1F) * 37 + 4;   
   //                      / 32               % 32         // for dword
   StaticTileData tiledata = new StaticTileData ();
   tiledata.id = id;
   try {
     tileDataFile.seek(pos);   
     tiledata.flags = (tileDataFile.readUnsignedByte() << 24) | 
                      (tileDataFile.readUnsignedByte() << 16) |
                      (tileDataFile.readUnsignedByte() <<  8) |
                       tileDataFile.readUnsignedByte();
     tileDataFile.seek(pos + 16);   
     tiledata.height = tileDataFile.readUnsignedByte();
     StringBuffer sb = new StringBuffer();
     for (int i = 0; i < 20; i++) {
       char c = (char) tileDataFile.readByte();
       if (c == 0)
        break;
       sb.append(c);
     }
                       
     //System.out.println("ID:" + id + " u1:" + u1 + " Name:" + name);
   } catch (IOException e) {
     System.out.println("ERROR: IOException while reading " + tileDataFilename + ": " + e.getMessage());
     System.exit(1);
   }  
   return tiledata;
 }  

}