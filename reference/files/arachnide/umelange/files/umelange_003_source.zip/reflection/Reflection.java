//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package reflection;

import java.awt.*;
import java.text.*;
import java.math.*;
import java.util.*;

import network.*;
import reflection.*;

/**
 *
 * The Reflection level, is the interface between the world and the graphic display.
 * It handles over all requests, but sperating task syntax. 
 *
 */  
public class Reflection extends Thread {   
 public static final int UP           = Network.NORTH_WEST;
 public static final int NORTH        = Network.NORTH;
 public static final int RIGHT        = Network.NORTH_EAST;
 public static final int EAST         = Network.EAST;
 public static final int DOWN         = Network.SOUTH_EAST;
 public static final int SOUTH        = Network.SOUTH;
 public static final int LEFT         = Network.SOUTH_WEST;
 public static final int WEST         = Network.WEST;        
        
 public int xPos = -1, yPos = -1, zPos = -1;
 public boolean worldUpdated = false;
 
 private static final int MESSAGE_LIST_SIZE = 5;
   
 private World   world;
 private Display display; 
 
 public boolean running = true; 

 private SysMessage sysMessages[];
 private int sysMsgListBegin  = 0;
 private int sysMsgListEnd    = 0;
 
 private Vector creatures = new Vector();
 
 public ActionList worldActions   = new ActionList();
 public ActionList displayActions = new ActionList();
   
 public Reflection(World world, Display display)
 {
   super("Reflection");
   this.world = world;
   this.display = display;   
   sysMessages = new SysMessage[MESSAGE_LIST_SIZE];
   for (int i = 0; i < MESSAGE_LIST_SIZE; i++) {
     sysMessages[i] = new SysMessage();   
   }   
   world.setReflection(this);
   display.setReflection(this);   
 }
     
/**
 *
 */
 public void run() 
 {     
   System.out.println("Reflection started.");
   Action action = new Action();
   while (running) {
     int msgnum = worldActions.peerMessage(action);
     if (msgnum != -1) {
       switch (action.cmd) {
          case ActionList.ACTION_WALK :
            //System.out.println("WALKING");
            int asw = world.walk(action.param1, false);
            worldActions.setAnswer(msgnum, asw);
            if (action.threadWaiting != null) 
              action.threadWaiting.interrupt();
            break;
          default :
            worldActions.finishAction(msgnum); // finish off action message
            System.out.println("INTERNAL FATAL, Reflection: invalid action event.");                      
            break;
       }        
     }           
     try {               
       sleep(1000);       
     } catch (InterruptedException e) {
       // nothing   
     }
   }
   System.out.println("Reflection stopped.");
 }         

/**
 * called from world
 */ 
 public synchronized void teleport(int x, int y, int z)
 {
   xPos = x;
   yPos = y;
   zPos = z;
   worldUpdated = true;
   display.interrupt();
 }

/**
 * called from display
 */
 public boolean walk(int direction, boolean run) 
 {
   int msgnum = worldActions.pushMessage(ActionList.ACTION_WALK, direction, Thread.currentThread());
   interrupt();   // set reflection thread to live

   //System.out.print("walk start wait ... ");
   // wait for answer
   while (!worldActions.isAnswered(msgnum)) {
     try {
       sleep(1000);
     } catch (InterruptedException e) {
       // nothing   
     }
   }  
   //System.out.println("stop ... ");
     
   int asw = worldActions.getAnswer(msgnum);
   if (asw != 256) {
     switch (direction) {
       case UP    : yPos++; xPos--; break;
       case NORTH : yPos--;         break;
       case RIGHT : yPos--; xPos++; break;
       case EAST  : xPos++;         break;
       case DOWN  : yPos--; xPos++; break;
       case SOUTH : yPos++;         break;
       case LEFT  : yPos++; xPos--; break;
       case WEST  : xPos--;         break;
     }           
     zPos = asw;   
     return true;        
   } else {
     return true;                
   }
 }
 
/**
 * called from display
 */ 
 public synchronized boolean updated() 
 {
   boolean oldworldUpdated = worldUpdated;
   worldUpdated = false;
   return oldworldUpdated;      
 }
 
/**
 * called from world
 */ 
 public synchronized void systemMessage(String text, int color) 
 {
   sysMessages[sysMsgListEnd].text  = text;
   sysMessages[sysMsgListEnd].color = color;
   if (++sysMsgListEnd == MESSAGE_LIST_SIZE) // buffer wrap around
     sysMsgListEnd = 0;   
   if (sysMsgListEnd == sysMsgListBegin) {      // if buffer full clear last entry
     if (++sysMsgListBegin == MESSAGE_LIST_SIZE)
       sysMsgListBegin = 0;        
   }
   worldUpdated = true;   
 }
 
/**
 * called from world
 */ 
 public synchronized void creatureSpeak(int playerId, String text, int color) 
 {
   Creature creature = (Creature) creatures.elementAt(playerId);
   text = creature.name + ": " + text;                     
   sysMessages[sysMsgListEnd].text  = text;
   sysMessages[sysMsgListEnd].color = color;
   if (++sysMsgListEnd == MESSAGE_LIST_SIZE) // buffer wrap around
     sysMsgListEnd = 0;   
   if (sysMsgListEnd == sysMsgListBegin) {      // if buffer full clear last entry
     if (++sysMsgListBegin == MESSAGE_LIST_SIZE)
       sysMsgListBegin = 0;        
   }
   worldUpdated = true;   
 }
/**
 * get a system message.
 *
 * @param p  position. 0 ist newest message SysMessageCount() is oldest message
 * 
 */ 
 public synchronized SysMessage getSystemMessage(int p)
 {
    int realpos = sysMsgListEnd - 1 - p;
    if (realpos < 0) 
      realpos += MESSAGE_LIST_SIZE;
    return sysMessages[realpos];
 }

/**
 * count system messages
 *
 * @return  number of saved system messages
 * 
 */ 
 public synchronized int systemMessageCount()
 { 
   int asw = sysMsgListEnd - sysMsgListBegin;
   if (asw < 0)
     asw += MESSAGE_LIST_SIZE;
   return asw;
 }
 
/**
 * called from world to add a creature
 *
 * @return  reflection creature id
 *
 */
 public synchronized int addCreature(String name, int x, int y, int z)
 {
   Creature creature = new Creature();   
   creature.name = new String(name);
   creature.x = x;
   creature.y = y;
   creature.z = z;
   creatures.addElement(creature);
   worldUpdated = true;
   return creatures.size() - 1;
 }
 
/**
 * called from world to change a creature
 *
 * @return  reflection creature id
 *
 */
 public synchronized void updateCreature(int id, String name, int x, int y, int z)
 {
   Creature creature = (Creature) creatures.elementAt(id);
   creature.name = new String(name);
   creature.x = x;
   creature.y = y;
   creature.z = z;
   worldUpdated = true;
 }
 
/**
 * called from world to change a creature
 *
 * @return  reflection creature id
 *
 */
 public synchronized void updateCreature(int id, int x, int y, int z)
 {
   Creature creature = (Creature) creatures.elementAt(id);
   creature.x = x;
   creature.y = y;
   creature.z = z;
   worldUpdated = true;
 }
 
/**
 * called from display
 *
 * @return  creature count
 *
 */
 public synchronized int creatureCount()
 {
   return creatures.size();
 } 



/**
 * called from display
 * read a creature
 *
 * @param id, id to read
 * @param object to fill data in, used to reduce memory operations
 *
 */
 public synchronized void getCreature(int id, Creature obj)
 {
   Creature creature = (Creature) creatures.elementAt(id);
   // the copy has to be done, so the new creature isn't affected by threads
   obj.name = creature.name;
   obj.x = creature.x;
   obj.y = creature.y;
   obj.z = creature.z;
 } 
 
/**
 * called from display
 *
 */
 public synchronized void talkRequest(String message)
 {
   world.talkRequest(message);
 }
}
