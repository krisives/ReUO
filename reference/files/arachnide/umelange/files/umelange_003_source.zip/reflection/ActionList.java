//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package reflection;

import java.awt.*;
import java.text.*;
import java.math.*;
import java.util.*;

/**
 *
 * Implements a FIFO for the action list.
 *
 * Should be accessable through reflection only.
 *
 */  
class ActionList {   
 public static final int MAX_ACTIONS            = 50;
        
/** 
 *
 * NO OPERANT - do nothing
 *
 * no params
 *
 */
 public static final int ACTION_NOP             =  0;

/** 
 * WALK - walk request
 *
 * param 1: direction
 *
 */
 public static final int ACTION_WALK            =  1;


 private Action actions[] = new Action[MAX_ACTIONS]; 
 private int answers[]    = new int[MAX_ACTIONS];
 private int actionBegin = 0;
 private int actionEnd   = 0;

 public ActionList()
 {
   for (int i = 0; i < MAX_ACTIONS; i++)
     actions[i] = new Action();   
 }
     
 public synchronized int peerMessage(Action action)
 {
   if (actionBegin == actionEnd)
     return -1;
   int msgnum = actionBegin;     
        
   action.cmd           = actions[msgnum].cmd;
   action.param1        = actions[msgnum].param1;
   action.threadWaiting = actions[msgnum].threadWaiting;

   if (++actionBegin == MAX_ACTIONS)
     actionBegin = 0;
   return msgnum;
 }

 public synchronized void setAnswer(int msgnum, int asw)
 {
   answers[msgnum] = asw;
   actions[msgnum].answered = true;
 }

/**
 * pop messages of buffer
 */
 public synchronized boolean isAnswered(int msgnum)
 {
   return actions[msgnum].answered;
 }
 
/**
 * pop messages of buffer
 */
 public synchronized int getAnswer(int msgnum)
 {
   int asw = answers[msgnum];   
   finishAction(msgnum);   
   return answers[msgnum];
 }
 
 public synchronized void finishAction(int msgnum)
 {
   actions[msgnum].finished = true;   
   while (actionBegin != actionEnd) {
     if (!actions[actionBegin].finished) {
       break;  
     }                     
     if (++actionBegin == MAX_ACTIONS)
       actionBegin = 0;
   }
 }

 public synchronized int pushMessage(Action action)
 {
   return pushMessage(action.cmd, action.param1, action.threadWaiting);
 }
 
 public synchronized int pushMessage(int cmd, int param1)
 {
   return pushMessage(cmd, param1, null);
 }

 public synchronized int pushMessage(int cmd, int param1, Thread threadWaiting)
 {
   if (((actionEnd + 1) == actionBegin) || ((actionBegin == 0) && (actionEnd == MAX_ACTIONS)))
     return -1;

   actions[actionEnd].cmd           = cmd;
   actions[actionEnd].param1        = param1;
   actions[actionEnd].threadWaiting = threadWaiting;
   actions[actionEnd].finished      = false;
   actions[actionEnd].answered      = false;
   int msgnum = actionEnd;
   
   if (++actionEnd == MAX_ACTIONS)
     actionEnd = 0;
   return msgnum;
 }
 
}

