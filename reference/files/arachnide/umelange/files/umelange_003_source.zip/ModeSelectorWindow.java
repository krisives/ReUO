//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.*;

/**
 *
 * This is the window where running mode is gathered. <br>
 *
 */

public class ModeSelectorWindow {
 static public final int MAX_LABELS = 5;

 static public final int WORLD_STASIS      = 1;
 static public final int WORLD_UO_NETWORK  = 2;

 static public final int DISPLAY_TEXTRA    = 1;
 static public final int DISPLAY_UO_VISION = 2;

/**
 * The frame for the game.
 */       
 Frame frame = null;
  
 Button startButton;
 Label  descLabels[];
 String detailText;
 int world;
 int display;
   
 private IniFile iniFile;  
 private String worldStr;
 private String displayStr;
   
/**
 * Constructor. Sets initial values read from ini file.
 * 
 * @param setCacheDemon      Cacher to get the data from.
 * @param setMapWindow       The map window.
 * @param setClearScreen     Shall the screen be "blued" before each frame?
 * @param setShowBall        Sets if the fireball in the middle is shown
 *
 */      
 ModeSelectorWindow(IniFile setIniFile) 
 {    
   //Create the top-level container and add contents to it.
   frame = new Frame("Ultimate Melange 0.0.3 - Mode Selectoin");
   frame.setResizable(false);
   frame.setBackground(Color.lightGray);
   
   iniFile = setIniFile;
   
   worldStr   = iniFile.getParameter("Select World", "Stasis").toUpperCase();
   displayStr = iniFile.getParameter("Select Display", "UO-Vision").toUpperCase();
   
   if (worldStr.equals("STASIS")) {
     world = WORLD_STASIS;
   } else if (worldStr.equals("UO-NETWORK")) {
     world = WORLD_UO_NETWORK;
   } else {
     System.out.println("ERROR: Invalid world paramater in .ini file, supposing default.");    
     world = WORLD_STASIS;
   }

   if (displayStr.equals("TEXTRA")) {
     display = DISPLAY_TEXTRA;
   } else if (displayStr.equals("UO-VISION")) {
     display = DISPLAY_UO_VISION;
   } else {
     System.out.println("ERROR: Invalid display paramater in .ini file, supposing default.");    
     display = DISPLAY_UO_VISION;
   }
          
   Panel worldSelectorPanel = new Panel(new BorderLayout(20, 20));      
   LinedPanel linedWorldSelectorPanel = new LinedPanel(worldSelectorPanel, true, false, false ,true, 
                                                                           10,   0,      0,   10,
                                                                           10,   10,    10,   10);   
   CheckboxGroup worldcbg = new CheckboxGroup();
   worldSelectorPanel.setLayout(new GridLayout(2, 1));
   Checkbox stasisWorld = new Checkbox("Stasis world", worldcbg, true);
   Checkbox uoNetworkWorld = new Checkbox("UO Network (Ignition)", worldcbg, true);
   worldSelectorPanel.add(stasisWorld);
   worldSelectorPanel.add(uoNetworkWorld);      
   
   Panel displaySelectorPanel = new Panel(new BorderLayout(20, 20));      
   LinedPanel linedDisplaySelectorPanel = new LinedPanel(displaySelectorPanel, true, true, false ,true, 
                                                                               10,   10,    0,   0,
                                                                               10,   10,   10,   10);   
   CheckboxGroup displaycbg = new CheckboxGroup();
   displaySelectorPanel.setLayout(new GridLayout(2, 1));
   Checkbox textraDisplay   = new Checkbox("TEXTRA text based display", displaycbg, true);
   Checkbox uoVisionDisplay = new Checkbox("UO Vision", displaycbg, true);
   displaySelectorPanel.add(textraDisplay);
   displaySelectorPanel.add(uoVisionDisplay);      

   GridBagLayout gridbag = new GridBagLayout();
   GridBagConstraints constrains = new GridBagConstraints();
   frame.setLayout(gridbag);
   constrains.fill = GridBagConstraints.BOTH;
   constrains.weightx =  1.0;   
   constrains.weighty = 12.0;   
   //constrains.gridwidth = GridBagConstraints.RELATIVE; //end row   
   gridbag.setConstraints(linedWorldSelectorPanel, constrains);
   frame.add(linedWorldSelectorPanel);
   
   constrains.gridwidth = GridBagConstraints.REMAINDER; //end row   
   gridbag.setConstraints(linedDisplaySelectorPanel, constrains);
   frame.add(linedDisplaySelectorPanel);


   GridBagLayout descGridBag = new GridBagLayout();
   Panel descPanel = new Panel(descGridBag);
   LinedPanel linedDescPanel = new LinedPanel(descPanel, true, true, false ,true, 
                                                            0,   10,    0,   10,
                                                           10,   10,   10,   10);  
   Panel buttonPanel = new Panel(new BorderLayout());
   LinedPanel linedButtonPanel = new LinedPanel(buttonPanel, true, true, true ,true, 
                                                                0,   10,   10,   10,
                                                               10,   10,   10,   10);  
   
   
   constrains.weightx = 2.0;
   constrains.weighty = 5.0;
   
   constrains.gridwidth = GridBagConstraints.REMAINDER; //end row   
   gridbag.setConstraints(linedDescPanel, constrains);

   frame.add(linedDescPanel);
   constrains.weightx = 2.0;   
   constrains.weighty = 2.0;
   constrains.gridwidth = GridBagConstraints.REMAINDER; //end row   
   gridbag.setConstraints(linedButtonPanel, constrains);

   //constrains.gridwidth = 1; //end row   
   
   frame.add(linedButtonPanel);
   
   descLabels = new Label[MAX_LABELS];
   GridBagConstraints descConstrains = new GridBagConstraints();
   descConstrains.weightx   = 1.0;
   descConstrains.fill      = GridBagConstraints.HORIZONTAL;   
   descConstrains.gridwidth = GridBagConstraints.REMAINDER;   
   for (int i = 0; i < 5; i++) {
     descLabels[i] = new Label();
     descLabels[i].setAlignment(Label.CENTER);
     descGridBag.setConstraints(descLabels[i], descConstrains);
     descPanel.add(descLabels[i]);
   }
   
   startButton = new Button("S  T  A  R  T");
   buttonPanel.add(startButton);

   switch (world) {
     case WORLD_STASIS :     
       stasisWorld.setState(true);
       break;
     case WORLD_UO_NETWORK :     
       uoNetworkWorld.setState(true);   
       break; 
   }
   switch (display) {
     case DISPLAY_TEXTRA :
       textraDisplay.setState(true);   
       break;
     case DISPLAY_UO_VISION :
       uoVisionDisplay.setState(true);   
       break;
   }
            
   stasisWorld.addItemListener(new ItemListener() {
     public void itemStateChanged(ItemEvent e)  
     {
       world    = WORLD_STASIS;
       checkInput();
     }
   });

   uoNetworkWorld.addItemListener(new ItemListener() {
     public void itemStateChanged(ItemEvent e)  
     {
       world    = WORLD_UO_NETWORK;
       checkInput();
     }
   });
  
   textraDisplay.addItemListener(new ItemListener() {
     public void itemStateChanged(ItemEvent e)  
     {
       display  = DISPLAY_TEXTRA;
       checkInput();
     }
   });

   uoVisionDisplay.addItemListener(new ItemListener() {
     public void itemStateChanged(ItemEvent e)  
     {
       display  = DISPLAY_UO_VISION;
       checkInput();
     }
   });
   checkInput();

   startButton.addActionListener(new ActionListener() {
     public void actionPerformed(ActionEvent e) 
     {        
       boolean modified = false;
       switch (world) {
         case WORLD_STASIS :     
           if (worldStr != "STASIS") {
             iniFile.setParameter("Select World", "Stasis");
             modified = true;
           }
           break;
        case WORLD_UO_NETWORK :     
           if (worldStr != "UO-NETWORK") {
             iniFile.setParameter("Select World", "UO-Network");
             modified = true;
           }
           break;
       }

       switch (display) {
         case DISPLAY_TEXTRA :     
           if (worldStr != "TEXTRA") {
             iniFile.setParameter("Select Display", "Textra");
             modified = true;
           }
           break;
        case WORLD_UO_NETWORK :     
           if (worldStr != "UO-VISION") {
             iniFile.setParameter("Select Display", "UO-Vision");
             modified = true;
           }
           break;
       }
       if (modified)
         iniFile.flush();
       frame.setVisible(false);
       Main.modeSelected(world, display);       
    }     
  });

   frame.pack();
   frame.validate();
   Toolkit tools = Toolkit.getDefaultToolkit();
   Dimension screen = tools.getScreenSize();

   frame.setSize(new Dimension(640, 480));
   frame.setLocation((screen.width - 640) / 2,(screen.height - 480) / 2);

   frame.setVisible(true);    
   frame.setLocation((screen.width - 640) / 2,(screen.height - 480) / 2);

   startButton.requestFocus();
   frame.addWindowListener(new WindowAdapter() {
        public void windowClosing(WindowEvent e) {
          frame.setVisible(false);
          System.out.println("Canceled startup on mode selection.");
          System.exit(1);
        }
   });   
 }

 private void checkInput() {
   switch (world) {
     case WORLD_STASIS :     
       switch (display) {
         case DISPLAY_TEXTRA :
           // STASIS + TEXTRA
           descLabels[0].setText("Well, this is quite a boring mode, however it is still valid combination.");
           descLabels[1].setText("You can view your static world data in a text based mode.");
           descLabels[2].setText("");
           descLabels[3].setText("");
           descLabels[4].setText("");
           startButton.setEnabled(true);
           break;
         case DISPLAY_UO_VISION :
           // STASIS + UO_VISION
           descLabels[0].setText("Graphical emulation of the UO Client with a frozen world. ");
           descLabels[1].setText("You can freely walk around the world, and see things you would never ");
           descLabels[2].setText("reach/discover on normal way.");
           descLabels[3].setText("");
           descLabels[4].setText("");
           startButton.setEnabled(true);
           break;
       }           
       break; 
     case WORLD_UO_NETWORK :     
       switch (display) {
         case DISPLAY_TEXTRA :
           // UO_NETWORK + TEXTRA
           descLabels[0].setText("Welcome to you to your timewarp into the 80ies. In this mode you can already");
           descLabels[1].setText("log on to an UO(X) shard, walk around watching and talking with other players.");
           descLabels[2].setText("Give your mouse a break, and watch ASCII art with it's own (old) fascination.");
           descLabels[3].setText("");
           descLabels[4].setText("");
           startButton.setEnabled(true);
           break;
         case DISPLAY_UO_VISION :
           // UO_NETWORK + UO_VISION
           descLabels[0].setText("Sorry, this combination is not yet valid!");
           descLabels[1].setText("Yeah guessed it: this was the mode you're were looking for, right?");
           descLabels[2].setText(". . . once agin, sorry for now  . . .");
           descLabels[3].setText("");
           descLabels[4].setText("");
           startButton.setEnabled(false);
           break;
       }           
       break; 
   }
 }
 
 /**
  * Reads values out of iniFile and calls the corresponding Main.class function
  * Used to override the modeSelector screen ("no select window" parameter)  
  * This function is declared static so the window does not need to be instanced / viewed.
  *
  * @param iniFile   The IniFile the read parameters from
  */
 public static void getSelection(IniFile iniFile) 
 {
   String worldStr   = iniFile.getParameter("Select World", "Stasis").toUpperCase();
   String displayStr = iniFile.getParameter("Select Display", "UO-Vision").toUpperCase();
   int world;
   int display;
   
   if (worldStr.equals("STASIS")) {
     world = WORLD_STASIS;
   } else if (worldStr.equals("UO-NETWORK")) {
     world = WORLD_UO_NETWORK;
   } else {
     System.out.println("ERROR: Invalid world paramater in .ini file, supposing default.");    
     world = WORLD_STASIS;
   }

   if (displayStr.equals("TEXTRA")) {
     display = DISPLAY_TEXTRA;
   } else if (displayStr.equals("UO-VISION")) {
     display = DISPLAY_UO_VISION;
   } else {
     System.out.println("ERROR: Invalid display paramater in .ini file, supposing default.");    
     display = DISPLAY_UO_VISION;
   }        
   Main.modeSelected(world, display);
 }
}


