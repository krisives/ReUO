//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package skin;

import java.awt.*;
import java.awt.image.*;

/** 
 *
 * A raw tile.
 *
 */  
public class MapTile  {   
  /**
   * Size of sprite data.
   */        
   public static final int DATASIZE = 1012;

  /**
   * The mask of a standard tile.
   * It is not used now.
   */        
   public static boolean mask[][];
   
  /**
   * Graphic data of the tile,
   */        
   public int data[] = new int[DATASIZE];
   
  /**
   *
   * Creates the mask.
   *
   */        
   public static void initialize() {
     mask = new boolean [44][44];
     // initiazie raw transpereny mask
     for (int y = 0; y < 44; y++)
       for (int x = 0; x < 44; x++)
         mask[x][y] = false;
     for (int y = 0; y < 22; y++) {
       for (int x = 21 - y; x < 21 + y + 2; x ++) {              
         mask[x][y] = true;        
         mask[x][43-y] = true;
       }
     }
   }
 }