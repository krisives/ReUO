//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package skin;

import java.io.*;

import Main;
import Sprite;

/** 
 * SkinReader
 *
 ***/  
 public class UmeSkinReader {   
   private static final int MAX_STATIC_SPRITES = 0x4000;
   private static final byte[] magicHeader = {'U', 'M', 'E', ' ', 'S', 'K', 'I', 'N',
                                              Main.MAJOR, 
                                              Main.MINOR, 
                                              Main.BUILD, 
                                              1,
                                              0, 0, 0, 0, 
                                              0, 0, 0, 0, 
                                              0, 0, 0, 0, 
                                             };

   private String           filename;
   private RandomAccessFile skinFile;
   private ByteArrayInputStream deserializeBuffer;
   private ObjectInputStream    deserializer;
      
   private int staticSpritesOffset[];
   private int staticSpritesLength[];
   
   private long segment_staticSpritesIndex;
   private long segment_staticSpritesData;
   
   public UmeSkinReader(String filename) 
   {
     this.filename = filename;
     staticSpritesOffset = new int[MAX_STATIC_SPRITES];
     staticSpritesLength = new int[MAX_STATIC_SPRITES];         
   }
   
   public boolean open() throws IOException 
   {
     //deserializeBuffer = new ByteArrayInputStream();
     //deserializer = new ObjectInputStream(deserializeBuffer);
     
     File file = new File(filename);
     if (!file.exists()) {
       System.out.println("File " + filename + " not found.");
       throw new FileNotFoundException();
     }          
     skinFile = new RandomAccessFile(file, "r");
     
     byte[] header = new byte[magicHeader.length];
     skinFile.read(header);     
     boolean equal;
     if (header.length == magicHeader.length) {
       equal = true;
       for (int i = 0; i < header.length; i++) {
         if (header[i] != magicHeader[i]) {
           equal = false;
           break;
         }           
       }  
     } else {
       equal = false;  
     }
     
     if (!equal) {
       System.out.println("Skin file " + filename + " corrupt, magic header not correct");
       return false;
     }
     
     // read segment offsets
     segment_staticSpritesIndex = skinFile.readInt();
     segment_staticSpritesData  = skinFile.readInt();
     
     // read static sprite offsets and lengths
     skinFile.seek(segment_staticSpritesIndex);
     
     for (int i = 0; i < MAX_STATIC_SPRITES; i++) {
       staticSpritesOffset[i] = skinFile.readInt();
       staticSpritesLength[i] = skinFile.readInt();
     }
     return true;
   }
   
   public void close() throws IOException
   {
     skinFile.close();    
   }
   
   public Sprite readStaticSprite(int id) 
   {
     Sprite sprite = null;
     //System.out.println("OFFSET:" + staticSpritesOffset[id]);
     //System.out.println("LENGTH:" + staticSpritesLength[id]);
     //System.out.println("ID:" + id);
     if ((staticSpritesOffset[id] == 0) || (staticSpritesLength[id] == 0)) {
       //System.out.println("WARNING non existing skin object read");
       return null;
     }
     
     try {
       skinFile.seek(staticSpritesOffset[id]);
       byte[] data = new byte[staticSpritesLength[id] + 1];
       //System.out.println("DATALENGTH:" + data.length);
       skinFile.read(data);
       //for ( int j = 0; j < data.length; j++) {
       //  System.out.print(data[j] + " ");
       //}       
       ByteArrayInputStream buffer = new ByteArrayInputStream(data);
       ObjectInputStream deserializer = new ObjectInputStream(buffer);
       sprite = (Sprite) deserializer.readObject();
     } catch (IOException e) {
       System.out.println("ERROR: IOException while reading skin tile " + id + ": " + e.getMessage());
       System.out.println("offset : " + staticSpritesOffset[id]);
       System.out.println("length : " + staticSpritesLength[id]);
       System.exit(1);
     } catch (ClassNotFoundException e) {
       System.out.println("ERROR: Class not found in skin :" + e.getMessage());
       System.exit(1);
     }
     return sprite;         
   }   
}