//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package skin;

import java.awt.*;
import java.awt.image.*;
import java.io.Serializable;

/** 
 * A Sprite.
 *
 * Detailed function of the sprite alogorithm will be placed on the documentation
 * page of the umelange homepage. (www.geocites.com/umelange)
 *
 ***/  
 public class SpriteBase implements Serializable {   
  /**
   * How much data get or jump over
   */
   public int run[];

  /**
   * The graphics data, stored continuesly without gaps.
   */
   public int data[];
  /**
   * Width of the sprite
   */
   public int width     = 0;

  /**
   * Height of the sprite
   */
   public int height    = 0; 

  /**
   * Length of run array.
   */
   public int rlen      = 0;
   
  /**
   * Reads an image (.gif) from harddisk and creates a corresponig sprite. <br>
   *
   * At the color of the most upper,left pixel is used as backcolor.
   * Should be replaced by the one specified by the gif format, but I couldn't yet find out 
   * how to read it.
   */
   public void takeImage(Image img, ImageObserver obs) 
   {
     width = img.getWidth(obs);
     height = img.getHeight(obs);
     int size = width*height;
     //int nextLineLen = bufWidth - width;
     
     PixelGrabber pg = new PixelGrabber(img, 0, 0, width, height, true);     
     try {
       pg.grabPixels();
     } catch (InterruptedException e) {
       System.out.println("INTERRUPTED!");
       return;	
     }
     //first calculate the size of arrays
     while ((pg.getStatus() & ImageObserver.ALLBITS) == 0);
     int pixels[] = (int[]) pg.getPixels();
     int datasize = 0;
     int runsize = 0;
     
     int background = pixels[0];
     boolean level = false; // true if foreground, false if background
     for (int i = 0, x = 0; i < size; i++, x++) {
       int pix = pixels[i];
       if (x==width) {
       	 x = 0;
       	 if (level) {
           //level = false;
       	   runsize++;       	 	
       	 }
       }
       if (level)
         datasize++;
       if (level && (pix!=background)) {
       	 level = false;
       	 runsize++;
       } else if (!level && (pix!=background)) {
       	 level = true;
       	 runsize++;
       }
     }     
     runsize++;
     //runsize *= 2;
     // now the size is known, build the arrays...
     run  = new int[runsize];
     data = new int[datasize];
     int dpos = 0;
     int rpos = 0;
     int len  = 0;
     level = false;    
     boolean nextline = false;    
     for (int i = 0, x = 0; i < size; i++, x++) {
       int pix = pixels[i];
       if (x==width) {
       	 x = 0;
       	 if (level) {
           run[rpos++] = len + 1;
       	 }
         len = 0;
       	 nextline = true;
       }
       len++;                
       if (level && (pix!=background)) 
         data[dpos++] = pixels[i];       
       if (level && (pix==background)) {
       	 level = false;
   	 run[rpos++] = len - 1;
       	 len = 0;
       } else if (!level && (pix!=background)) {
       	 level = true;
         if (nextline)
           run[rpos++] = -len - 1;
         else   
           run[rpos++] = len + 1;
       	 nextline = false;
       	 len = 0;
       }
     }      
     run[rpos] = 0;
     // copy locals to globals    
     rlen = rpos - 2;
   }

  /**
   * Reads an image (.gif) from harddisk and creates a corresponig sprite. <br>
   *
   * This image is nonTransparent and has a square outline
   */
   public void takeImage_nonTransparent(Image img, ImageObserver obs) 
   {
     width = img.getWidth(obs);
     height = img.getHeight(obs);
     int size = width*height;
     //int nextLineLen = bufWidth - width;
     
     PixelGrabber pg = new PixelGrabber(img, 0, 0, width, height, true);     
     try {
       pg.grabPixels();
     } catch (InterruptedException e) {
       System.out.println("INTERRUPTED!");
       return;	
     }
     //first calculate the size of arrays
     while ((pg.getStatus() & ImageObserver.ALLBITS) == 0);
     int pixels[] = (int[]) pg.getPixels();
     int datasize = 0;
     int runsize = 0;
     
     int background = pixels[0];
     boolean level = false; // true if foreground, false if background    
     run  = new int[height * 2 + 1];
     data = new int[height * width];
     run[0] = 0;
     int rpos = 1;
     int dpos = 0;
     for (int i = 0, x = 0; i < size; i++, x++) {
       int pix = pixels[i];
       if (x==width) {
       	 x = 0;
         run[rpos++] = width;
         run[rpos++] = 0;
       }
       data[dpos++] = pixels[i];       
     }      
     run[rpos] = 0;
     // copy locals to globals    
     rlen = rpos - 2;
   }
 }