//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package skin;

import java.io.*;
import java.awt.*;
import java.awt.image.*;

import AnimSprite;
import Sprite;

/** 
 *
 * Read data from the original client, the '.mul' files
 *
 * For format of these files please also see at UOInside: <br>
 *
 * <a href>http://dkbush.cablenet-va.com/alazane/file_formats.html</a>
 *
 */  
public class MulSkinReader {   
 public  final        int RUN_TILE_OFFSET = 16384;   
	   	
 private RandomAccessFile animDataFile    = null;
 private RandomAccessFile animIndexFile   = null;
 private RandomAccessFile artDataFile     = null;
 private RandomAccessFile artIndexFile    = null;
 private RandomAccessFile radarColorFile  = null;
 private String artDataFilename           = null;
 private String artIndexFilename          = null;
 private String radarColorFilename        = null;
 private String animDataFilename          = null;
 private String animIndexFilename         = null;
                                
 public MulSkinReader(String uoPath) throws IOException {
   animIndexFilename = uoPath + "anim.idx";
   System.out.print("  ");
   System.out.print(animIndexFilename);
   System.out.print(" ... ");
   animIndexFile = new RandomAccessFile(animIndexFilename,"r");     
   System.out.println(" OK ");
     
   animDataFilename = uoPath + "anim.mul";
   System.out.print("  ");
   System.out.print(animDataFilename);
   System.out.print(" ... ");
   animDataFile = new RandomAccessFile(animDataFilename,"r");     
   System.out.println(" OK ");

   artDataFilename = uoPath + "art.mul";
   System.out.print("  ");
   System.out.print(artDataFilename);
   System.out.print(" ... ");
   artDataFile = new RandomAccessFile(artDataFilename,"r");     
   System.out.println(" OK ");
     
   artIndexFilename = uoPath + "artidx.mul";
   System.out.print("  ");
   System.out.print(artIndexFilename);
   System.out.print(" ... ");
   artIndexFile = new RandomAccessFile(artIndexFilename,"r");     
   System.out.println(" OK ");

   radarColorFilename = uoPath + "radarcol.mul";
   System.out.print("  ");
   System.out.print(radarColorFilename);
   System.out.print(" ... ");
   radarColorFile = new RandomAccessFile(radarColorFilename,"r");     
   System.out.println(" OK ");
 }
   
/**
 *
 * Called to free resources, close the files.
 *
 */
 public synchronized void close() {
    System.out.print("  ");
    System.out.print(artDataFilename);
    System.out.print(" ... ");      
    try {
      artDataFile.close();
      System.out.println("OK");
    } catch (IOException e) {
      System.out.println("Failure");
    }
    System.out.print("  ");
    System.out.print(artIndexFilename);
    System.out.print(" ... ");      
    try {
      artIndexFile.close();
      System.out.println("OK");
    } catch (IOException e) {
      System.out.println("Failure");
    }
 }

/**
 *
 * Reads a raw tile into memory.
 *
 * @param id     ID of the tile.
 *
 */   
 public synchronized MapTile readMapTile(int id) 
 {
   MapTile aTile = new MapTile();     
   try {
     artIndexFile.seek(id*12);
     long index = (artIndexFile.readUnsignedByte()      ) + (artIndexFile.readUnsignedByte() <<  8) + 
                  (artIndexFile.readUnsignedByte() << 16) + (artIndexFile.readUnsignedByte() << 24);
      if (index == 0xFFFFFFFF) {
        //System.out.println("ERROR: illlegal index of map-tile read, id:" + id);
        return null;	
      }
      artDataFile.seek(index);       
      for (int i = 0; i < MapTile.DATASIZE; i++) {
        int pixel16 = artDataFile.readUnsignedByte() + (artDataFile.readUnsignedByte() << 8);
        int pixel32 = (0xFF000000 |
                      ((((pixel16 >> 10) & 0x1F) * 0xFF / 0x1F) << 16) |
                      ((((pixel16 >> 5) & 0x1F) * 0xFF / 0x1F) << 8) |
                       ((( pixel16 & 0x1F) * 0xFF / 0x1F)));
        aTile.data[i] = pixel32;
      }              
    } catch (IOException e) {
      System.out.println("ERROR: IOException while reading tile in " + artDataFilename + " :" + e.getMessage());
      System.exit(1);
    }  
    return aTile;   	     
  }
 
             
/***
 *
 * Reads a run sprite into memory.
 *
 * @param id  id of the MapBlock to read.
 * @param id  buffer of width of tile.
 *
 * @return the MapBlock
 *
 ***/
 public synchronized Sprite readStaticSprite(int id) 
 { 
   Sprite aSprite = new Sprite();
   try {
     artIndexFile.seek((RUN_TILE_OFFSET + id)*12);
     int index = (artIndexFile.readUnsignedByte()      ) + (artIndexFile.readUnsignedByte() <<  8) + 
                 (artIndexFile.readUnsignedByte() << 16) + (artIndexFile.readUnsignedByte() << 24);
     if (index == 0xFFFFFFFF) {
       //System.out.println("ERROR: illlegal index of static-tile read, id:" + id);
       return null;	
     }
     artDataFile.seek(index + 4); // 4 to skip some header (size?)
     int width  = artDataFile.readUnsignedByte() + (artDataFile.readUnsignedByte() <<  8);
     int height = artDataFile.readUnsignedByte() + (artDataFile.readUnsignedByte() <<  8);
     if (height == 0)  // no height, no sprite
       return null;
     int lStart[] = new int[height];            
     int data[] = new int[width*height];
     int run[] = new int[width*height];
     for (int i=0; i< height; i++) {
       lStart[i] = artDataFile.readUnsignedByte() + (artDataFile.readUnsignedByte() <<  8);
     }
     long dStart = artDataFile.getFilePointer();
     int x = 0;
     int y = 0;
     int rpos = 0;
     int dpos = 0;
     boolean linefeed = false;
     int len = 0;     
     artDataFile.seek(dStart + (lStart[y] << 1)); 
     int runned = 0;
     while (y < height) {
       int xoffs = artDataFile.readUnsignedByte() + (artDataFile.readUnsignedByte() <<  8);
       int runby = artDataFile.readUnsignedByte() + (artDataFile.readUnsignedByte() <<  8);
       runned += 4;
       if (runby != 0) {
         // background
         if (linefeed)
           run[rpos++] = -(len + xoffs);
         else
           run[rpos++] = +(len + xoffs);
         linefeed = false;
         x += xoffs + runby;
         len = 0;   
         // foreground
         for (int i = 0; i < runby; i++) {
           int pixel16 = artDataFile.readUnsignedByte() + (artDataFile.readUnsignedByte() << 8);
           runned += 2;
           int pixel32 = ((((pixel16 >> 10) & 0x1F) * 0xFF / 0x1F) << 16) |
                         ((((pixel16 >> 5) & 0x1F) * 0xFF / 0x1F) << 8) |
                          (((pixel16 & 0x1F) * 0xFF / 0x1F));
           data[dpos++] = pixel32;
         }
         run[rpos++] = runby;
         //runned += (runby << 1) + 8;
       } else {
         // backgound
         //if (linefeed) {
         //  run[rpos++] = 0;      
         //  run[rpos++] = 0;      
         //}
         linefeed = true;
         x = 0;
         y++;
         if (y < height) {        
           artDataFile.seek(dStart + (lStart[y] << 1));
         }
       }         
     }       
     run[rpos] = 0;
     aSprite.width  = width;
     aSprite.height = height;
     // cut down arrays to proper fit. (copy them)
     int fdata[] = new int[dpos];
     int frun[]  = new int[rpos];
     System.arraycopy(run,  0, frun, 0,  rpos);
     System.arraycopy(data, 0, fdata, 0, dpos);
     aSprite.data   = fdata;
     aSprite.run    = frun;
     aSprite.rlen   = rpos - 1;
   } catch (IOException e) {
     System.out.println("ERROR: IOException while reading tile in " + artDataFilename + " :" + e.getMessage());
     System.exit(1);
   }  
   return aSprite;	
 }
  
  
/*** 
 *
 * Reads the radar colors from radarcol.mul
 *
 ***/
 public synchronized int[] readRadarColors() 
 { 
   int colors[] = new int[65536];
   
   try {
     for (int i = 0; i < 65536; i++) {
       int pixel16 = radarColorFile.readUnsignedByte() + (radarColorFile.readUnsignedByte() << 8);
       colors[i] = (0xFF000000 |
                   ((((pixel16 >> 10) & 0x1F) * 0xFF / 0x1F) << 16) |
                    ((((pixel16 >> 5) & 0x1F) * 0xFF / 0x1F) << 8) |
                    ((( pixel16 & 0x1F) * 0xFF / 0x1F)));
     }
   } catch (IOException e) {
     System.out.println("ERROR: IOException while reading tile in " + radarColorFilename + " :" + e.getMessage());
     System.exit(1);
   }  
   return colors;
 }  

/***
 *
 * Reads a animation sprite into memory.
 *
 * @param id  id of the MapBlock to read.
 * @param id  buffer of width of tile.
 *
 * @return the MapBlock
 *
 ***/
 public synchronized AnimSprite readAnimSprite(int id, int frame) 
 { 
   AnimSprite aSprite = new AnimSprite();
   try {
     animIndexFile.seek(id * 12);
     int index = (animIndexFile.readUnsignedByte()      ) + (animIndexFile.readUnsignedByte() <<  8) + 
                 (animIndexFile.readUnsignedByte() << 16) + (animIndexFile.readUnsignedByte() << 24);
     if (index == 0xFFFFFFFF) {
        
       System.out.println("ERROR: illlegal animation index read, id:" + id);
       return null;	
     }
     int size  = (animIndexFile.readUnsignedByte()      ) + (animIndexFile.readUnsignedByte() <<  8) + 
                 (animIndexFile.readUnsignedByte() << 16) + (animIndexFile.readUnsignedByte() << 24);
     int palette[] = new int[256];
     animDataFile.seek(index); // goto pallette
     for (int i = 0; i < 256; i++) {
       int pixel16 = (animDataFile.readUnsignedByte()) + (animDataFile.readUnsignedByte() <<  8);
       
       palette[i] = ((((pixel16 >> 10) & 0x1F) * 0xFF / 0x1F) << 16) |
                    ((((pixel16 >> 5) & 0x1F) * 0xFF / 0x1F) << 8) |
                     (((pixel16 & 0x1F) * 0xFF / 0x1F));
     }
     
     int framecount = (animDataFile.readUnsignedByte()      ) + (animDataFile.readUnsignedByte() <<  8) + 
                      (animDataFile.readUnsignedByte() << 16) + (animDataFile.readUnsignedByte() << 24);               
     if (frame >= framecount) {
       System.out.println("ERROR: tried to read more frames than exist id:" + id + "frame:" + frame);
       return null;	        
     }
     
     animDataFile.seek(index + 512 + 4 + 4 * frame); // goto position interesting
     int frameindex = (animDataFile.readUnsignedByte()      ) + (animDataFile.readUnsignedByte() <<  8) + 
                      (animDataFile.readUnsignedByte() << 16) + (animDataFile.readUnsignedByte() << 24);
     animDataFile.seek(index + 512 + frameindex); // goto position interesting
     int centX = animDataFile.readUnsignedByte() + (animDataFile.readUnsignedByte() <<  8);
     int centY = animDataFile.readUnsignedByte() + (animDataFile.readUnsignedByte() <<  8);
     if ((centX & 0x8000) != 0)  
       centX = - (centX ^ 0xFFFF) + 1;
     if ((centY & 0x8000) != 0)   
       centY = - (centY ^ 0xFFFF) + 1;
     int width  = animDataFile.readUnsignedByte() + (animDataFile.readUnsignedByte() <<  8);
     int height = animDataFile.readUnsignedByte() + (animDataFile.readUnsignedByte() <<  8);
     int data[] = new int[width*height];
     int run[] = new int[width*height];     
     int rpos = 0;
     int dpos = 0;
     
     int prevline = -1;
     int x = 0;
     int y = 0;
     int lastline = -1;
     while (y < height) {
       int rowHeader = animDataFile.readUnsignedByte() + (animDataFile.readUnsignedByte() <<  8);
       int rowofs    = animDataFile.readUnsignedByte() + (animDataFile.readUnsignedByte() <<  8);

       if ((rowHeader == 0x7FFF) || (rowofs == 0x7FFF))
         break;
       
       int runby   = rowHeader & 0xfff;
       int linenum = rowHeader >> 12;
       boolean sign    = ((rowofs & 0x8000) != 0) ? true : false;
       int xoffs   = (rowofs) >> 6;
       if (sign) {
         xoffs += centX - 1024;
       } else {
         xoffs += centX;
       }
       
       int lastrunby = 0;
       if (linenum == lastline) {
         run[rpos++] = xoffs - x;
         x = xoffs + runby;
         for (int i = 0; i < runby; i++) {
           data[dpos++] = palette[animDataFile.readUnsignedByte()];
         }
         run[rpos++] = runby;
       } else {
         y++;
         if (linenum == -1)
           run[rpos++] = xoffs - x;
         else
           run[rpos++] = -xoffs; 
         x = xoffs + runby;
         for (int i = 0; i < runby; i++) {
           int dat = animDataFile.readUnsignedByte();           
           data[dpos++] = palette[dat];
         }
         run[rpos++] = runby;         
       }         
       lastline = linenum;
       lastrunby = runby;
     }       
            
     int fdata[] = new int[dpos];
     int frun[]  = new int[rpos];
     System.arraycopy(data, 0, fdata, 0, dpos);
     System.arraycopy(run,  0, frun, 0,  rpos);
  
     aSprite.data   = fdata;
     aSprite.run    = frun;
     aSprite.rlen   = rpos - 1;
     aSprite.height = height;
     aSprite.width  = width;
     aSprite.centX  = centX;
     aSprite.centY  = centY;
   } catch (IOException e) {
     System.out.println("ERROR: IOException while reading tile in " + artDataFilename);
     System.exit(1);
   }  
   return aSprite;	
 }


}