//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package skin;

import java.io.*;

import Main;
import Sprite;
import ProgressWindow;

/** 
 * SkinFromMulWriter
 *
 * Creates a skin from standard .mul files
 *
 ***/  
 public class SkinFromMulWriter {   
   private static final int MAX_STATIC_SPRITES = 0x4000;

   private String           filename;
   private MulSkinReader    mulReader;     
   private RandomAccessFile skinFile;
   
   private ProgressWindow progress;
      
   private int segment_staticSpritesIndex = 0x800;
   //private long segment_staticSpritesData;
   private int staticSpritesOffset[];
   private int staticSpritesLength[];
   
   public SkinFromMulWriter(String filename, MulSkinReader mulReader) throws IOException
   {
     this.filename = filename;
     this.mulReader = mulReader; 
     staticSpritesOffset = new int[MAX_STATIC_SPRITES];
     staticSpritesLength = new int[MAX_STATIC_SPRITES];
   }
   
   public void exec() throws IOException
   {
     File file = new File(filename);
     progress = new ProgressWindow(0x4000 / 16);
     if (file.exists()) {
       System.out.println("File " + filename + " already exists, deleted");
       file.delete();
     }          
     skinFile = new RandomAccessFile(filename,"rw");
     // Write header
     skinFile.writeBytes("UME SKIN");          
     skinFile.writeByte(Main.MAJOR);
     skinFile.writeByte(Main.MINOR);
     skinFile.writeByte(Main.BUILD);
     // Write some padding bytes
     skinFile.writeByte(1); // file format version
     for (int i = 0; i < 12; i++)
       skinFile.writeByte(0); // padding
     
     // now reached position 0x0010
     // here the segment adresses will be filled later   
     skinFile.writeInt((int) segment_staticSpritesIndex);     // segment 1 static sprites index
     skinFile.writeInt((int) segment_staticSpritesIndex + 
                             MAX_STATIC_SPRITES * 8);         // segment 2 static sprites data
     for (int i = 0; i < 252; i++) {
       skinFile.writeInt(0); // offset
       skinFile.writeInt(0); // length
     }
     // now reached position 0x0400
     if (skinFile.getFilePointer() != 0x800) {
       System.out.println("FATAL INTERNAL ERROR in skin creation, file pointer mismatch (0x800 != 0x" + 
                          Integer.toHexString((int) skinFile.getFilePointer()) + ")");
       System.exit(1);
     }
     // start of segment 1 - offset values for static grafics
     for (int i = 0; i < MAX_STATIC_SPRITES; i++) {
       skinFile.writeInt(0);
       skinFile.writeInt(0);
     }
     
     writeStaticSprites();
     
     skinFile.writeBytes("EOF");
     
     // go back and fill in index values;
     skinFile.seek(segment_staticSpritesIndex);
     for (int i = 0; i < MAX_STATIC_SPRITES; i++) {
       skinFile.writeInt(staticSpritesOffset[i]);
       skinFile.writeInt(staticSpritesLength[i]);
     }     
     
     // close streams
     skinFile.close();
     progress.setVisible(false);
     
     // cleanup memory before game starts
     // since it's really messed up now ;)
     Runtime rt = Runtime.getRuntime();
     rt.gc();              // run garbage collector
     rt.runFinalization(); // free memory.                
   }
   
   private void writeStaticSprites() throws IOException
   {
     for (int i = 0; i < MAX_STATIC_SPRITES; i++) {
       if ((i & 0x0F) == 0) {
         System.out.print(".");
         System.out.flush();         
         progress.step();
       }         
       staticSpritesOffset[i] = (int) skinFile.getFilePointer();
       Sprite sprite = mulReader.readStaticSprite(i);
       ByteArrayOutputStream serializeBuffer = new ByteArrayOutputStream();
       ObjectOutputStream serializer = new ObjectOutputStream(serializeBuffer);
       //serializeBuffer.reset();
       serializer.writeObject((SpriteBase) sprite);
       byte[] data = serializeBuffer.toByteArray();
       staticSpritesLength[i] = data.length;       
       skinFile.write(data);
       
       // DEBUG
       //if (i == 1307) {
        //System.out.println("============");
        //System.out.println("Offset: " + staticSpritesOffset[i]);
        //System.out.println("Length: " + data.length);
        //System.out.println("Data: " + data.length);
        //for ( int j = 0; j < data.length; j++) {
        //  System.out.print(data[j] + " ");
        //}
        //System.out.println("============");
        /*
        try {
          ByteArrayInputStream buf2 = new ByteArrayInputStream(data);
          ObjectInputStream deserializer = new ObjectInputStream(buf2);
          sprite = (Sprite) deserializer.readObject();
        } catch (IOException e) {
          System.out.println("ERROR: IOException while reading skin :" + e.getMessage());
          System.exit(1);
        } catch (ClassNotFoundException e) {
          System.out.println("ERROR: Class not found in skin :" + e.getMessage());
          System.exit(1);
        }
        */
     }
   }
 }