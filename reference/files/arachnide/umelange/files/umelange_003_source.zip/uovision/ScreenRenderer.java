//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package uovision;

import java.util.*;
import java.awt.*;
import java.awt.image.*;

import map.*;
import skin.*;

import AnimSprite;
import CacheDemon;
import Sprite;

/**
 *
 * This class actually renders the game images(frames). 
 *
 *  <pre>
 *  Programmers compass rose:
 *  -------------------------------------------------
 *
 *  screen Y-Axis
 *
 *  A             
 *  |            
 *  |                         Up (u) 
 *  |                           A
 *  |                           |
 *  |           West (w)        |         North (n) 
 *  |                   �.   .--+--.   ,� 
 *  |                     �.�   |   `,� 
 *  |                     / �.  |  ,� \ 
 *  |                    |    �.|,�    |
 *  |    Left (l) <------+------X------+--------> Right (r)
 *  |                    |     ,|.     |
 *  |                     \  ,� | �.  / 
 *  |                      ,�   |   �.
 *  |                    ,�  �--+--�  �.
 *  |           South (s)       |       � East (e)
 *  |                           |
 *  |                           V
 *  |                       Down (d)
 *  |
 *  |
 *  +-------------------------------------------------------> screen X-Axis
 *
 *             I hope it also looks nicely on your screen ;)
 *
 *                     - knoxos
 * 
 */

public class ScreenRenderer implements ImageProducer {		        
/**
 * Line lengths of raw tiles.
 * knoxos: Oh i just se there are also in CacheDemon defined. Well the world is not big enough of both...
 */
 static final int map_tile_rowlen[]  = { 2, 4, 6, 8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,
                                        44,42,40,38,36,34,32,30,28,26,24,22,20,18,16,14,12,10, 8, 6, 4, 2};

/*
 * Line offsets of raw tiles.
 */
 static final int map_tile_offset[] = {21,20,19,18,17,16,15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,
                                        0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,20,21};
/**
 * Data offsets per line in a sprite of an unstretched raw tile.
 */
 static final int map_tile_data_offs[] = {  0,   2,   6,  12,  20,  30,  42,  56,  72,  90, 110, 132, 156, 182, 
                                          210, 240, 272, 306, 342, 380, 420, 462, 506, 550, 592, 632, 670, 706, 
                                          740, 772, 802, 830, 856, 880, 902, 922, 940, 956, 970, 982, 992, 
                                          1000, 1006, 1010}; 
                                          
 int max_clips = 10;

 ClipRect fullClip = new ClipRect(0, 0, screenWidth, screenHeight);

/**
 * The game window
 */
 GameWindow gameWindow;

/**
 * The color model used to create the images.
 */
 ColorModel model;
 
 //int[] pixels;

/**
 * Data buffer.
 */
 int[] foreGround;

/**
 * Data buffer.
 */
 int[] gameScreen;

/**
 * Linewidth of buffer until next line begins
 */
 int pixelscan;
 
/**
 * For ImageProducer...
 */
 Hashtable properties;

/**
 * For ImageProducer...
 */
 Vector theConsumers;

/**
 * For ImageProducer...
 */
 boolean animating;

/**
 * For ImageProducer...
 */
 boolean fullbuffers;

/**
 * The sprite for the fireball
 */
 //public AnimSprite whispSprite = null;

/**
 * Current scroller x shift.
 */
 private int scrollerX  = 0;

/**
 * Current scroller y shift.
 */
 private int scrollerY  = 0;  

 int relx = 0;
 int rely = 0;

/**
 * The data source.
 */   
 private CacheDemon cacheDemon;  

/**
 * The map maker creating the map sprite
 */   
 private MapMaker  mapMaker;
   
/**
 * Width of gaming screen
 */   
 static int screenWidth       = 640;
/**
 * Height of gaming screen
 */   
 static int screenHeight      = 480;
 
 Creature player;
 
 boolean full_frame  = true;
 
/**
 * Pool for the clipping rectangles, so that heap must not be pested for these
 */
 ClipRect[] clips = new ClipRect[max_clips];
 
/**
 * Player clip, last clipping of player.
 */
 ClipRect playerClip = new ClipRect(0, 0, 0, 0);
  
/***
 * Current drawing level
 * true  is drawing on game wrap-buffer
 * false is drawing on unwrapped screen buffer
 */
 boolean drawLevel = true;

 private boolean perf_lag = false;    // clear the screen between frames.
 
 static int screenSize        = (screenWidth)* (screenHeight);
 static int screenShiftX      = -15;
 static int screenShiftY      = 2;

 int offset     = 20 * screenWidth + 320;
  

 public ScreenRenderer(ColorModel colormodel,  
                       GameWindow gameWindow, 
                       CacheDemon cacheDemon, 
                       boolean    mapShowStatics) 
 {
   this.cacheDemon  = cacheDemon;
   this.gameWindow  = gameWindow;
   mapMaker         = new MapMaker(cacheDemon, mapShowStatics, gameWindow);
   theConsumers = new Vector();
   model = colormodel;
   pixelscan = screenWidth;
   properties = new Hashtable();
   gameScreen = new int[screenWidth * screenHeight];
   foreGround = new int[screenWidth * screenHeight];
   for (int i = 0; i < max_clips; i++) {
     clips[i] = new ClipRect(0, 0, 0, 0);
   }
   //whispSprite = cacheDemon.getRunSprite(14078, screenWidth);
   //whispSprite = cacheDemon.getRunSprite(14001, screenWidth);
   //whispSprite = cacheDemon.getAnimSprite(0x195B, 0);
   //whispSprite = cacheDemon.getAnimSprite(0x5F96, 0);
   System.out.println("Loading player creature ... ");
   player = new Creature(cacheDemon, 0x195A); // red dragon
   //player = new Creature(cacheDemon, 0x88B8); // man
   //player = new Creature(cacheDemon, 0x044c); // demon with sword
   System.out.println("OK");
 }

/**  
 *
 * Here the new image is calculated.
 *
 */
 public synchronized void newPixels()
 {
   /*
   if (clearScreen) {
     for (int i = 0; i < screenSize; i++)
     //foreGround[i] = 0x0000FF;        
     gameScreen[i] = 0xFFFFFF;        
   }
   */
   drawLevel = true;
  
   int currentX   = gameWindow.currentX;
   int currentY   = gameWindow.currentY;
   int clip_count = 0;
   if (full_frame) {
     clips[0].set(fullClip);
     clip_count = 1;
   } else {
     if (relx > 0) {
       clips[clip_count].set(0,0, relx, screenHeight);
       clip_count++;
     } else if (relx < 0) {
       clips[clip_count].set(screenWidth + relx , 0, screenWidth, screenHeight);
       clip_count++;
     }
   
     if (rely > 0) {
       clips[clip_count].set(0, 0, screenWidth, rely);
       clip_count++;
     } else if (rely < 0) {
       clips[clip_count].set(0, screenHeight + rely , screenWidth, screenHeight);
       clip_count++;
     }
   }
   
   // make player clip
   AnimSprite whispSprite;        
   switch (player.kind) {
     case Creature.WALK :
       if (player.dir > GameWindow.UP) {                        
         whispSprite = player.walk[4 - (player.dir - GameWindow.UP)][player.frame];
       } else {
         whispSprite = player.walk[player.dir][player.frame];
       }
       break;
     case Creature.STAND :
       if (player.dir > GameWindow.UP) {
         whispSprite = player.stand[4 - (player.dir - GameWindow.UP)];
       } else {
         whispSprite = player.stand[player.dir];
       }
       break;
     default :
       System.out.println("INTERNAL FATAL, invalid creature animation kind");
       whispSprite = null;
       break;                   
   }

   MapBlock cBlock = cacheDemon.getMapBlockOfRawTile(currentX,currentY,true);
   MapCell cCell = cBlock.cells[currentX % 8][currentY % 8];   
   int cheight = cCell.hl < cCell.hr ? cCell.hr : cCell.hl;
   int player_x =  - (screenShiftX - screenShiftY)*22 - 66 - whispSprite.centX;
   int player_y =  - (screenShiftX + screenShiftY)*22 - 88 - whispSprite.height - whispSprite.centY + (cheight >> 1);

   int absx = Math.abs(relx) + 2;
   int absy = Math.abs(rely) + 2;
   if (!full_frame) 
     clips[clip_count].set(playerClip); // set last player clip
   playerClip.set(player_x - absx, player_y - absy, player_x + whispSprite.width + absx, player_y + whispSprite.height + absy);
   if (!full_frame) 
     clip_count++;
   
   //clips[0].set(screenWidth / 2 - 10, 0, screenWidth / 2 + 10, screenHeight);
   //clips[1].set(screenWidth / 2, screenHeight / 2, screenWidth - 10, screenHeight - 10);
   //clip_count = 1;
   if (clip_count > 0) {
     int currentZ = cCell.zpos;
     int hshift = -currentZ / 44;
     int orgX = (currentX - currentY) * 22 + scrollerX + (screenShiftX - screenShiftY)*22 + 88;
     int orgY = (currentX + currentY) * 22 + scrollerY + (screenShiftX + screenShiftY)*22 + 88;
   
     int xTiles = screenWidth  / 44 +  5;
     int yTiles = screenHeight / 44 + 11 + hshift;
   
     for (int y = hshift - 2; y < yTiles; y++) {
       for (int odd = 0; odd <=1; odd++) { 
         int tileX = currentX + y + odd + screenShiftX;
         int tileY = currentY + y + screenShiftY;
         for (int x = 0; x < xTiles; x++) {    	
           int screenX = (tileX - tileY) * 22 - orgX;
           int screenY = (tileX + tileY) * 22 - orgY + currentZ;
           if ((tileX >= 0) && (tileY >= 0) && (tileX < 768*8)  && (tileY < 512*8)) {
             MapCell cell = cacheDemon.getMapCell(tileX, tileY, true);              
            
             int len = cell.hl < cell.hr ? cell.hr : cell.hl;
             if ((screenX < screenWidth) && 
                 (screenX > -44) &&
                 (screenY + len - cell.zpos > 0) && 
                 (screenY - cell.zpos < screenHeight)) {
               if ((cell.hr == 44) && (cell.hl == 44) && (cell.stl == 22) && (cell.str == 22)) {
                 MapTile tile = cacheDemon.getMapTile(cell.id);
                 for (int i = 0; i < clip_count; i++) {
                   if (clips[i].intersect(screenX,  screenY - cell.zpos, 44, 44)) {
                     drawMapTile(screenX,  screenY - cell.zpos, tile, clips[i]);
                   }
                 }               
               } else {
                 Sprite sprite = cacheDemon.getMapSprite(cell);
                 if (sprite != null) {
                   for (int i = 0; i < clip_count; i++) {
                     if (clips[i].intersect(screenX,  screenY - cell.zpos, sprite.width, sprite.height)) {
                       drawSprite(screenX,  screenY - cell.zpos , sprite, clips[i]);
                     }
                   }
                 }
               }
             } 
             StaticCell sCell = cacheDemon.getStaticCell(tileX, tileY);
             for (int j = 0; j < sCell.tiles.length; j++) {
               StaticParticle sp = sCell.tiles[j];
               if (sp.sprite == null) {
                 sp.sprite = cacheDemon.getStaticSprite(sp.id);
               }
               if (sp.sprite != null) {
                 int spx = screenX - sp.sprite.width / 2 + 22;
                 int spy = screenY - (sp.z << 2) - sp.sprite.height + 44;
                 for (int i = 0; i < clip_count; i++) {
                   if (clips[i].intersect(spx,  spy, sp.sprite.width, sp.sprite.height)) {
                     drawSprite(spx, spy , sp.sprite, clips[i]);
                   }
                 }               
               }
             }
             if ((tileX == currentX) && (tileY == currentY)) {
               //cell = cacheDemon.getMapCell(tileX, tileY , true);
               //int cheight = cell.hl < cell.hr ? cell.hr : cell.hl;
               if (player.dir > GameWindow.UP) {
                 //drawSprite_flipHorz(screenX - whispSprite.centX + 22 + scrollerX, screenY + scrollerY - whispSprite.height - whispSprite.centY - cell.zpos + (cheight >> 1), whispSprite);
                 drawSprite_flipHorz(player_x, player_y, whispSprite);
                 //drawSprite(player_x, player_y, whispSprite, fullClip);
               } else {
                 drawSprite(player_x, player_y, whispSprite, fullClip);
               }
             }              
           } //else {
             //eraseRawTile(screenX, screenY , 0);	
           //}
           tileX++; // move to right        
           tileY--; 
         }
       }
     }
   }
   full_frame = false;
   // make unwrapped screen
   System.arraycopy(gameScreen, offset, foreGround, 0, screenSize - offset);
   System.arraycopy(gameScreen, 0, foreGround, screenSize - offset, offset);      
   drawLevel = false;
   drawSprite(10,10, gameWindow.mapSprite, fullClip);
   Sprite mapSprite = mapMaker.loadMap(currentX, currentY);
   drawSprite(21,21, mapSprite, fullClip);
   /*
   if (perf_lag) { // draw pefromance lag sprite
     Sprite perfLag = gameWindow.perfLagSprite;
     drawSprite(screenWidth - perfLag.width - 10, 10, perfLag, fullClip);
   }
   */
   mapMaker.releaseSprite();
   newPixels(0, 0, screenWidth, screenHeight, true);
 }
  
/**
 *
 * Draws a sprite into the buffer.
 *
 * @param x       The x position for sprite
 * @param y       The y position for sprite
 * @param sprite  The sprite to draw.
 */   
 protected void drawSprite(int x, int y, Sprite sprite, ClipRect clip) 
 {
   // insert a sprite
   int data[] = sprite.data;
   int run[]  = sprite.run;
   boolean level = false;
   int bpos = 0;
   int ypos = y * screenWidth;
   int xpos = x;
   int runby;    
   int istart = 0;
   runby = run[0];
   int runpos = 1;
   if (runby == 0) {
     level = true;
     runby = run[runpos++];
     istart++;
   }
   int rlen = sprite.rlen;
   for(int i = istart; i < rlen; i++) {
     if (!level) {
       if (runby <= 0) { // next line
         runby = -runby;
         ypos += screenWidth;
         y++;
         xpos = x + runby;
       } else {
         xpos += runby;
       }
       level = true;
     } else {    
       if (runby == 0) {
         level = false;
         runby = run[runpos++];
         continue;  	
       }
       if (runby <= 0) {
         System.out.println("ERROR, wrong sprite info!");
       } 
       if (y < clip.up) { // clipped upward
         bpos += runby;
         xpos += runby;
         level = false;
         runby = run[runpos++];
         continue;
       }
       if (y >= clip.down)                        // clipped downward
         return;
       if (xpos + runby >= clip.right) {          // clipped right
         int xlen = clip.right - xpos; 
         if (xlen > 0) {
           if (xlen > (clip.right - clip.left)) { // clipped left and right
             int dlen  = clip.right - clip.left;             
             int doffs = clip.left - xpos;
             putPixels(data, bpos + doffs, ypos + clip.left, dlen);         
           } else {
             putPixels(data, bpos, ypos + xpos, xlen);         
           }
         }
         bpos += runby;
         xpos += runby;
         level = false;
         runby = run[runpos++];
         continue;
       }
       if (xpos < clip.left) {                    // clipped left only 
         int xleft = clip.left - xpos;
         int xlen  = runby - xleft; 
         if (xlen > 0) {
           //if ((xpos + runby) > clip.right) {
           //  xlen -= (xpos + runby) - clip.right;
           //} 
           putPixels(data, bpos + xleft, ypos + clip.left, xlen);         
         }
         bpos += runby;
         xpos += runby;
         level = false;
         runby = run[runpos++];
         continue;  
       }
       putPixels(data, bpos, ypos + xpos, runby);         
       xpos += runby;
       bpos += runby;
       level = false;
     }      
     runby = run[runpos++];
   } 
 }

/**
 *
 * Draws a sprite into the buffer.
 * But flipped horizontal 
 *
 * @param x       The x position for sprite
 * @param y       The y position for sprite
 * @param sprite  The sprite to draw.
 */   
 protected void drawSprite_flipHorz(int x, int y, Sprite sprite) 
 {
   // insert a sprite
   int data[] = sprite.data;
   int run[]  = sprite.run;
   boolean level = false;
   int bpos = 0;
   int width = sprite.width;
   int ypos = y * screenWidth;
   int xpos = x + width;
   int runby;    
   int istart = 0;
   runby = run[0];
   int runpos = 1;
   if (runby == 0) {
     level = true;
     runby = run[runpos++];
     istart++;
   }
   int rlen = sprite.rlen;
   for(int i = istart; i < rlen; i++) {
     if (!level) {
       if (runby <= 0) { // next line
         runby = -runby;
         ypos += screenWidth;
         y++;
         xpos = x + width - runby;
       } else {
         xpos -= runby;
       }
       level = true;
     } else {    
       if (runby == 0) {
         level = false;
         runby = run[runpos++];
         continue;  	
       }
       if (runby <= 0) {
         System.out.println("ERROR, wrong sprite info!");
       } 
       if (y < 0) {
         bpos += runby;
         xpos -= runby;
         level = false;
         runby = run[runpos++];
         continue;
       }
       if (y >= screenHeight)
         return;
       if (xpos >= screenWidth) {
         /*int xlen = screenWidth - xpos; 
         if (xlen > 0)
           putPixels(data, bpos, ypos + xpos, xlen);         
         */
         bpos += runby;
         xpos -= runby;
         level = false;
         runby = run[runpos++];       
        continue;
       }
       if ((xpos - runby) < 0) {
         //int xlen = runby + xpos; 
         //if (xlen > 0)
         //  putPixels(data, bpos - xpos, ypos, xlen);         
         bpos += runby;
         xpos -= runby;
         level = false;
         runby = run[runpos++];
         continue;  
       }
       // can't do normal put pixels since data also has to be flipped
       // putPixels(data, bpos, ypos + xpos - runby, runby);
       // 
       bpos += runby;
       int datpos = offset + ypos + xpos - runby;
       while (datpos < 0)
         datpos += screenSize;
       while (datpos >= screenSize)
         datpos -= screenSize;
       for (int p = 0; p < runby; p++) {
         //if ((datpos < 0) || (datpos >= screenSize))
         //  continue;
         gameScreen[datpos] = data[bpos--];
         if (++datpos == screenSize)
           datpos = 0;
         //if (++datpos == screenWidth) {
         //  datpos = 0;
         //}
       }
       xpos -= runby;
       bpos += runby;
       level = false;
     }      
     runby = run[runpos++];
   } 
 }



 /**
  *
  * Should erase a tile, if it is not drawn.
  * The emptiness of this function, is the reason for the edges of the world to be wrong. (not cleared)
  *
  */
  public void eraseRawTile (int x, int y, int color) 
  {    
  }

 /**
  *
  * Draws an unstretched, untilted map tile on screen. <br>
  * width         = 44 <br>
  * height        = 44 <br>
  * stretch left  = 22 <br>
  * stretch right = 22 <br>
  *
  * @param x     The x position for the raw tile.
  * @param y     The y position for the raw tile.
  * @param tile  The rawtile data.
  *
  * (Stretched tiles are drawn using the drawSprite function)
  */
  public void drawMapTile (int x, int y, MapTile tile, ClipRect clip) 
  {  
    int orgx = x;
    int orgy = y;        
       
    // erase if no tile
    if (tile==null)  {
      eraseRawTile(x,y,0);
      return;
    }
    int pos     = y * screenWidth + x + 22;
    int data[]  = tile.data;
    int datapos = 0;
    int ylimit;
    if (y + 44 >= clip.down)
      ylimit = clip.down - y;
    else
      ylimit = 44; // no border
    if (y <= clip.up - 44)                 
      return;
    boolean xborder = false;
    if (x + 44 >= clip.right) {
      xborder = true;
      //return;
    }
    int starty = 0;
    if (y < clip.up) {
      starty = clip.up - y;
      if (starty < 22) {
        x -= starty;
      } else {
        x += starty - 44;             
      }
      datapos += map_tile_data_offs[starty];
      y = clip.up;
    }
    x += 22;    
    int yp = y * screenWidth;
   
    for (int iy = starty; iy < ylimit; iy++) {            
      int len = map_tile_rowlen[iy];
      int xlen = x + len;
      if (x < clip.left) {
        int llen = len - (clip.left - x);
        if (llen > 0) {
          if ((xlen) > clip.right) {
            int rlen = llen - (xlen - clip.right);
            putPixels(data, datapos + len - llen, yp + clip.left, rlen);
          } else {
            putPixels(data, datapos + len - llen, yp + clip.left, llen);
          }
        }
      } else {
        if (xborder) {
          int rlen = len;
          if ((xlen) > clip.right )
            rlen = clip.right - x;
          if (rlen > 0) {
            putPixels(data, datapos, yp + x, rlen);
          }
        } else {
          putPixels(data, datapos, yp + x, len);
        }
      }
      datapos += len;
      if (iy <22) {
        x--; 
      } else {
        x++; 
      }
      yp += screenWidth;
    }
  }
        
 /**
  *
  * Scrolls the window.
  *
  * @param scrollX   sroll to right (positive) or left (negative)
  * @param scrollY   sroll up (positive) or down (negative)
  *
  */       
  public void scroll(int scrollX, int scrollY) 
  {
    //offset += scrollX + scrollY*screenWidth;
    
    
    //scrollerX += scrollX;
    //scrollerY += scrollY;
    relx = scrollerX - scrollX;
    rely = scrollerY - scrollY;    

    offset -= relx;
    offset -= rely * screenWidth;
    
    while (offset >= screenSize) {
      offset -= screenSize;   
    }
    while (offset < 0) {
      offset += screenSize;   
    }
          
    scrollerX = scrollX;
    scrollerY = scrollY;
        
    // scroll to right
    //while (scrollerX >= 44) {
       //if (gameWindow.currentX < 768*8 - 1)
       //  gameWindow.currentX++;   
       //if (gameWindow.currentY > 0)
       //  gameWindow.currentY--;   
       //scrollerX -= 44;
    //}
    //while (scrollerX <= -44) {
      //if (gameWindow.currentX > 0)
      //  gameWindow.currentX--;
      //if (gameWindow.currentY < 512 * 8 - 1)
      //  gameWindow.currentY++;
      //scrollerX += 44;
    //}
    //while (scrollerY >= 44) {
      //if (gameWindow.currentX < 768 * 8 - 1)
      //  gameWindow.currentX++;
      //if (gameWindow.currentY < 512 * 8 - 1)
      //  gameWindow.currentY++;
      //scrollerY -= 44;;
    //}
    //while (scrollerY <= -44) {
      //if (gameWindow.currentX > 0)
      //  gameWindow.currentX--;
      //if (gameWindow.currentY > 0)
      //  gameWindow.currentY--;
      //scrollerY += 44;;      
    //}
    //*/
  }  

  public synchronized void setPos(int walkx, int walky) {
    full_frame = true;
    /*
    int relx = scrollerX - walkx;
    int rely = scrollerY - walky;
    
    offset -= relx;
    offset -= rely * screenWidth;
        
    while (offset >= screenSize) {
      offset -= screenSize;   
    }
    while (offset < 0) {
      offset += screenSize;   
    }
    */

    scrollerX = 0;
    scrollerY = 0;        
  }



  public void putPixels(int[] data, int dpos, int offs, int len) {
    if (drawLevel) {
      // if drawing on wrapped game buffer
      int sumoffset = offset + offs;
      if (sumoffset + len >= screenSize) {
        // copy on buffer border
        if (sumoffset >= screenSize) {
          // it is all above the buffer
          System.arraycopy(data, dpos, gameScreen, sumoffset - screenSize, len);
        } else {
          // it's a real split
          System.arraycopy(data, dpos, gameScreen, sumoffset, screenSize - sumoffset);        
          System.arraycopy(data, dpos, gameScreen, 0, len - (screenSize - sumoffset));        
        }
      } else {
        // normal copy
        //try {
          System.arraycopy(data, dpos, gameScreen, sumoffset , len);       
          /*
        } catch (Exception e) {
          System.out.println("EXCEPTION!");
          System.out.println("dlen    : " + data.length);
          System.out.println("dpos    : " + dpos);
          System.out.println("slen    : " + gameScreen.length);
          System.out.println("spos    : " + sumoffset);
          System.out.println("len     : " + len);
        }
        */
      }
    } else {
      // if drawing on non-wrapped screen buffer   
      System.arraycopy(data, dpos, foreGround, offs, len);       
    }
  }
  
  public synchronized void resize(int w, int h) 
  {
     screenWidth  = w;
     screenHeight = h;
     screenSize   = w * h;
     foreGround = new int[screenSize];
     gameScreen = new int[screenSize];
     fullClip.right = w;
     fullClip.down = h;
     full_frame = true;

     // tell the consumer of the resize
     for (int i = 0; i < theConsumers.size(); i++) {
       ImageConsumer consumer = (ImageConsumer ) theConsumers.elementAt(i);
       //consumer.setDimensions(w,h);
       initConsumer(consumer);
     }
     offset = 0; // reset offset wrapping
     int shift_horz = w / 44; // 640 / 44 = 14.5
     int shift_vert = h / 44; // 480 / 44 = 10.9
     
     //               14 + 10
     // screenShifX = ------- = 12
     //                  2
      
     //                14 - 10
     // screenShiftY = ------- = 2
     //                   2
     
     screenShiftX  = -shift_horz;
     screenShiftY  = (shift_horz - shift_vert) / 2;
     //System.out.println("Center shifting, x: " + screenShiftX + "Center shifting, y: " + screenShiftY);
  }
        
        
  public synchronized void setPlayer(int kind, int dir, int frame) {
    player.kind  = kind;
    player.dir   = dir;
    player.frame = frame;
  }

  public synchronized void setPerformanceLag(boolean perf_lag) {
    this.perf_lag = perf_lag;
  }

        
// +================================================================+
// |                                                                |
// |  ImageProducer standards                                       |
// |                                                                |
// +================================================================+

/**
 *
 * Send a rectangular region of the buffer of pixels to any
 * ImageConsumers that are currently interested in the data for
 * this image.
 *
 * From ImageProducer... 
 *
 * If the framenotify parameter is true then the consumers are
 * also notified that an animation frame is complete.
 * This method only has effect if the animation flag has been
 * turned on through the setAnimated() method.
 * If the full buffer update flag was turned on with the
 * setFullBufferUpdates() method then the rectangle parameters
 * will be ignored and the entire buffer will always be sent.
 *
 * @param x the x coordinate of the upper left corner of the rectangle
 * of pixels to be sent
 *
 * @param y the y coordinate of the upper left corner of the rectangle
 * of pixels to be sent
 *
 * @param w the width of the rectangle of pixels to be sent
 * @param h the height of the rectangle of pixels to be sent
 * @param framenotify true if the consumers should be sent a
 * SINGLEFRAMEDONE notification
 *
 */
 public synchronized void newPixels(int i, int j, int k, int l, boolean flag)
 {
   if (animating) {
     if(fullbuffers) {
       i = j = 0;
       k = screenWidth;
       l = screenHeight;
     } else {
       if (i < 0) {
         k += i;
         i = 0;
       }
       if(i + k > screenWidth)
         k = screenWidth - i;
       if(j < 0) {
         l += j;
         j = 0;
       }
       if(j + l > screenHeight)
         l = screenHeight - j;
     }
     if((k <= 0 || l <= 0) && !flag)
       return;
     for(Enumeration enumeration = theConsumers.elements(); enumeration.hasMoreElements();) {
       ImageConsumer imageconsumer = (ImageConsumer)enumeration.nextElement();
       if(k > 0 && l > 0)
         sendPixels(imageconsumer, i, j, k, l);
       if(flag && isConsumer(imageconsumer))
         imageconsumer.imageComplete(2);
     }
   }
 }


/**
 * Adds an ImageConsumer to the list of consumers interested in
 * data for this image.
 */
 public synchronized void addConsumer(ImageConsumer ic) 
 {
   if (theConsumers.contains(ic)) 
     return;
   theConsumers.addElement(ic);
   try {
     initConsumer(ic);
     sendPixels(ic, 0, 0, screenWidth, screenHeight);
     if (isConsumer(ic)) {
       ic.imageComplete(animating? ImageConsumer.SINGLEFRAMEDONE
				 : ImageConsumer.STATICIMAGEDONE);
       if (!animating && isConsumer(ic)) {
	 ic.imageComplete(ImageConsumer.IMAGEERROR);
	 removeConsumer(ic);
       }
     }
   } catch (Exception e) {
     if (isConsumer(ic)) 
       ic.imageComplete(ImageConsumer.IMAGEERROR);
   }
 }
 
 private void initConsumer(ImageConsumer imageconsumer) 
 {
   // knoxos: don't ask me why this is done so strange...
   //         I asume the consumer can cancel it's membership at any point.    
   if(isConsumer(imageconsumer))
     imageconsumer.setDimensions(screenWidth, screenHeight);
   if(isConsumer(imageconsumer))
     imageconsumer.setProperties(properties);
   if(isConsumer(imageconsumer))
     imageconsumer.setColorModel(model);
   if(isConsumer(imageconsumer))
     imageconsumer.setHints(animating ? 
          (fullbuffers ? (ImageConsumer.TOPDOWNLEFTRIGHT | ImageConsumer.COMPLETESCANLINES) : ImageConsumer.RANDOMPIXELORDER) : 
          (ImageConsumer.TOPDOWNLEFTRIGHT | ImageConsumer.COMPLETESCANLINES | ImageConsumer.SINGLEPASS | ImageConsumer.SINGLEFRAME));
 }

 public synchronized boolean isConsumer(ImageConsumer imageconsumer)
 {
   return theConsumers.contains(imageconsumer);
 }
 
/***
 *
 * Change this memory image into a multi-frame animation or a
 * single-frame static image depending on the animated parameter.
 * <p>This method should be called immediately after the
 * MemoryImageSource is constructed and before an image is
 * created with it to ensure that all ImageConsumers will
 * receive the correct multi-frame data.  If an ImageConsumer
 * is added to this ImageProducer before this flag is set then
 * that ImageConsumer will see only a snapshot of the pixel
 * data that was available when it connected.
 *
 * @param animated true if the image is a multi-frame animation
 *
 ***/
  public synchronized void setAnimated(boolean animated) {
    this.animating = animated;
    if (!animating) {
      Enumeration enum = theConsumers.elements();
      while (enum.hasMoreElements()) {
	ImageConsumer ic = (ImageConsumer) enum.nextElement();
	ic.imageComplete(ImageConsumer.STATICIMAGEDONE);
	if (isConsumer(ic)) {
          ic.imageComplete(ImageConsumer.IMAGEERROR);
        }
      }
      theConsumers.removeAllElements();
    }
  }

  public synchronized void setFullBufferUpdates(boolean flag)
  {
    if(fullbuffers == flag)
      return;
    fullbuffers = flag;
    if(animating) {
      ImageConsumer imageconsumer;
      for(Enumeration enumeration = theConsumers.elements(); enumeration.hasMoreElements(); imageconsumer.setHints(flag ? 6 : 1))
        imageconsumer = (ImageConsumer)enumeration.nextElement();
    }
  }

  public void startProduction(ImageConsumer imageconsumer)
  {
    addConsumer(imageconsumer);
  }
  
 public synchronized void removeConsumer(ImageConsumer imageconsumer)
 {
   theConsumers.removeElement(imageconsumer);
 }

 public void requestTopDownLeftRightResend(ImageConsumer imageconsumer)
 {
   // nothing
 }

 private void sendPixels(ImageConsumer imageconsumer, int x, int y, int w, int h)
 {
   imageconsumer.setPixels(x, y, w, h, model, foreGround, 0, screenWidth);    
 }
  
}

