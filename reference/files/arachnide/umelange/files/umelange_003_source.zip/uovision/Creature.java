//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package uovision;

import AnimSprite;
import CacheDemon;

/**
 *
 *
 */
class Creature { 
  public static final int WALK  = 0;
  public static final int STAND = 1;
  AnimSprite[]   stand;  
  AnimSprite[][] walk;    

  int kind  = 0;
  int dir   = 0;
  int frame = 0;
  
  Creature(CacheDemon cacheDemon, int id) 
  {
    stand = new AnimSprite[5];
    walk  = new AnimSprite[5][10];
    for (int i = 0; i < 5; i++) {
      for (int f = 0; f < 10; f++) {
        walk[i][f] = cacheDemon.getAnimSprite(id, f);
      }
      id++;
    }        
    for (int i = 0; i < 5; i++) {
      stand[i] = cacheDemon.getAnimSprite(id++, 0);
    }
  }
}
