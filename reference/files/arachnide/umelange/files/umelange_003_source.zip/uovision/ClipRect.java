//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package uovision;

import AnimSprite;
import CacheDemon;

/**
 *
 *
 */
class ClipRect { 
  int left;
  int right;
  
  int up;
  int down;
  
  
  ClipRect(int s_left, int s_up, int s_right, int s_down) 
  {
     left  = s_left;
     right = s_right;
     up    = s_up;
     down  = s_down;
  }
  
  void set(int s_left, int s_up, int s_right, int s_down) 
  {
     left  = s_left;
     right = s_right;
     up    = s_up;
     down  = s_down;
  }

  void set(ClipRect rect) 
  {
     left  = rect.left;
     right = rect.right;
     up    = rect.up;
     down  = rect.down;
  }

  boolean intersect(int x, int y, int w, int h) {
    int rdown  = y + h;
    int rright = x + w;
    if (x > right)
      return false;
    if (y > down)
      return false;
    if (rdown < up)
      return false;    
    if (rright < left)
      return false;    
    // ok here it is a real intersect   
    return true;
  }  
}
