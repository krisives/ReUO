//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package uovision;

import java.util.*;
import java.awt.*;
import java.awt.image.*;
import java.math.*;

import map.*;

import CacheDemon;
import Sprite;

/**
 * Renderes the map view used by MapWindow.
 *
 * This is accomplished by a ring buffer, with wrap around, to improve pefromance. <br>
 * There is somwhat missing on the algorithm, since one line gets not drawed. The
 * one in which wrap arround occurs. But for now nobody will notice it ;) 
 *
 */
 
class MapMaker extends Thread {
 /**
  * The colormodel used to create image.        
  */ 
  ColorModel model;
 
 /**
  * Buffer where map data is held.
  */
  int[] pixels;
   
 /**
  * Buffer where map data is held.
  */
  int[] screen1;
  int[] screen2;

 /**
  * Width of a line in pixel data until next line information starts
  */
  int pixelscan;
 
  private CacheDemon  cacheDemon;  
  private GameWindow  gameWindow;
 
  private int radarColors[];
 
 /**
  * Last x position where map is drawed, 
  * used to calculate which differences have to be drawn.
  */
  private int oldx = 0;

 /**
  * Last y position where map is drawed, 
  * used to calculate which differences have to be drawn.
  */
  private int oldy = 0;

 /**
  * Defines if this is the very first call to map renderer.
  */
  private boolean first = true;

 /**
  * Current position in ring buffer
  */  
  private int offset = 0;

 /**
  * Width of the rendered screen.
  */  
  static final int screenWidth       = 193;

 /**
  * Height of the rendered screen.
  */  
  static final int screenHeight      = 174;

 /**
  * Height of the rendered screen.
  */  
  static final int screenSize        = screenWidth * screenHeight;
  
 /**
  * position of the center "cross"
  */
  static final int center1           = screenWidth / 2 + (screenHeight / 2) * screenWidth;
  static final int center2           = center1 + 1;
  static final int center3           = center1 - 1;
  static final int center4           = center1 + screenWidth;
  static final int center5           = center1 - screenWidth;
   
   
 /**
  * shall static Tiles been shown?
  */
  public boolean showStatics;
   
  int curx = 0;
  int cury = 0;
  boolean running = false;
  
 /**
  * The screen sprite
  */  
  Sprite curSprite    = null;
  Sprite calcSprite   = null;
  Sprite sprite1      = null;
  Sprite sprite2      = null;
  Sprite mapCalcSprite;
  
 /**  
  * Holds info which sprite is used for what
  * true:  sprite1 == curSprite
  *        sprite2 == calcSprite
  *
  * false: sprite1 == calcSprite
  *        sprite2 == curSprite  
  */
  boolean whichSprite = true;

 /**
  * If sprite is currently used, this variable is set to true
  * So sprite switching will not be allowed until it is released 
  * again
  */
  boolean spriteUsed = false;

  boolean showCalcSprite = true;

 /**
  * Constructor
  *
  * @param colormodel     Color model to use.
  * @param cacheDemon  Source for the data.
  */
  public MapMaker(CacheDemon cacheDemon, boolean showStatics, GameWindow gameWindow) 
  {
   super("MapMaker");
   this.cacheDemon  = cacheDemon;
   this.showStatics = showStatics;
   radarColors = cacheDemon.getRadarColors();
   pixels = new int[screenSize];
   screen1 = new int[screenSize];
   screen2 = new int[screenSize];
   sprite1 = new Sprite();
   mapCalcSprite = gameWindow.mapCalcSprite;
   sprite2 = new Sprite();

   curSprite  = sprite1;
   calcSprite = sprite2;
   sprite1.run = new int[screenHeight * 2];
   sprite2.run = new int[screenHeight * 2];
   // make a boring square sprite
   int rpos = 0;
   for (int i = 0; i < screenHeight; i++) {
     sprite1.run[rpos] = 0;     
     sprite2.run[rpos++] = 0;     
     sprite1.run[rpos] = screenWidth;
     sprite2.run[rpos++] = screenWidth;
   }
   sprite1.rlen = rpos - 1;
   sprite1.data = screen1;
   sprite2.rlen = rpos - 1;
   sprite2.data = screen2;
   model = new DirectColorModel(32,0xFF0000,0x00FF00,0x0000FF);
   setPriority(Thread.NORM_PRIORITY - 1);
  }

/**
 * 
 * Renderers new map image.
 *
 * @param curx    new x center.
 * @param cury    new y center.
 *
 */
 public synchronized Sprite loadMap(int curx , int cury)
 { 
   spriteUsed = true;
   if (running) {
     if (showCalcSprite)
       return mapCalcSprite;
     else
       return curSprite;
   }
   this.curx = curx;
   this.cury = cury;
   running = true;      
   if (!isAlive()) {
     start();
   } else {
     interrupt();    
   }
   if (showCalcSprite)
     return mapCalcSprite;
   else
     return curSprite;
 }    

 public void releaseSprite()
 { 
    spriteUsed = false;
 }

 private synchronized void switchSprites() 
 {
   boolean collision = false;
   try { // wait for sprite to be released
     while (spriteUsed) {
       System.out.println("Map sprite access collision ... delay"); 
       collision = true;
       Thread.sleep(100);
     }
   } catch (InterruptedException e) {
     // nothing
   }
   if (collision)
     System.out.println("Collision unraveled"); 
   showCalcSprite = false;     
   if (whichSprite) {
     calcSprite = sprite1;    
     curSprite  = sprite2;    
     whichSprite = false;
   } else {
     calcSprite = sprite2;    
     curSprite  = sprite1;    
     whichSprite = true;        
   }
 }
        
 public void run() 
 {
   for(;;) {
     try {
       while (!running) {
         sleep(100);
       }
     } catch (InterruptedException e) {
       // nothing
     }
     //System.out.println("MAP MAKING");
     int curx = this.curx;
     int cury = this.cury;
     int newx = + curx + cury;       // knoxos: I don't count on correctness of this eq's, they are
     int newy = - curx + cury;       //         more guessed than calculated.
     int dely = (newx - oldx);  //         > however it seems to do right now
     int delx = (- newy + oldy);
     //dely = (dely >> 1) + (dely & 0x01);
     //delx = (delx >> 1) + (delx & 0x01);
     dely = (dely / 2);
     delx = (delx / 2);
     if ((delx == 0) && (dely == 0)) {
  //     return sprite; 
       running = false;   
       //System.out.println("Nothing to do");
       continue;     
     }
       
     if (!first)
       offset += (delx) + (dely) * screenWidth;
     while (offset < 0)
       offset += screenSize;
     while (offset > screenSize)
       offset -= screenSize;
   
     int xstart;
     int xend;
     if (first || (Math.abs(delx) > (screenWidth / 4))) {
       xstart = 0;
       xend = screenWidth;    
       System.out.println("game : map teleport detected (x)");
     } else {   
       if (delx > 0) {
         xstart = screenWidth - delx;
         xend   = screenWidth;
       } else {
         xstart = 0;
         xend   = - delx;
       }     
     }
     int i = offset + xstart;
     int xlinefeed = screenWidth - (xend - xstart);
   
     for (int y = 0; y < screenHeight; y++, i+=xlinefeed) {
       for (int x = xstart; x < xend; x++, i++) {
         while (i >= screenSize)
           i -= screenSize;
         int px = x - screenWidth / 2;
         int py = y - screenHeight / 2 ; 
         int mapx = curx + px + py;
         int mapy = cury - px + py;
       
         if ((mapx > 0) && (mapx < 768 * 8) && (mapy > 0) && (mapy < 512 * 8)) {
           MapCell    mCell = cacheDemon.getMapCell(mapx, mapy, false);
           StaticCell sCell = cacheDemon.getStaticCell(mapx, mapy);
           if (showStatics) {
             if (sCell.tiles.length == 0) {
               pixels[i] = radarColors[mCell.id];
             } else {
               pixels[i] = radarColors[0x4000 + sCell.tiles[sCell.tiles.length - 1].id];
             }         
           } else {
             pixels[i] = radarColors[mCell.id];
           }
         } else {
           pixels[i] = 0x0000FF;
         }
       }
     }  

     int ystart;
     int yend;
     if (first || (Math.abs(dely) > (screenHeight / 4))) {
       ystart = 0;
       yend = screenHeight;    
       System.out.println("game : map teleport detected (y)");
     } else {   
       if (dely > 0) {
         ystart = screenHeight - dely;
         yend   = screenHeight;
       } else {
         ystart = 0;
         yend   = - dely;
       }     
     }
     i = offset + ystart * screenWidth;
   
     //for (int y = ystart; y < yend; y++, i+=xlinefeed) {
     for (int y = ystart; y < yend; y++) {
       for (int x = 0; x < screenWidth; x++, i++) {
         while (i >= screenSize)         
           i -= screenSize;
         int px = x - screenWidth / 2;
         int py = y - screenHeight / 2 ; 
         int mapx = curx + px + py;
         int mapy = cury - px + py;
       
         if ((mapx > 0) && (mapx < 768 * 8) && (mapy > 0) && (mapy < 512 * 8)) {
           MapCell    mCell = cacheDemon.getMapCell(mapx, mapy, false);
           StaticCell sCell = cacheDemon.getStaticCell(mapx, mapy);
           if (showStatics) {
             if (sCell.tiles.length == 0) {
               pixels[i] = radarColors[mCell.id];
             } else {
               pixels[i] = radarColors[0x4000 + sCell.tiles[sCell.tiles.length - 1].id];
             }         
           } else {
             pixels[i] = radarColors[mCell.id];
           }
         } else {
           pixels[i] = 0x000000;
         }
       }
     }  
    
     // make unwrapped screen
     if (whichSprite) {
       System.arraycopy(pixels, offset, screen2, 0, screenSize - offset);
       System.arraycopy(pixels,      0, screen2, screenSize - offset, offset);      
       screen2[center1]    = 0x44FF44;
       screen2[center2]    = 0x22AA22;
       screen2[center3]    = 0x22AA22;   
       screen2[center4]    = 0x22AA22;
       screen2[center5]    = 0x22AA22;
     } else {
       System.arraycopy(pixels, offset, screen1, 0, screenSize - offset);
       System.arraycopy(pixels,      0, screen1, screenSize - offset, offset);      
       screen1[center1]    = 0x44FF44;
       screen1[center2]    = 0x22AA22;
       screen1[center3]    = 0x22AA22;   
       screen1[center4]    = 0x22AA22;
       screen1[center5]    = 0x22AA22;
     }
        
     oldx = newx;
     oldy = newy;
     first = false;
     //return sprite;
     switchSprites();
     running = false;   
     //System.out.println("Finished");
   }
 }        
 
}

