//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package uovision;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.*;

import map.*;

import CacheDemon;
import Main;
import Sprite;


/**
 *
 * This is the window in which game plays. <br>
 * Currently it has only one component: GamePanel, but this may extend. In this version
 * Mouse and keyboard capturing occurs here, and also the graphics are managaged by the 
 * window.
 *
 */


public class GameWindow extends Frame implements Runnable {
  public static final int DOWN  = 0;
  public static final int SOUTH = 1;
  public static final int LEFT  = 2;
  public static final int WEST  = 3;
  public static final int UP    = 4;
  public static final int NORTH = 5;
  public static final int RIGHT = 6;
  public static final int EAST  = 7;

/**
 * Current x coordinate of the player in the world.
 */     
 int           currentX  = 1472;  //Britain

/**
 * Current y coordinate of the player in the world.
 */     
 int           currentY  = 1642;

/**
 * Shows if the game is in normal running mode. While shutdown it becomes false.
 */	
 public boolean running  = true;
  
/**
 * Stores x value of current mouse position
 */
 public int mouseX = 0;

/**
 * Stores y value of current mouse position
 */
 public int mouseY = 0;

/**
 * Reference to the cacheDemon as data source.
 */
 private CacheDemon cacheDemon;

/**
 * Reference to the mapWindow
 */
 private MapMaker mapMaker;
      
/**
 * This should be defined here. Array where screen information is stored.
 * This will change and move to ScreenRendereer.
 */      
 int pixels[]      = null;
 
/**
 * Colormodel used to create the game images. <br>
 * This should also not stay here.
 */      
 ColorModel  cModel       = null;

/**
 * Pointer to the screen source which renders the game images. <br>
 * (Again i used that pointer word. They are still there in java, just somwhat disquised.)
 */      
 ScreenRenderer screenSource = null;
        
/**
 * Stores information of current mouse buttons.
 */      
 private boolean mousedown = false;

/**
 * The game thread. Also currently resided here.
 */      
 private Thread tickThread = null;
	
/**
 * The gamepanel, currently one and only component of game window.
 */      
 public GamePanel gamePanel = null;
    
 public  Image  mapImage;
 public  Image  mapCalcImage;
 public  Image  perfLagImage;
 public  Sprite mapSprite;
 public  Sprite mapCalcSprite;
 public  Sprite perfLagSprite;
 int     walkpos = 0;
 int     framepos = 0;
 boolean walking = false;
 int     walk_diffX;
 int     walk_diffY;
 int     dir;
 int     frame_cap;

/**
 * Keeps track of the window size
 */
 private Dimension size;
/**
 *
 * Used to build up component structure of gameWindow. <br>
 * Currently very straight forward.
 *
 */      
 public Component createComponents() {    	
   gamePanel = new GamePanel();
   Panel pane = new Panel();                                                      
   pane.setLayout(new BorderLayout());
   pane.add(gamePanel);
   return pane;
 }
   
/**
 * Constructor. Sets initial values read from ini file.
 * 
 * @param setCacheDemon      Cacher to get the data from.
 * @param setMapWindow       The map window.
 *
 */      
 public GameWindow(CacheDemon cacheDemon, 
                   int frame_cap,
                   boolean mapShowStatics) 
 {    
   super("Ultimate Melange " + Main.MAJOR + "." + + Main.MINOR + "." + + Main.BUILD);        
   this.cacheDemon = cacheDemon;
   this.frame_cap  = frame_cap;
   //Create the top-level container and add contents to it.
   Component contents = createComponents();
   //frame.getContentPane().add(contents, BorderLayout.CENTER);
   add(contents, BorderLayout.CENTER);
   //frame.setResizable(false);
      
   // load images
   System.out.print("Loading map.gif ... ");
   //mapImage     = getToolkit().getImage("skin/map.gif");
   mapImage     = getToolkit().getImage("./map.gif");
   prepareImage(mapImage, gamePanel);
   int flags = checkImage(mapImage, gamePanel);
   while ((flags & ImageObserver.ALLBITS) == 0 ) {
     flags = checkImage(mapImage, gamePanel);
     if ((flags & ImageObserver.ERROR) != 0 ) {
        System.out.println("FAILURE");
        break;
     }
   }         
   if ((flags & ImageObserver.ALLBITS) != 0) {
     mapSprite = new Sprite();
     mapSprite.takeImage(mapImage, gamePanel);
     System.out.println("OK");
   } else {
     System.out.println("FAILURE");
   }

   System.out.print("Loading mapcalc.gif ... ");
   //mapCalcImage = getToolkit().getImage("skin/mapcalc.gif");
   mapCalcImage   = getToolkit().getImage("./mapcalc.gif");
   prepareImage(mapCalcImage, gamePanel);
   flags = checkImage(mapCalcImage, gamePanel);
   while ((flags & ImageObserver.ALLBITS) == 0 ) {
     flags = checkImage(mapCalcImage, gamePanel);
     if ((flags & ImageObserver.ERROR) != 0 ) {
        System.out.println("FAILURE");
        break;
     }
   }            
   if ((flags & ImageObserver.ALLBITS) != 0) {
     mapCalcSprite = new Sprite();
     mapCalcSprite.takeImage_nonTransparent(mapCalcImage, gamePanel);
     System.out.println("OK");
   } else {
     System.out.println("FAILURE");
   }

  /*
   System.out.print("Loading perflag.gif ... ");
   perfLagImage = getToolkit().getImage("skin/perflag.gif");
   prepareImage(perfLagImage, gamePanel);
   flags = checkImage(perfLagImage, gamePanel);
   while ((flags & ImageObserver.ALLBITS) == 0 ) {
     flags = checkImage(perfLagImage, gamePanel);
     if ((flags & ImageObserver.ERROR) != 0 ) {
        System.out.println("FAILURE");
        break;
     }
   }            
   if ((flags & ImageObserver.ALLBITS) != 0) {
     perfLagSprite = new Sprite();
     perfLagSprite.takeImage_nonTransparent(perfLagImage, gamePanel);
     System.out.println("OK");
   } else {
     System.out.println("FAILURE");
   }
   */

   //Finish setting up the frame, and show it.
   addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        Main.logout();
      }
   });
   // --- KEY LISTENER ----
   gamePanel.addKeyListener(new KeyListener() {
        public void keyPressed(KeyEvent e) {
          // nothing
          switch (e.getKeyCode()) {
            case KeyEvent.VK_UP    : currentY--; currentX--; gamePanel.repaint(); break;
            case KeyEvent.VK_DOWN  : currentY++; currentX++; gamePanel.repaint(); break;
            case KeyEvent.VK_LEFT  : currentY++; currentX--; gamePanel.repaint(); break;
            case KeyEvent.VK_RIGHT : currentY--; currentX++; gamePanel.repaint(); break;
          }
        }
        public void keyReleased(KeyEvent e) {
          // nothing
        }
        public void keyTyped(KeyEvent e) {
          // nothing          	
        }
      });
 // --- MOUSE LISTENER ----
    gamePanel.addMouseListener(new MouseListener() {
       public void mouseClicked(MouseEvent e) 
       {
         // Invoked when the mouse has been clicked on a component.
       }
         
       public void mouseEntered(MouseEvent e) 
       {
         // Invoked when the mouse enters a component.
       }
         
       public void mouseExited(MouseEvent e) 
       {
         // Invoked when the mouse exits a component.
       }
         
       public void mousePressed(MouseEvent e) 
       {
         // Invoked when a mouse button has been pressed on a component.
         mouseX = e.getX();
         mouseY = e.getY();
         mousedown = true;
         if (tickThread != null) 
           tickThread.interrupt();
       }  
         
       public void mouseReleased(MouseEvent e) 
       {
         // Invoked when a mouse button has been released on a component.
         mousedown = false;
         if (tickThread != null) 
           tickThread.interrupt();
       }
   });
   // --- MOUSE MOTION LISTENER
   gamePanel.addMouseMotionListener(new MouseMotionListener() {
       public void mouseDragged(MouseEvent e)
       {
         // Invoked when a mouse button is pressed on a component and then dragged. Mouse drag events will continue to be delivered to the component where the first
         // originated until the mouse button is released (regardless of whether the mouse position is within the bounds of the component).
         mouseX = e.getX();
         mouseY = e.getY();
         //if (tickThread != null) 
         //  tickThread.interrupt();
       }
       
       public void mouseMoved(MouseEvent e)
       {
         // Invoked when the mouse button has been moved on a component (with no buttons no down).
       }
   });
    
   //for (int i = 0; i < 0x1000; i++) {
   //  cacheDemon.getMapTile(i);    
   //}
   /*
   System.out.print("Precaching static graphics ");
   long start = System.currentTimeMillis();
   for (int i = 0; i < 0x2000; i++) {
     if ((i % 50) == 0) {
       System.out.print('.');
       System.out.flush();
     }
     cacheDemon.getStaticSprite(i);    
   }
   long stop = System.currentTimeMillis();
   System.out.println(" DONE");
   System.out.println(" needed " + (stop - start) + " milli-seconds.");
   */
   addComponentListener( new ComponentAdapter() {
      public void componentResized(ComponentEvent e)  {
        handleResize();
      }
   });
    
   pack();    
   validate();
    
   Insets fBorder = getInsets();
   setSize(new Dimension(fBorder.left + fBorder.right  + 640 ,
                               fBorder.top  + fBorder.bottom + 480));
   //Centralize frame on screen
   Toolkit tools = Toolkit.getDefaultToolkit();
   Dimension screen = tools.getScreenSize();
   Dimension frameSize = getSize();
   setLocation((screen.width - frameSize.width) / 2,(screen.height - frameSize.height) / 2);
   // show it
   setVisible(true);
   // resize again, because f#$!d micrsoft VM misses it's sometimes the first time
   setSize(new Dimension(fBorder.left + fBorder.right  + 640 ,
                         fBorder.top  + fBorder.bottom + 480));
   size = getSize();
       
   cModel = new DirectColorModel(32,0xFF0000,0x00FF00,0x0000FF);
   screenSource = new ScreenRenderer(cModel, this, cacheDemon, mapShowStatics);
   //screenSource.aSprite = umSprite;
     
   screenSource.newPixels();
     
   screenSource.setAnimated(true);
   screenSource.setFullBufferUpdates(true);
   Toolkit tk = Toolkit.getDefaultToolkit();
   gamePanel.screen = tk.createImage(screenSource);
   prepareImage(gamePanel.screen, gamePanel);
              
   // Start ticker thread
   if (tickThread == null) {
     tickThread = new Thread(this, "Ticker");
     tickThread.start();
   }
 }

 void handleResize() 
 {
   Dimension newSize = getSize();
   if (size == null) {
     // still in bootup, do not interfer
     return;    
   }   
   if ((size.height == newSize.height) && (size.width == newSize.width)) {
     // nothing happend ... nothing to do
     return;     
   }
   Insets fBorder = getInsets();
   int gameWidth  = newSize.width  - fBorder.right - fBorder.left;
   int gameHeight = newSize.height - fBorder.top   - fBorder.bottom;
   boolean newresize = false; // screen to small? need a new resize?   
   if (gameWidth < 320)  {
     gameWidth  = 320;
     newresize = true;     
   }
   if (gameHeight < 240)  {
     gameHeight = 240;
     newresize = true;     
   }
   if (newresize) {
     // screen was to small, call resize, this will call this function a second time so quit after that.
     System.out.println("Resize to small, corrected.");
     setSize(gameWidth  + fBorder.right + fBorder.left,
             gameHeight + fBorder.top   + fBorder.bottom);
   } else {
     System.out.println("Gamescreen resized to " + gameWidth + "x" + gameHeight);
     screenSource.resize(gameWidth, gameHeight);
     size = newSize;
   }      
 }
    
/**
 *
 * Mainloop of the graphics game thread.
 *
 */   
 public void run() 
 {
   // world ticker (for graphics, animation)
   Thread myThread = Thread.currentThread();
   Random ran      = new Random();
   long started    = System.currentTimeMillis();
   long perfLag  = 0;
   dir = 0;
   walking = false;
   int frametime   = 1000 / frame_cap;
   while (running) {
     long start = System.currentTimeMillis();      
     if (mousedown && (!walking)) {        
       startwalk(1);
     } else {
       checkwalk();    
     }
     //long now = System.currentTimeMillis();
     //if (now - started > 5000) {
     //  System.out.println("game : frames/sec: " + (float) gamePanel.frame / 5);
     //  started = now;
     //  gamePanel.frame  = 0;  
     //}     	      	
     screenSource.newPixels();      	
     gamePanel.update(gamePanel.getGraphics());          
     long stop     = System.currentTimeMillis();      
     long diff     = stop - start;
     try {
       long sleep = frametime - diff;
       if (sleep < 0) {
         screenSource.setPerformanceLag(true);
         perfLag = stop;    
       } else {
         if ((stop - 500) > perfLag)  // wait at least some time to remove the lag sign again
           screenSource.setPerformanceLag(false);
         Thread.sleep(sleep);
       }
     } catch (InterruptedException e){
       // nothing
     }          
   }
 }
 
 public void calcwalk()
 {
   int rx = (size.width  >> 1) - mouseX;
   int ry = (size.height >> 1) - mouseY;
   int ax = Math.abs(rx);
   int ay = Math.abs(ry);
   if (((ay >> 1) - ax) >= 0)
     if (ry > 0) {
       dir = UP;
     } else {
       dir = DOWN;
     }
   else if (((ax >> 1) - ay) >= 0) {
     if (rx > 0) {
       dir = LEFT;
     } else {
       dir = RIGHT;
     }
   } else if ((rx >= 0) && (ry >= 0)) { 
     dir = WEST;
   } else if ((rx >= 0) && (ry < 0)) { 
     dir = SOUTH;
   } else if ((rx < 0) && (ry < 0)) { 
     dir = EAST;
   } else {
     dir = NORTH;
   }
   
   int ctileX = currentX;
   int ctileY = currentY;

   int ntileX = currentX;
   int ntileY = currentY;  
   
   switch (dir) {
     case DOWN  : ntileX++; ntileY++; break;
     case SOUTH :           ntileY++; break;
     case LEFT  : ntileX--; ntileY++; break;
     case WEST  : ntileX--;           break;
     case UP    : ntileX--; ntileY--; break;
     case NORTH :           ntileY--; break;
     case RIGHT : ntileX++; ntileY--; break;
     case EAST  : ntileX++;           break;
   }
   
   MapCell ccell = cacheDemon.getMapCell(ctileX, ctileY , true);
   MapCell ncell = cacheDemon.getMapCell(ntileX, ntileY , true);
   int cheight = ccell.hl < ccell.hr ? ccell.hr : ccell.hl;
   int nheight = ncell.hl < ncell.hr ? ncell.hr : ncell.hl;
     
   int currentZ = ccell.zpos;
   int newZ     = ncell.zpos;

   int cur_screenX = (ctileX - ctileY) * 22;
   int cur_screenY = (ctileX + ctileY) * 22 - currentZ;
   
   int new_screenX = (ntileX - ntileY) * 22;
   int new_screenY = (ntileX + ntileY) * 22 - newZ; 
   
   walk_diffX = (new_screenX - cur_screenX);
   walk_diffY = (new_screenY - cur_screenY);
 }

 
 public void startwalk(int dir) 
 {
   walking = true;
   int rx = (size.width  >> 1) - mouseX;
   int ry = (size.height >> 1) - mouseY;
   calcwalk();
   screenSource.scroll(walk_diffX / 6, walk_diffY / 6);
   //screenSource.setPlayer(Creature.WALK, dir, 0);
   walkpos = 1;
   framepos = 4;
 }

 public void checkwalk() 
 {
   if (walking) {
     if ((walkpos >= 0) && (walkpos < 5)) {
       walkpos ++;
       screenSource.scroll((walk_diffX * walkpos) / 6, (walk_diffY * walkpos) / 6);
       screenSource.setPlayer(Creature.WALK, dir, framepos);
       if (++framepos == 10)
         framepos = 0;
     } else if (walkpos == 5) {
       if (mousedown) {
         // continue walking
         switch (dir) {
           case DOWN  : currentX++; currentY++; break;
           case SOUTH :             currentY++; break;
           case LEFT  : currentX--; currentY++; break;
           case WEST  : currentX--;             break;
           case UP    : currentX--; currentY--; break;
           case NORTH :             currentY--; break;
           case RIGHT : currentX++; currentY--; break;
           case EAST  : currentX++;             break;
         }
         screenSource.setPos(walk_diffX, walk_diffY) ;
         walkpos = 0;
         calcwalk();
         if (++framepos == 10)
           framepos = 0;
         screenSource.setPlayer(Creature.WALK, dir, framepos);
       } else {
         // stand
         switch (dir) {
           case DOWN  : currentX++; currentY++; break;
           case SOUTH :             currentY++; break;
           case LEFT  : currentX--; currentY++; break;
           case WEST  : currentX--;             break;
           case UP    : currentX--; currentY--; break;
           case NORTH :             currentY--; break;
           case RIGHT : currentX++; currentY--; break;
           case EAST  : currentX++;             break;
         }
         screenSource.setPos(walk_diffX, walk_diffY);
         walkpos = 0;
         walking = false;
         screenSource.setPlayer(Creature.STAND, dir, 0);
       }
     }
   }        
 }

}
