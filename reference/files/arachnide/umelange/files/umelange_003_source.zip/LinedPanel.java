//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.*;

/**
 *
 * A panel with a nice line around it.
 *
 */
public class LinedPanel extends Panel {

/**
 * Constructor. Sets initial values read from ini file.
 * 
 * @param setCacheDemon      Cacher to get the data from.
 * @param setMapWindow       The map window.
 * @param setClearScreen     Shall the screen be "blued" before each frame?
 * @param setShowBall        Sets if the fireball in the middle is shown
 *
 */      
 LinedPanel(Panel innerPanel, boolean north,  boolean east,   boolean south,  boolean west, 
                              int     nspace, int     espace, int     sspace, int     wspace,
                              int     ninner, int     einner, int     sinner, int     winner) 
 {    
   setLayout(new BorderLayout(0, 0));
   add(innerPanel, BorderLayout.CENTER);
   if (north)
     add(new LinedBorderPanel(0, north,  east,   south,  west, 
                                 nspace, espace, sspace, wspace, 
                                 ninner, einner, sinner, winner), BorderLayout.NORTH);
   if (east)
     add(new LinedBorderPanel(1, north,  east,   south,  west, 
                                 nspace, espace, sspace, wspace, 
                                 ninner, einner, sinner, winner), BorderLayout.EAST);
   if (south)
     add(new LinedBorderPanel(2, north,  east,   south,  west, 
                                 nspace, espace, sspace, wspace, 
                                 ninner, einner, sinner, winner), BorderLayout.SOUTH);
   if (west)
     add(new LinedBorderPanel(3, north,  east,   south,  west, 
                                 nspace, espace, sspace, wspace, 
                                 ninner, einner, sinner, winner), BorderLayout.WEST);
 }
}


class LinedBorderPanel extends Panel {
  int compass;
  boolean north,  east,   south,  west;
  int     nspace, espace, sspace, wspace;
  int     ninner, einner, sinner, winner;
  Dimension dim;  
  
  LinedBorderPanel(int compass, boolean north,  boolean east,   boolean south,  boolean west, 
                                int     nspace, int     espace, int     sspace, int     wspace,
                                int     ninner, int     einner, int     sinner, int     winner) 
  {
    super();     
    this.north = north;  this.nspace = nspace;  this.ninner = ninner;
    this.east  = east;   this.espace = espace;  this.einner = einner;
    this.south = south;  this.sspace = sspace;  this.sinner = sinner;
    this.west  = west;   this.wspace = wspace;  this.winner = winner;
    this.compass = compass;       
    switch (compass) {
      case 0 : if (north)
                 dim = new Dimension(nspace + ninner + 2, nspace + ninner + 2); 
               else
                 dim = new Dimension(nspace + ninner,     nspace + ninner); 
               break;
      case 1 : if (east) 
                 dim = new Dimension(espace + einner + 2, espace + einner + 2); 
               else
                 dim = new Dimension(espace + einner,     espace + einner); 
               break;  
      case 2 : if (south)
                 dim = new Dimension(sspace + sinner + 2, sspace + sinner + 2); 
               else
                 dim = new Dimension(sspace + sinner,     sspace + sinner); 
               break;  
      case 3 : if (west)
                 dim = new Dimension(wspace + winner + 2, wspace + winner + 2); 
               else
                 dim = new Dimension(wspace + winner,  wspace + winner); 
               break;  
                 
    }
  }        

  public Dimension getPreferredSize()
  {
    return dim;
  }
  
  public void paint(Graphics g) 
  {
    Dimension rect = this.getSize();    
    rect.width--;
    rect.height--;
    int in, ie, is, iw;
    if (north) in = 1; else in = 0;
    if (east)  ie = 1; else ie = 0;
    if (south) is = 1; else is = 0;
    if (west)  iw = 1; else iw = 0;
    g.setColor(Color.darkGray);
    switch (compass) {
      case 0 :   
        if (north) g.drawLine(wspace,                  nspace,     rect.width - espace,     nspace);       
        if (west)  g.drawLine(wspace,                  nspace,     wspace,                  rect.height);       
        if (east)  g.drawLine(rect.width - espace - 1, nspace + 1 ,rect.width - espace- 1,  rect.height);       
        g.setColor(Color.white);
        if (north) g.drawLine(wspace + 1,              nspace + 1 , rect.width - espace - 1 - ie, nspace + 1);       
        if (west)  g.drawLine(wspace + 1,              nspace + 1 , wspace + 1,                   rect.height);       
        if (east)  g.drawLine(rect.width - espace ,    nspace ,     rect.width - espace,          rect.height);       
        break;
      case 1 :   
        if (east) g.drawLine(rect.width - espace - 1, 0 , rect.width - espace - 1, rect.height);       
        g.setColor(Color.white);
        if (east) g.drawLine(rect.width - espace,     0 , rect.width - espace,     rect.height);       
        break;
      case 2 :   
        if (south) g.drawLine(wspace,                  rect.height - sspace - 1, rect.width - espace,     rect.height - sspace - 1);       
        if (east)  g.drawLine(rect.width - espace - 1, 0,                        rect.width - espace - 1, rect.height - sspace - 1);       
        if (west)  g.drawLine(wspace,                  0,                        wspace,                  rect.height - sspace);       
        g.setColor(Color.white);
        if (south) g.drawLine(wspace,               rect.height - sspace , rect.width - espace, rect.height - sspace);       
        if (east)  g.drawLine(rect.width - espace , 0,                     rect.width - espace, rect.height - sspace);       
        if (west)  g.drawLine(wspace + 1,           0,                     wspace + 1,          rect.height - sspace - 2);       
        break;
      case 3 :   
        if (west) g.drawLine(wspace,     0 , wspace ,    rect.height);       
        g.setColor(Color.white);
        if (west) g.drawLine(wspace + 1, 0 , wspace + 1, rect.height);       
        break;
    }
  }

        
}