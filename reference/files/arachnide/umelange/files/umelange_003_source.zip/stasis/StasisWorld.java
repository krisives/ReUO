//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

package stasis;

import java.io.*;
import java.util.*;

import map.*;

import reflection.*;
import CacheDemon;

/**
 *
 * This class implements a "world" that consists on a remote UOX server.
 *  
 */                                                     
public class StasisWorld implements World {   
 public int xPos = 1472; //Britain
 public int yPos = 1642;
 public int zPos = 0;
 public int dir  = 0;
 
 private Reflection reflection;

  private CacheDemon cacheDemon;
  
 /**
  *
  * Constrcutor
  *
  *
  */
  public StasisWorld(CacheDemon cacheDemon) 
  {
    this.cacheDemon = cacheDemon;
  }
                                                       
 /**
  * from Reflection
  */
  public synchronized int walk(int direction, boolean run) 
  {
    if (direction != dir) {
      // just turned over face
      dir = direction;
      return 256; // walk deny
    }        
    // real walking
    int newx;
    int newy;
    int newz;
    switch (direction) {
      case Reflection.UP    : newy = yPos + 1; newx = xPos - 1; break;
      case Reflection.NORTH : newy = yPos - 1; newx = xPos;     break;
      case Reflection.RIGHT : newy = yPos + 1; newx = xPos + 1; break;
      case Reflection.EAST  : newy = yPos;     newx = xPos + 1; break;
      case Reflection.DOWN  : newy = yPos - 1; newx = xPos + 1; break;
      case Reflection.SOUTH : newy = yPos + 1; newx = xPos;     break;
      case Reflection.LEFT  : newy = yPos - 1; newx = xPos - 1; break;
      case Reflection.WEST  : newy = yPos;     newx = xPos - 1; break;
      default :
        newx = 0; newy = 0; // just to make compiler happy
        System.out.println("INTERNAL FATAL, unkown direction");
        System.exit(-1);
    }
    StaticCell sCell = cacheDemon.getStaticCell(newx, newy);
    MapCell mCell = cacheDemon.getMapCell(newx, newy, false);
    newz = mCell.zpos >> 2;
    
    // first check for floats, not falling down to deepest
    for (int i = 0; i < sCell.tiles.length; i++) {
      StaticParticle apart = sCell.tiles[i];
      StaticTileData tiledata = apart.tiledata;
      if ((apart.z <= zPos) && ((tiledata.flags & 0x00020000) != 0)) {
        //System.out.println("NetWorld: floating due to tile 0x" + Integer.toHexString(apart.id));
        newz = apart.z + tiledata.height;
      } else {
        //System.out.println("NetWorld: NOT floating due to tile 0x" + Integer.toHexString(apart.id) + " at height " + apart.z);                
      }
    } 

    // not check for climbs
    int climbon = -1;
    for (int i = 0; i < sCell.tiles.length; i++) {
      StaticParticle apart = sCell.tiles[i];
      StaticTileData tiledata = apart.tiledata;
      if ((apart.z >= newz) && (apart.z <= newz + 16)) {      
        if ((tiledata.flags & 0x00040000) != 0) {
          //System.out.println("NetWorld: climbing due to tile 0x" + Integer.toHexString(apart.id));
          newz = apart.z + tiledata.height;
          climbon = i;
          continue;
        }
      }
    } 
    
    // finally look if something there blocking
    for (int i = 0; i < sCell.tiles.length; i++) {
      if (i == climbon)
        continue;
      StaticParticle apart = sCell.tiles[i];
      StaticTileData tiledata = apart.tiledata;
      if ((apart.z >= newz) && (apart.z <= newz + 16)) {      
        if ((tiledata.flags & 0x40000000) != 0) {
          System.out.println("NetWorld: walk blocked due to tile 0x" + Integer.toHexString(apart.id) + " at height " + apart.z);
          return 256; // walk deny
        }
      }
    } 
    // no blocking walk is true
    yPos = newy;
    xPos = newx;
    zPos = newz;
    return zPos; // walk allow
  }
      
  // reflection system start up
  public void setReflection(Reflection reflection) 
  {
    this.reflection = reflection;
    reflection.teleport(xPos, yPos, zPos);    
    reflection.systemMessage("You just entered a frozen world.", 0x8080FF);
    reflection.systemMessage("You don't even hear some birds singing, all is silence.", 0x8080FF);
  }

  public void interrupt()
  {
    // nothing
  }
 
  public int getZpos()
  {
    return zPos;     
  }
  
 /**
  * called form reflection
  */
  public void talkRequest(String message)
  {
    reflection.systemMessage("You words echo in the frozen air", 0x8080FF);
  }
 
}
