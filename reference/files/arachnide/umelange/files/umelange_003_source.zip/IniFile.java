//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Brent Schartung
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.io.*;
import java.util.*;

/**
 *
 * Reads/Writes options of a .ini file
 * 
 * The class remembers alignment used by the user, and tries to keep it that way
 * if it writes to the file again.
 * 
 * Basic line structure:
 * 
 *   [ variable = value ] [ # comment ]
 *
 */  
public class IniFile {   

  private static String defaultString = "null";
  private static int defaultInt = 0;
  private static boolean defaultBool = false;	
  private static String c = "#";         // Character that signifies a comment
  private static String trueChars = "tTyY1";  // Characters that represent true

  private String fileName = null;
  private Vector lines = new Vector();
  private Hashtable line_of_variable = new Hashtable();
  private Hashtable hash     = new Hashtable();
  private int number_of_lines;
  private boolean needs_flush;
   
 /**
  * Constructor.
  *
  * Reads the ini file into memory.
  *
  * @param setFileName     Filename of the ini file.  
  */
  IniFile(String setFileName)  {
		number_of_lines = 0;
    fileName   = setFileName;
    File aFile = new File(fileName);
    if (!aFile.exists()) {
      System.out.println("FAILURE");       	
      System.out.println("ERROR: file " + fileName + " not found.");       	
      return;
    }

    Exception InvalidLine = new Exception();
    try {
      BufferedReader in = new BufferedReader(new FileReader(aFile));
      String line;
      int comment = 0;
			
      while ((line = in.readLine()) != null) {
	lines.addElement(new String(line));
        number_of_lines++;
	line = line.trim();
				
        if (line.equals("") || (comment = line.indexOf(c)) == 0) {
          continue;
        }
				
        if (comment > 0)
          line = line.substring(0,comment-1);
				
        StringTokenizer tokens = new StringTokenizer(line, "=");
        if (!tokens.hasMoreTokens()) {
          continue;
        }
				
        String var = tokens.nextToken().trim();
        if (var.equals("")) {
          SyntaxErrorPrompt(number_of_lines);
          continue;
        }
				
        if (!tokens.hasMoreTokens()) {
          SyntaxErrorPrompt(number_of_lines);
          continue;
        }
				
        String value = tokens.nextToken().trim();
				
        if (tokens.hasMoreTokens()) {
          SyntaxErrorPrompt(number_of_lines);
          continue;
        }
				
        hash.put(var.toUpperCase(), value);
        line_of_variable.put(var.toUpperCase(), new Integer(number_of_lines-1));
        System.out.println(var+" = "+value);
      }       
    }
    catch (FileNotFoundException e) {
      System.out.println("Unable to find "+fileName);
      return;
    }
    catch (IOException e) {
      System.out.println("Unable to read "+fileName);
      return;
    }
		
    needs_flush = false;
  }        
  
  private void SyntaxErrorPrompt(int line) {
    System.out.println("Syntax error: line "+line+" ignored.");
  }
	

 /**
  *
  * Reads a option/parameter in string format.
  * Will not return a null pointer.
  *
  * @param param   The option key. (Left side of '=')
  *
  * @return        The option value.
  *
  */	
  String getParameter(String param) 
  {
     return getParameter(param , defaultString);
  }


 /**
  *
  * Reads a option/parameter in string format.
  * Will not return a null pointer.
  *
  * @param param      The option key. (Left side of '=')
  * @param defaultVal return this if not found
  *
  * @return        The option value.
  *
  */	
  String getParameter(String param, String defaultVal) 
  {
     String value = (String) hash.get(param.toUpperCase());
     if (value != null) 
       return value;
		
     hash.put(param.toUpperCase(), defaultString);
     needs_flush = true;
     return defaultString;
  }        
        
 /**
  *
  * Sets a option/parameter in string format
  *
  * @param param   The option key. (Left side of '=')
  * @param value   The new option value.
  *
  */
  public void setParameter(String param, String value) 
  {
     // Do we need to do anything?
     if (  ((String) hash.get(param.toUpperCase())).equals(value)  )
       return;
		
     String line;
     Integer line_number = (Integer) line_of_variable.get(param.toUpperCase());
		
     // If it is a new variable, add it
     if (line_number==null) {
       line = param + " = " + value;
       line_of_variable.put(param, new Integer(number_of_lines-1));
       lines.addElement(line);
       number_of_lines++;		
       // Otherwise, change the existing line of the file and the variable
     } else {
       line = (String) lines.elementAt(line_number.intValue());
       String old_value = (String) hash.get(param.toUpperCase());
       int index = line.indexOf(old_value);
	
       // Splice the new value into the string and save it
       if (index > -1) {
         line = line.substring(0,index) + value + 
         line.substring(index+old_value.length());
				
         // If the line didn't contain the variable,
         // notify and set line to new value
       } else {
         System.out.println("Failed to change " + param + "\nChanging line in "+fileName);
         line = param + " = " + value;
       }
       lines.setElementAt(line, line_number.intValue());
    }
    hash.put(param.toUpperCase(), value);
    needs_flush = true;
  }


 /**
  *
  * Reads a option/parameter and stores it in the hash.
  *
  * @param param   The option key. (Left side of '=')
  * @param param   DefaultValue that is returned, if parameter is missing or incorrect
  *
  * @return        The option value.
  *
  */
  int getInteger(String param) 
  { 
     return getInteger(param, defaultInt); 
  }
  
  int getInteger(String param, int defaultValue) 
  {
    String sValue = getParameter(param);
    if (sValue.equals(defaultString)) {
      setParameter(param, String.valueOf(defaultValue));
      return defaultValue;
    }
    return Integer.parseInt(sValue);
  }

 /**
  *
  * Reads a option/parameter, and converts it into boolean. <br>
  * Everything that begins with a letter contained in the
  * variable True is true. Everything else if false.<br>
  * So you can use i.e "yes", "no", "true" and "false", <br>
  * but if you like you can also use "yep", "never", "nope", "yobaby", "forget it", "totaly", ...
  *
  * @param param   The option key. (Left side of '=')
  * @param param   DefaultValue that is returned, if parameter is missing or incorrect
  *
  * @return        The option value.
  *
  */
  boolean getBoolean(String param) 
  { 
     return getBoolean(param,defaultBool);
  }
  
  boolean getBoolean(String param, boolean defaultValue) 
  {
    String sValue = getParameter(param);
    if (sValue.equals(defaultString)) {
      setParameter(param, String.valueOf(defaultValue));
      return defaultValue;
    }
		
    return (trueChars.indexOf(sValue.charAt(0)) != -1);
  }

 /**
  *
  * Writes the current representation of the file back to disk.
  * Should look exactly the same as it was before, except the changes by setParameter.
  *
  */
  public void flush() {
    try {
      File aFile = new File(fileName);
      FileWriter writer = new FileWriter(aFile);
      BufferedWriter out = new BufferedWriter(writer);
      for (int i=0; i<lines.size(); i++) {
        out.write(lines.elementAt(i)+"\r\n");
      }
      out.close();
      writer.close();               
      needs_flush = false;
    } catch (IOException e) {
      System.out.println("ERROR: could not write "+fileName+"\n");
    }
  }
	
  boolean NeedsFlush() 
  {  
    return needs_flush;  
  }
	
/*  This method is used for debug purposes only
    public static void main(String args[]) {
      IniFile ini = new IniFile("umelange.ini");
      // Test parameter retrieval
      System.out.println(ini.getParameter("uopath"));
		
      // Add a new variable
      ini.setParameter("new_variable", "some_value");
		
      // Test paramter setting
      ini.setParameter("uopath","G:\\");
      System.out.println(ini.getParameter("uopath"));
		
      // Make sure values don't get accidently
      // overwritten due to call-by-reference
      String temp = ini.getParameter("uopath");
      temp = "Vwaha";
      System.out.println(ini.getParameter("uopath"));
		
      // Check int and bool getParameter calls
      System.out.println(ini.getBoolean("showball"));
      System.out.println(ini.getInteger("memory"));
		
      ini.flush();
		
      // Done
      System.out.println("OK");  	
   }
*/
	
}

