//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.io.*;
import java.net.*;
import java.awt.*;

import reflection.*;
import chardisplay.*;
import uovision.*;
import map.*;
import skin.*;

/** 
 *
 * The Main class.
 * 
 * Entry point of the console
 ***/  
public class Main {
   // please if leave the version string to "(unofficial)". A version chaos is the last thing that this
   // project needs.  
   public static final int MAJOR            = 0;
   public static final int MINOR            = 0;
   public static final int BUILD            = 3;
   public static final String version       = "(unofficial)";
   public static final String compileAuthor = "specify";
   public static final String contactAuthor = "specify";
   public static final String compileDate   = "DD/MM/YYYY"; // specify
                
   private static IniFile            iniFile;
   private static CacheDemon         cacheDemon;
   private static Reflection         reflection;
   private static ModeSelectorWindow modeSelectorWindow;
   private static CharWindow         charWindow;
   private static GameWindow         gamewindow;

   public static void main(String[] args) {
     //LoginWindow loginwindow = new LoginWindow();
   
    
     // create log file
     FileOutputStream logFile = null;
     try {
       logFile = new FileOutputStream("log");
     } catch (IOException e) {  
       System.out.println("Error creating log file: " + e.getMessage());   
       System.exit(1);
     }
     OutputStreamY outputStreamY = new OutputStreamY(System.out, logFile);
     PrintStream   printStreamY  = new PrintStream(outputStreamY);
     System.setOut(printStreamY);
     // Redirect standard error to standard out.
     // This is done be able to capture all out inclusive errors into a log file
     System.setErr(System.out);
     

     // +++ read umelange.ini +++
     System.out.print("Reading setup from umelange.ini ...");
     iniFile = new IniFile("umelange.ini");

     //BuildHuffmanTree.main(args);
     
     String uopath = iniFile.getParameter("UOPath");     
     if (uopath == null) {
       System.out.println("Paramater \"UOPath\" is missing in umelange.ini");
       System.exit(1);
     }
     if (uopath.charAt(uopath.length()-1) != File.separatorChar) {
       uopath = uopath + File.separatorChar;
     }
    
     int cacheDemonTicker     = iniFile.getInteger("cache demon ticker", 200);
     boolean showMemoryUsage  = iniFile.getBoolean("show memory usage" , false);
     int     showMemoryCycles = iniFile.getInteger("show memory cycles", 10);
     boolean showCacheUsage   = iniFile.getBoolean("show cache usage"  , false);
     int     showCacheCycles  = iniFile.getInteger("show cache cycles" , 10);
     int     megaMemory       = iniFile.getInteger("memory", 65);
     boolean no_select_window = iniFile.getBoolean("no select window", false);
     
     // +++ finished with umelange.ini +++     
     MulSkinReader mulSkinReader = null;
     MulMapReader mulMapReader   = null;
     try {
       System.out.println("Opening OSI data files ...");
       mulMapReader  = new MulMapReader(uopath);
       mulSkinReader = new MulSkinReader(uopath);
     } catch (IOException e) {
       System.out.println("Failure");
       System.exit(1);   	
     }

     File skinFile = new File("classicUO.skin");
     if (!skinFile.exists()) {
       System.out.println("Creating classicUO.skin ...");
       System.out.println("This may take some minutes and will take approximately 45MB harddisk space");
       System.out.println("The skin file is an optimized data file for static sprites of art.mul ...");
       System.out.println("If you cancled this job, delete classicUO.skin for proper operation.");
       {
         try {
           SkinFromMulWriter skinFromMulWriter = new SkinFromMulWriter("classicUO.skin", mulSkinReader);
           skinFromMulWriter.exec();
         } catch (IOException e) {
           System.out.println("FAILURE");
           System.out.println("IO Exception during skin creation: " + e.getMessage());
           System.exit(1);
         }
         // brackets to enable deletion of writer now already
       }
     }
   
     System.out.print("Opening skin file classicUO.skin ... ");
     UmeSkinReader skinReader = new UmeSkinReader("classicUO.skin");
     try {
       if (!skinReader.open()) {
         System.out.println("FAILURE");
         System.out.println("Recreating classicUO.skin because it's corrupted or out-of-date ...");
         SkinFromMulWriter skinFromMulWriter = new SkinFromMulWriter("classicUO.skin", mulSkinReader);
         skinFromMulWriter.exec();                
       }
     } catch (IOException e) {
       System.out.println("FAILURE");
       System.out.println("IO Exception while reading skin: " + e.getMessage());
       System.exit(1);
     }
     System.out.println("OK");
   

     System.out.println("Initializing cache ... ");          
     MapTile.initialize();
     cacheDemon = new CacheDemon(mulMapReader, 
                                 mulSkinReader, 
                                 skinReader,
                                 cacheDemonTicker, 
                                 showMemoryUsage, showMemoryCycles, 
                                 showCacheUsage,  showCacheCycles,
                                 megaMemory);
     cacheDemon.setPriority(cacheDemon.MIN_PRIORITY);
     cacheDemon.setDaemon(true);
     if (cacheDemonTicker >= 0)
       cacheDemon.start();

         
     System.out.println("Ultimate melange version " + version + ", Copyright (C) 2000 Axel Kittenberger");
     System.out.println("Compiled by " + compileAuthor + ". on " + compileDate);
     System.out.println("Contact: " + contactAuthor);
     System.out.println();     
     System.out.println("This program is free software; you can redistribute it and/or modify");
     System.out.println("it under the terms of the GNU General Public License as published by");
     System.out.println("the Free Software Foundation; either version 2 of the License, or");
     System.out.println("(at your option) any later version.");
     System.out.println();
     
     if (no_select_window) {
       // jump over window creation, and call static function to read run-mode
       ModeSelectorWindow.getSelection(iniFile);
     } else {
       // normally show selector window
       modeSelectorWindow = new ModeSelectorWindow(iniFile);
     }
     /* debug output
     for (int i = 0; i < 0x3FFF; i++) {
       int data = cacheDemon.getStaticTileData(i);
       String name = mulReader.readStaticTileName(i);
       String nr = Integer.toHexString(i);
       while (nr.length() < 4)
         nr  = "0" + nr;
       String datw = Integer.toBinaryString(data);
       while (datw.length() < 8* 4)
         datw  = "0" + datw;
       String dat1 = datw.substring( 0, 8);
       String dat2 = datw.substring( 8,16);
       String dat3 = datw.substring(16,24);
       String dat4 = datw.substring(24,32);
         
       System.out.println("0x" + nr + " : " + dat1 + "." + dat2 + "." + dat3 + "." + dat4 + " :" + name);
     }
     
     for (int p = 31; p >= 0; p--) {
       int mask = 1 << p;       
       String maskString = Integer.toHexString(mask);
       while (maskString.length() < 8)
         maskString  = "0" + maskString;
       
       System.out.println(); 
       System.out.println(); 
       System.out.println("=============================================");
       System.out.println(" Following tiles have bit 0x" + maskString);
       System.out.println("=============================================");
       for (int i = 0; i < 0x3FFF; i++) {
         int data = cacheDemon.getStaticTileData(i);
         if ((data & mask) != 0) {
           String name = mulReader.readStaticTileName(i);
           String nr = Integer.toHexString(i);
           while (nr.length() < 4)
             nr  = "0" + nr;         
           if (name.length() > 0)
             System.out.println("  0x" + nr + " : " + name);
         }
       }
     }
     */
 }

 /**
  *
  * Called from GameWindow if user logget out.
  * Prepares a shutdown.
  *
  */ 
  public static void logout() 
  {
    System.out.println("\n-> CLIENT SHUTDOWN");
    System.out.println("Closing data files ...");  
    //artReader.close();
    System.out.println("Finished.");
    System.exit(0);
    // nothing	
  }
  
  public static void startGame(World world, Display display) 
  {
    System.out.println("\n-> IN GAME");    
    
    reflection = new Reflection(world, display);
    reflection.start();
  }

 /**
  *
  * Called from Mode Selector.
  *
  */ 
  public static void modeSelected(int world, int display) 
  {        
     if ((world   == ModeSelectorWindow.WORLD_STASIS) &&
         (display == ModeSelectorWindow.DISPLAY_TEXTRA)) {
       charWindow = new CharWindow(iniFile, world, cacheDemon, null, 0, null, null);
     } else if ((world   == ModeSelectorWindow.WORLD_UO_NETWORK) &&     
         (display == ModeSelectorWindow.DISPLAY_TEXTRA)) {
       String server   = iniFile.getParameter("Server");
       int    port     = iniFile.getInteger  ("Port",2593);
       String account  = iniFile.getParameter("Account");
       String password = iniFile.getParameter("Password");
       charWindow = new CharWindow(iniFile, world, cacheDemon, server, port, account, password);
     } else if ((world   == ModeSelectorWindow.WORLD_STASIS) &&
                (display == ModeSelectorWindow.DISPLAY_UO_VISION)) {                        
       boolean showStatics = iniFile.getBoolean("show map statics",  false);
       int     frame_cap   = iniFile.getInteger("frame cap",  12);
       if (frame_cap <= 0) {
         System.out.println("Warning: Illegal value for 'frame cap', set to default");
         frame_cap = 12;
       }
       if (frame_cap > 500) {
         System.out.println("Warning: Illegal value for 'frame cap', value reduced");
         frame_cap = 500;
       }
       System.out.println("Loading game window ... ");
       Point cords = new Point();
       Thread myThread = Thread.currentThread();
       System.out.println();
       GameWindow gamewindow = new GameWindow(cacheDemon, frame_cap, showStatics);
     } else {
       System.out.println("INTERNAL FATAL, invalid mode selected.");  
       System.exit(-1);
     }
  }
}