//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.io.*;

/** 
 * Splits a print stream into two
 *
 ***/  
 class OutputStreamY extends OutputStream {   
   private OutputStream streamA;
   private OutputStream streamB;
 
   public OutputStreamY(OutputStream streamA, OutputStream streamB) 
   {
     this.streamA = streamA;    
     this.streamB = streamB; 
   }
    
   public void close() throws IOException
   {
     // Closes this output stream and releases any system resources associated with this stream.
     streamA.close();
     streamB.close();
   }
   
   public void flush() throws IOException
   {
     // Flushes this output stream and forces any buffered output bytes to be written out.
     streamA.flush();
     streamB.flush();
   }
          
   public void write(byte[] b) throws IOException
   {
     // Writes b.length bytes from the specified byte array to this output stream.
     streamA.write(b);
     streamB.write(b);
   }
   
   public void write(byte[] b, int off, int len) throws IOException
   {
     // Writes len bytes from the specified byte array starting at offset off to this output stream.
     streamA.write(b, off, len);
     streamB.write(b, off, len);
   }
   
   public void write(int b) throws IOException
   {
     // Writes the specified byte to this output stream.
     streamA.write(b);
     streamB.write(b);
   }

 }