//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/** 
 *
 * Not used currently, is written in swing, has to be converted...
 *
 */

/*
import java.awt.*;
import java.awt.event.*;

public class LoginWindow {
  public Component createComponents() 
  {
    final JLabel serverLabel   = new JLabel("Server: ");
    final JLabel accountLabel  = new JLabel("Account Name: ");
    final JLabel passwordLabel = new JLabel("Password: ");

    ImageIcon iconUMelange = new ImageIcon("images/Umelange.gif");
    JLabel   labelUMelange = null;
    while (iconUMelange.getImageLoadStatus()!= MediaTracker.COMPLETE) {
      if (iconUMelange.getImageLoadStatus()== MediaTracker.ERRORED) {
        System.out.println("ERROR: Could not load images/Umelange.gif");	
        labelUMelange = new JLabel();                    
        break;
      }
    } 
    if (labelUMelange == null) 
      labelUMelange = new JLabel(iconUMelange);        
        
    JTextField serverField   = new JTextField();
    JTextField accountField  = new JTextField();
    JTextField passwordField = new JTextField();

    JPanel loginPanel = new JPanel();
    loginPanel.setLayout(new GridLayout(3, 2));
    loginPanel.add(serverLabel);
    loginPanel.add(serverField);
    loginPanel.add(accountLabel);
    loginPanel.add(accountField);
    loginPanel.add(passwordLabel);
    loginPanel.add(passwordField);

    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new GridLayout(1, 3));
    JButton buttonConnect = new JButton("Connect");
    buttonConnect.setMnemonic(KeyEvent.VK_C);
    buttonConnect.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) 
      {
          // nothing
      }
    });
    
    buttonPanel.add(buttonConnect);        

    JPanel pane = new JPanel();        
    pane.setBorder(BorderFactory.createEmptyBorder(
                                     10, //top
                                     30, //left
                                     10, //bottom
                                     30) //right
                                 );                                        
                                        
    pane.setLayout(new BorderLayout(20,20));
    pane.add(labelUMelange, BorderLayout.NORTH);
    pane.add(loginPanel, BorderLayout.CENTER);        
    pane.add(buttonPanel, BorderLayout.SOUTH);        
    //buttonConnect
    return pane;
  }

  LoginWindow() 
  {
    try {
      UIManager.setLookAndFeel(
        UIManager.getCrossPlatformLookAndFeelClassName());
    } catch (Exception e) { }

    //Create the top-level container and add contents to it.
    JFrame frame = new JFrame("Ultimate Melange");        
    Component contents = createComponents();
    frame.getContentPane().add(contents, BorderLayout.CENTER);
    frame.setResizable(false);
        
       
    //Finish setting up the frame, and show it.
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });    
    frame.pack();
    //Centralize frame on screen
    Toolkit tools = Toolkit.getDefaultToolkit();
    Dimension screen = tools.getScreenSize();    
    frame.setLocation((screen.width - frame.getWidth()) / 2,(screen.height - frame.getHeight()) / 2);
    frame.setVisible(true);
  }
}
*/