//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


import java.awt.*;
import java.awt.image.*;


/***
 * The map window..
 ***/
class MapWindow extends Frame {   
 static final int width          = 200;
 static final int height         = 200;
 public Image        screen       = null;
 private MapRenderer mapSource    = null;
 private CacheDemon  cacheDemon   = null;
 public GameWindow   gameWindow   = null;
  
 Insets border = getInsets();
  
/***
 * Constructor
 *
 * @param setCacheDemon   sets the cache demon to use.
 * @param setGameWindow   sets the game window to use.
 *
 ***/
 MapWindow(CacheDemon setCacheDemon, int mapx, int mapy) 
 {        
   super("Map");      
   cacheDemon = setCacheDemon;
              
   pack();
   validate();
   setSize(new Dimension(border.left + border.right  + width ,
                         border.top + border.bottom + height));
   DirectColorModel colormodel = new DirectColorModel(32,0xFF0000,0x00FF00,0x0000FF);


   mapSource = new MapRenderer(colormodel,  setCacheDemon);
   mapSource.loadMap(mapx, mapy);
      
   mapSource.setAnimated(true);
   mapSource.setFullBufferUpdates(true);
   Toolkit tk = Toolkit.getDefaultToolkit();
   screen     = tk.createImage(mapSource);
   prepareImage(screen, this);

   show();
   setSize(new Dimension(border.left + border.right  + width ,
                         border.top + border.bottom + height));

 }      

 public void paint(Graphics g)
 {
   update(g);
 }


 public void update(Graphics g)
 { 
   if (screen != null) 
     g.drawImage(screen,0,0,this);        
 }

/***
 *
 * Loads the new map.
 *
 * @param x     new x center
 * @param y     new y center
 *
 ***/
 public void loadMap(int x, int y)
 { 
   mapSource.loadMap(x,y);
   update(getGraphics());
 }

}