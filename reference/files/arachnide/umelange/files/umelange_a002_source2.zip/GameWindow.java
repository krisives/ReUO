//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.awt.*;
import java.awt.image.*;
//import javax.swing.*;
import java.awt.event.*;
import java.util.*;

/**
 *
 * This is the window in which game plays. <br>
 * Currently it has only one component: GamePanel, but this may extend. In this version
 * Mouse and keyboard capturing occurs here, and also the graphics are managaged by the 
 * window.
 *
 */


public class GameWindow implements Runnable {
/**
 * Current x coordinate of the player in the world.
 */     
 int           currentX  = 1451;  //Britain

/**
 * Current y coordinate of the player in the world.
 */     
 int           currentY  = 1652;

/**
 * Shows if the game is in normal running mode. While shutdown it becomes false.
 */	
 public boolean running  = true;
 
/**
 * Horizintal size of the game.
 */	 
 public int hSize = 0;

/**
 * Vertical size of the game.
 */	 
 public int vSize = 0;
 
/**
 * Stores x value of current mouse position
 */
 public int mouseX = 0;

/**
 * Stores y value of current mouse position
 */
 public int mouseY = 0;

/**
 * Reference to the cacheDemon as data source.
 */
 private CacheDemon cacheDemon;

/**
 * Reference to the mapWindow
 */
 private MapWindow mapWindow;
      
/**
 * The frame for the game.
 */      
 Frame frame       = null;

/**
 * This should be defined here. Array where screen information is stored.
 * This will change and move to ScreenRendereer.
 */      
 int pixels[]      = null;
 
/**
 * Colormodel used to create the game images. <br>
 * This should also not stay here.
 */      
 ColorModel  cModel       = null;

/**
 * Pointer to the screen source which renders the game images. <br>
 * (Again i used that pointer word. They are still there in java, just somwhat disquised.)
 */      
 ScreenRenderer screenSource = null;
        
/**
 * Stores information of current mouse buttons.
 */      
 private boolean mousedown = false;

/**
 * The game thread. Also currently resided here.
 */      
 private Thread tickThread = null;
	
/**
 * The gamepanel, currently one and only component of game window.
 */      
 public GamePanel gamePanel = null;
    
/**
 *
 * Used to build up component structure of gameWindow. <br>
 * Currently very straight forward.
 *
 */      
 public Component createComponents() {    	
   gamePanel = new GamePanel();
   Panel pane = new Panel();                                                      
   pane.setLayout(new BorderLayout());
   pane.add(gamePanel);
   return pane;
 }
   
/**
 * Constructor. Sets initial values read from ini file.
 * 
 * @param setCacheDemon      Cacher to get the data from.
 * @param setMapWindow       The map window.
 * @param setClearScreen     Shall the screen be "blued" before each frame?
 * @param setShowBall        Sets if the fireball in the middle is shown
 *
 */      
 GameWindow(CacheDemon setCacheDemon, 
            MapWindow setMapWindow,
            boolean setClearScreen,
            boolean setShowBall) 
 {    
   cacheDemon = setCacheDemon;
   mapWindow  = setMapWindow;
   //Create the top-level container and add contents to it.
   frame = new Frame("Ultimate Melange");        
   Component contents = createComponents();
   //frame.getContentPane().add(contents, BorderLayout.CENTER);
   frame.add(contents, BorderLayout.CENTER);
   frame.setResizable(false);
      
   // load images
   /*
   uMelangeImage = frame.getToolkit().getImage("images/umelange.gif");
   frame.prepareImage(uMelangeImage, gamePanel);
   System.out.print("Loading images ... ");
   int flags = frame.checkImage(uMelangeImage, gamePanel);
   while ((flags & ImageObserver.ALLBITS) == 0 ) {
     flags = frame.checkImage(uMelangeImage, gamePanel);
     if ((flags & ImageObserver.ERROR) != 0 ) {
        System.out.println("FAILURE");
        break;
     }
   }
   Sprite umSprite = null;
   
   if ((flags & ImageObserver.ALLBITS) != 0) {
     umSprite = new Sprite();
     umSprite.takeImage(uMelangeImage, gamePanel, ScreenRenderer.screenWidth);
     System.out.println("complete.");
   }
   */   
   //Finish setting up the frame, and show it.
   frame.addWindowListener(new WindowAdapter() {
        public void windowClosing(WindowEvent e) {
          Main.logOut();
        }
   });
   // --- KEY LISTENER ----
   gamePanel.addKeyListener(new KeyListener() {
        public void keyPressed(KeyEvent e) {
          // nothing
          switch (e.getKeyCode()) {
            case KeyEvent.VK_UP    : currentY--; currentX--; gamePanel.repaint(); break;
            case KeyEvent.VK_DOWN  : currentY++; currentX++; gamePanel.repaint(); break;
            case KeyEvent.VK_LEFT  : currentY++; currentX--; gamePanel.repaint(); break;
            case KeyEvent.VK_RIGHT : currentY--; currentX++; gamePanel.repaint(); break;
          }
        }
        public void keyReleased(KeyEvent e) {
          // nothing
        }
        public void keyTyped(KeyEvent e) {
          // nothing          	
        }
      });
 // --- MOUSE LISTENER ----
    gamePanel.addMouseListener(new MouseListener() {
       public void mouseClicked(MouseEvent e) 
       {
         // Invoked when the mouse has been clicked on a component.
       }
         
       public void mouseEntered(MouseEvent e) 
       {
         // Invoked when the mouse enters a component.
       }
         
       public void mouseExited(MouseEvent e) 
       {
         // Invoked when the mouse exits a component.
       }
         
       public void mousePressed(MouseEvent e) 
       {
         // Invoked when a mouse button has been pressed on a component.
         mouseX = e.getX();
         mouseY = e.getY();
         mousedown = true;
       }  
         
       public void mouseReleased(MouseEvent e) 
       {
         // Invoked when a mouse button has been released on a component.
         mousedown = false;
       }
   });
   // --- MOUSE MOTION LISTENER
   gamePanel.addMouseMotionListener(new MouseMotionListener() {
       public void mouseDragged(MouseEvent e)
       {
         // Invoked when a mouse button is pressed on a component and then dragged. Mouse drag events will continue to be delivered to the component where the first
         // originated until the mouse button is released (regardless of whether the mouse position is within the bounds of the component).
         mouseX = e.getX();
         mouseY = e.getY();
       }
       
       public void mouseMoved(MouseEvent e)
       {
         // Invoked when the mouse button has been moved on a component (with no buttons no down).
       }
   });
    
   frame.pack();    
   frame.validate();
    
   hSize=640;
   vSize=480;
   Insets fBorder = frame.getInsets();
   frame.setSize(new Dimension(fBorder.left + fBorder.right  + 640 ,
                               fBorder.top  + fBorder.bottom + 480));
   //Centralize frame on screen
   Toolkit tools = Toolkit.getDefaultToolkit();
   Dimension screen = tools.getScreenSize();
   Dimension frameSize = frame.getSize();
   frame.setLocation((screen.width - frameSize.width) / 2,(screen.height - frameSize.height) / 2);
   // show it
   frame.setVisible(true);
   // resize again, because f#$!d micrsoft VM misses it's sometimes the first time
   frame.setSize(new Dimension(fBorder.left + fBorder.right  + 640 ,
                               fBorder.top  + fBorder.bottom + 480));
       
   cModel = new DirectColorModel(32,0xFF0000,0x00FF00,0x0000FF);
   screenSource = new ScreenRenderer(cModel, this, cacheDemon, setMapWindow, setClearScreen, setShowBall);
   //screenSource.aSprite = umSprite;
     
   screenSource.newPixels();
     
   screenSource.setAnimated(true);
   screenSource.setFullBufferUpdates(true);
   Toolkit tk = Toolkit.getDefaultToolkit();
   gamePanel.screen = tk.createImage(screenSource);
   frame.prepareImage(gamePanel.screen, gamePanel);
              
   // Start ticker thread
   if (tickThread == null) {
     tickThread = new Thread(this, "Ticker");
     tickThread.start();
   }
 }
    
/**
 *
 * Mainloop of the graphics game thread.
 *
 */   
 public void run() 
 {
   // world ticker (for graphics, animation)
   Thread myThread = Thread.currentThread();
   Random ran      = new Random();
   long started    = System.currentTimeMillis();
   while (running) {
     if (mousedown) {
       int rx = hSize / 2 - mouseX;
       int ry = vSize / 2 - mouseY;
       /*
       if (ry<-150)
         screenSource.scroll(0, +44);
       else if (ry<-75) 
         screenSource.scroll(0, +11);
        if (ry>150) 
         screenSource.scroll(0, -44);
       else if (ry>75) 
         screenSource.scroll(0, -11);
        if (rx>150) 
         screenSource.scroll(-44, 0);
       else if (rx>75) 
         screenSource.scroll(-11, 0);
        if (rx<-150) 
         screenSource.scroll(+44, 0);
       else if (rx<-75) 
         screenSource.scroll(+11, 0);
       */
       screenSource.scroll(- rx / 10, -ry / 10);
       screenSource.scroll(0, -ry / 10);
     }
     long now = System.currentTimeMillis();
     if (now-started > 5000) {
       System.out.println("game : frames/sec: " + (float) gamePanel.frame / 5);
       started = now;
       gamePanel.frame  = 0;  
     }     	      	
     //screenSource.offset+=5;
     screenSource.newPixels();      	
     mapWindow.loadMap(currentX, currentY);
     gamePanel.update(gamePanel.getGraphics());
     
     
     try {
       //while (!paperboard.ImageReady)
       Thread.sleep(0);
     } catch (InterruptedException e){
       // the VM doesn't want this thread to sleep anymore,
       // so get back to work
     }
   }
 }
}
