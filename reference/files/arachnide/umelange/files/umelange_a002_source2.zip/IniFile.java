//  Ultimate Melange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.io.*;
import java.util.*;

/**
 *
 * Reads/Writes options of a .ini file
 * 
 * The class remembers alignment used by the user, and tries to keep it that way
 * if it writes to the file again.
 *
 */  
class IniFile {   
 /**
  * Filename of the ini file.
  */      
  private String    fileName = null;
  
 /**
  * The opions are stored here.
  */
  private Vector    options  = new Vector();
  
 /**
  * Used to look up options quickly.
  */
  private Hashtable hash     = new Hashtable();
   
 /**
  * Constructor.
  *
  * Reads the ini file into memory.
  *
  * @param setFileName     Filename of the ini file.  
  */
  IniFile(String setFileName)  {
    fileName   = setFileName;
    File aFile = new File(fileName);
    if (!aFile.exists()) {
      System.out.println("FAILURE");       	
      System.out.println("ERROR: file " + fileName + " not found.");       	
      return;
    }
    try {
      FileReader reader = new FileReader(aFile);
      BufferedReader in = new BufferedReader(reader);
      String line;
parse_loop:
      for(int linepos = 0;; linepos++) {
        line = in.readLine();
        if (line==null)
          break;
        int linelen = line.length();
        int i = 0;
       	  
        // goto begin of statement
        int parampos = 0;
        for(;;i++) {
          if (i==linelen) {
            options.addElement(new Option(null, 0,  null, 0, -1, line, -1));
            continue parse_loop;	
          }
          if (line.charAt(i) != ' ') {
            parampos = i;
            break;
          }
        }
        if (line.charAt(i) == '=') { // equal before parameter
          System.out.println("FAILURE");
          System.out.println("SYNTAX ERROR in " + fileName + " in line " + linepos);
          options.addElement(new Option(null, 0,  null, 0, -1, line, -1));
          continue parse_loop;         		          
        }
        int valuepos = 0;
        int equalpos = -1;
        String param = null;
        String value = null;
        if (line.charAt(i) != '#') { // if not a comment only line          
          // goto equal sign
      	  for(;;i++) {
            if (i == linelen) { // end of line before '=' or '#'
              //param = line.substring(parampos,i).trim();
       	      //if (param.length() > 0) { 
              System.out.println("FAILURE");
       	      System.out.println("SYNTAX ERROR in " + fileName + " in line " + linepos);
              options.addElement(new Option(null, 0,  null, 0, -1, line, -1));
              continue parse_loop;         		
            }
            if (line.charAt(i) == '=') {
       	      equalpos = i;
       	      param = line.substring(parampos,i).trim();
       	      break;
       	    }       	      
       	  }
          // goto start of value
          i++;
          for(;;i++) {
            if (i==linelen) {
              System.out.println("FAILURE");
       	      System.out.println("SYNTAX ERROR in " + fileName + " in line " + linepos);
              options.addElement(new Option(null, 0,  null, 0, -1, line, -1));
              continue parse_loop;	
            }
            if ((line.charAt(i) == '=') || (line.charAt(i) == '#')) {
              System.out.println("FAILURE");
       	      System.out.println("SYNTAX ERROR in " + fileName + " in line " + linepos);
              options.addElement(new Option(null, 0,  null, 0, -1, line, -1));
              continue parse_loop;	
            }
            if (line.charAt(i) != ' ') {
              valuepos = i;
              break;
            }
          }
          for(;;i++) {
            if (i == linelen) { // end of line 
       	      value = line.substring(valuepos,i).trim();
              options.addElement(new Option(param, parampos, value, valuepos, equalpos, null, 0));
              continue parse_loop;         		
            }
            if (line.charAt(i) == '#') {
       	      value = line.substring(valuepos,i).trim();
       	      break;
       	    }       	      
       	  }          
        }       	        	   
        // is there a comment?      
        int commentpos = 0;
        String comment = null;
        if (line.charAt(i) == '#') {
          commentpos = i;
          comment = line.substring(commentpos,line.length()).trim();                 	
          options.addElement(new Option(param, parampos, value, valuepos, equalpos, comment, commentpos));
          continue parse_loop;         		          
        }
        // this should never be reached
        System.out.println("FAILURE");
  	System.out.println("SYNTAX ERROR in " + fileName + " in line " + linepos);
        options.addElement(new Option(null, 0,  null, 0, -1, line, -1));
        continue parse_loop;	        
      }
      in.close();
      reader.close();
    } catch (IOException ex) {
      System.out.println("FAILURE");	
      System.out.println("IO ERROR: while reading " + fileName);       	
      return;
    }
    // now all lines are inside the options Vector, build a hashtable to find paramters quickly
    for(Enumeration en = options.elements(); en.hasMoreElements();) {
      Option option = (Option) en.nextElement();
      if (option.parameter != null) {
        hash.put(option.parameter.toUpperCase(), option);
      }       
    }            
    System.out.println("OK");       	
  }           
  
 /**
  *
  * Reads a option/parameter in string format
  *
  * @param param   The option key. (Left side of '=')
  *
  * @return        The option value.
  *
  */
  String getParameter(String param) 
  {
    Option option = (Option) hash.get(param.toUpperCase());
    if (option == null)     
      return null;
    return option.value;
  }


 /**
  *
  * Sets a option/parameter in string format
  *
  * @param param   The option key. (Left side of '=')
  * @param value   The new option value.
  *
  */
  void setParameter(String param, String value) 
  {
    Option option = (Option) hash.get(param.toUpperCase());
    if (option == null) { 
      option = new Option(param, 0, value, param.length() + 2, param.length() + value.length() + 2, null, -1);
      options.addElement(option);
      hash.put(param.toUpperCase(), option);      
    } else {
      option.value = value;
    }
  }

 /**
  *
  * Writes the current representation of the file back to disk.
  * Should look exactly the same as it was before, except the changes by setParameter.
  *
  */
  void flush() {
    try {
      File aFile = new File(fileName);
      FileWriter writer = new FileWriter(aFile);
      BufferedWriter out = new BufferedWriter(writer);
      for (Enumeration en = options.elements(); en.hasMoreElements();) {
        Option option = (Option) en.nextElement();
        out.write(option.generateLine()+"\r\n");
      } 
      out.close();
      writer.close();               
    } catch (IOException ex) {
      System.out.println("FAILURE");	
      System.out.println("IO ERROR: while writing " + fileName);       	
      return;
    }   
  }

 /**
  *
  * Reads a option/parameter, and converts it into string.
  *
  * @param param   The option key. (Left side of '=')
  * @param param   DefaultValue that is returned, if parameter is missing or incorrect
  *
  * @return        The option value.
  *
  */
  int getInteger(String param, int defaultValue) 
  {
    String sValue = getParameter(param);
    int iValue;
    if (sValue == null) {
      System.out.println("Paramater \"" + param + "\" is missing, supposing default: " + defaultValue);
      iValue = defaultValue;
      setParameter(param, String.valueOf(defaultValue));
      flush();
    } else {
      try {
        iValue = Integer.parseInt(sValue);
      } catch (NumberFormatException ex) {
        System.out.println("Paramater \"" + param + " is not a number, setting to default");
        iValue = defaultValue;
        setParameter(param , String.valueOf(defaultValue));
        flush();         
      }               
    } 
    return iValue;
  }

 /**
  *
  * Reads a option/parameter, and converts it into boolean. <br>
  * Everything that begins with 'n' or 'f' is false. <br>
  * Everything that begins with 'y' or 't' is true. <br>
  * So you can use i.e "yes", "no", "true" and "false", <br>
  * but if you like you can also use "yep", "never", "nope", "yobaby", "forget it", "totaly", ...
  *
  * @param param   The option key. (Left side of '=')
  * @param param   DefaultValue that is returned, if parameter is missing or incorrect
  *
  * @return        The option value.
  *
  */
  boolean getBoolean(String param, boolean defaultValue) 
  {
    String sValue = getParameter(param);
    boolean bValue;
    if (sValue == null) {
      if (defaultValue)
        System.out.println("Paramater \"" + param + "\" is missing, supposing default: yes");
      else
        System.out.println("Paramater \"" + param + "\" is missing, supposing default: no");      
      bValue = defaultValue;
      setParameter(param, String.valueOf(defaultValue));
      flush();
    } else {
       char c = sValue.charAt(0);
       if ((c == 'N') || (c == 'n') || (c == 'f') || (c == 'F')) {
         bValue = false;
       } else if ((c == 'Y') || (c == 'y') || (c == 't') || (c == 'T')) {
         bValue = true;
       } else {
        if (defaultValue)
          System.out.println("Paramater \"" + param + "\" is missing, supposing default: yes");
        else
          System.out.println("Paramater \"" + param + "\" is missing, supposing default: no");      
        bValue = defaultValue;
        setParameter(param , " ");
        flush();         
      }               
    } 
    return bValue;
  }


}



/***
 * A class for IniFile only, it holds per line info.
 ***/   
 class Option {
   public String parameter  = null;
   public int    parampos   = 0;
   public String value      = null;
   public int    valuepos   = 0;
   public int    equalpos   = 0;
   public String comment    = null;   
   public int    commentpos = 0;
   
   Option() 
   { 
     // nothing
   };
   
   Option(String setParameter, int setParampos, 
          String setValue,     int setValuepos,
          int    setEqualpos,
          String setComment,   int setCommentpos)
   {
     parameter  = setParameter;
     parampos   = setParampos;
     value      = setValue;
     valuepos   = setValuepos;
     equalpos   = setEqualpos;
     comment    = setComment;
     commentpos = setCommentpos;
   }
   
  /**
   *
   * Synthesizes the line information back to the string represenation. <br>
   * Hmmm, maybe the toString() method of java could some used....
   *
   */
   String generateLine() {
     StringBuffer buf = new StringBuffer();
     int pos;
     for (pos = 0; pos < parampos; pos++)
       buf.append(' ');      
     if (parameter!=null) {
       buf.append(parameter);
       pos += parameter.length();
     }
     for (; pos < equalpos; pos++)
       buf.append(' ');
     if (equalpos == pos) {
       buf.append('=');
       pos ++;
     }
     for (; pos < valuepos; pos++)
       buf.append(' ');
     if (value!=null) {
       buf.append(value);
       pos += value.length();
     } 
     for (; pos < commentpos; pos++)
       buf.append(' ');
     if (comment!=null) {
       buf.append(comment);
       pos += comment.length();
     }
     return buf.toString();       	
   }
               
 }