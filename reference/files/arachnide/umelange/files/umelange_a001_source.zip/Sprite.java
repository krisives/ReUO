//  Ultimate Melanange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.awt.*;
import java.awt.image.*;
//import java.util.*;

/** 
 * Read RawTile
 ***/  
 class Sprite  {   
   public int run[];
   public int data[];
   //public int heightpos = 0;
   public int width     = 0;
   public int height    = 0; 
   public int dlen      = 0;
   public int rlen      = 0;
   
   public void takeImage(Image img, ImageObserver obs, int bufWidth) 
   {
     width = img.getWidth(obs);
     height = img.getHeight(obs);
     int size = width*height;
     int nextLineLen = bufWidth - width;
     
     PixelGrabber pg = new PixelGrabber(img, 0, 0, width, height, true);     
     try {
       pg.grabPixels();
     } catch (InterruptedException e) {
       System.out.println("INTERRUPTED!");
       return;	
     }
     //first calculate the size of arrays
     while ((pg.getStatus() & ImageObserver.ALLBITS) == 0);
     int pixels[] = (int[]) pg.getPixels();
     int datasize = 0;
     int runsize = 0;
     
     int background = pixels[0];
     boolean level = false; // true if foreground, false if background
     for (int i = 0, x = 0; i < size; i++, x++) {
       if (x==width) {
       	 x = 0;
       	 if (level) {
           level = false;
       	   runsize++;       	 	
       	 }
       }
       if (level)
         datasize++;
       if (level && (pixels[i]==background)) {
       	 level = false;
       	 runsize++;
       } else if (!level && (pixels[i]!=background)) {
       	 level = true;
       	 runsize++;
       }
     }     
     runsize++;
     // now the size is known, build the arrays...
     run  = new int[runsize];
     data = new int[datasize];
     int dpos = 0;
     int rpos = 0;
     int len  = 0;
     level = false;    
     for (int i = 0, x = 0; i < size; i++, x++) {
       int pix = pixels[i];
       if (x==width) {
       	 x = 0;
       	 if (level) {
           level = false;
           run[rpos++] = len;
       	   len = 0;
       	 }
       	 len += nextLineLen;
       }
       len++;                
       if (level && (pix!=background)) 
         data[dpos++] = pixels[i];       
       if (level && (pix==background)) {
       	 level = false;
       	 run[rpos++] = len;
       	 len = 0;
       } else if (!level && (pix!=background)) {
       	 level = true;
       	 run[rpos++] = len;
       	 len = 0;
       }
     }      
     run[rpos] = 0;
     // copy locals to globals    
     dlen = datasize;
     rlen = runsize;
   }
 }