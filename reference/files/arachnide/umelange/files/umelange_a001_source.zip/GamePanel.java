//  Ultimate Melanange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.awt.*;
import java.awt.event.*;

import java.io.*;

class GamePanel extends Panel implements MouseListener, MouseMotionListener {
  int           xoff      = 0;
  int           yoff      = 0;
  boolean       firstTime = true; 
  
  public Image     screen    = null;
  public int       frame     = 0;

  public GamePanel(){
    setBackground(Color.white);
    //addMouseMotionListener(this);
    //addMouseListener(this);
    //} );
  }

  public void mousePressed(MouseEvent e) {
    // nothing
  }

  public void mouseDragged(MouseEvent e) {
    // nothing
  }

  public void mouseReleased(MouseEvent e){
    // nothing
  }

  public void mouseMoved(MouseEvent e) {
    // nothing
  }

  public void mouseClicked(MouseEvent e) {
    // nothing  
  }
  
  public void mouseExited(MouseEvent e) {
    // nothing
  }
  
  public void mouseEntered(MouseEvent e) {
    // nothing
  	}

  public void updateLocation(MouseEvent e){
    // nothing
  }

  public void paint(Graphics g)
  {
    //super.paintComponent(g);
    update(g);
    //super.paint(g);
  }


  public void update(Graphics g)
  { 
    frame++;
    if (screen != null) 
      g.drawImage(screen,0,0,this);
  }
}
