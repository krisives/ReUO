//  Ultimate Melanange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.awt.*;
import java.text.*;
import java.math.*;
import java.util.*;

/***
 *
 * Manages the grafic cache
 *
 ***/  
 class CacheDemon extends Thread {   
 static final int rawlen[]  = { 2, 4, 6, 8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,
                               44,42,40,38,36,34,32,30,28,26,24,22,20,18,16,14,12,10, 8, 6, 4, 2};

 static final int rawoffs[] = {21,20,19,18,17,16,15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,
                                0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,20,21};
 static final int rawdataoffs[] = {  0,  2,  6, 12, 20, 30, 42, 56, 72, 90,110,132,156,182,210,240,272,306,342, 380, 420, 462,
                                   506,550,592,632,670,706,740,772,802,830,856,880,902,922,940,956,970,982,992,1000,1006,1010}; 

 private long      ticker;
 private boolean   showMemoryUsage;
 private int       showMemoryCycle;

 private boolean   showCacheUsage;
 private int       showCacheCycle;
 private MulReader mulReader;
 private int       blocks;
 
 /*** Amount of memory as base ***/ 
 public  long      memory;
 //public  long      greedyCache;
 //public  long      normalCache;
 //public  long      panicCache;
 
    
 // Fixed Cache strategies
 public  static final int MAX_RAW_TILES           = 16382;
 public  static final int MAX_RUN_SPRITES         = 16382;
 
 private int radarColors[] = null;

 private RawTile  rawTileCache[] = new RawTile[MAX_RAW_TILES];
 private Sprite runSpriteCache[] = new Sprite[MAX_RUN_SPRITES];
 
 private Hashtable cellCache    = new Hashtable(); // saves cells.
 //private Vector    cellHistory   = new Vector();    // save history (timestamps) for freeing;

 private static int cachedRawTiles   = 0;
 private static int cachedRunSprites = 0;

 private static final int MAP_BLOCK_CACHE_SIZE    = 50;
 private static final int STATIC_BLOCK_CACHE_SIZE = 50;
 
 private static Hashtable mapBlockCache      = new Hashtable();
 //private static Vector    mapBlockHistory    = new Vector();
 
 private static Hashtable staticBlockCache   = new Hashtable();
 //private static Vector    staticBlockHistory = new Vector();

 public CacheDemon(MulReader setMulReader,     long setTicker, 
                   boolean setShowMemoryUsage, int setShowMemoryCycle,
                   boolean setShowCacheUsage,  int setShowCacheCycle,
                   int megaMemory)
 {
   super("CacheDemon");
   ticker = setTicker;
   mulReader = setMulReader;
   showMemoryUsage  = setShowMemoryUsage;
   showMemoryCycle  = setShowMemoryCycle;
   showCacheUsage   = setShowCacheUsage;
   showCacheCycle   = setShowCacheCycle;
   memory           = megaMemory * 1024 * 1024;
   //greedyCache      = memory * percentGreedyCache / 100;
   //normalCache      = memory * percentNormalCache / 100;
   //panicCache       = memory * percentPanicCache / 100;
   //blocks           = setBlocks;
 }
   
 public void run() 
 {     
   Runtime rt = Runtime.getRuntime();
   DecimalFormat df = new DecimalFormat();
   DecimalFormatSymbols dfs = new DecimalFormatSymbols();
   dfs.setGroupingSeparator('.');
   df.setDecimalFormatSymbols(dfs);
   long cycle = 0;
   while (true) {
     cycle++;
     long usedmem = rt.totalMemory() - rt.freeMemory();
     int percent = (int) (usedmem * 100 / memory);

     //while (mapBlockHistory.size() > MAP_BLOCK_CACHE_SIZE) {
     //  Integer key = (Integer) mapBlockHistory.elementAt(0);
     //  mapBlockCache.remove(key);
     //  mapBlockHistory.removeElementAt(0);                
     //}
     //while (staticBlockHistory.size() > STATIC_BLOCK_CACHE_SIZE) {
     //  Integer key = (Integer) staticBlockHistory.elementAt(0);
     //  staticBlockCache.remove(key);
     //  staticBlockHistory.removeElementAt(0);                
     //} 
     if (usedmem > memory) {
        flushCache();        
     } 
       
     if (showMemoryUsage) {  
       if ((cycle % showMemoryCycle) == 0) {
         StringBuffer sb = new StringBuffer("cache: ");
         sb.append(df.format(usedmem >> 10));
         sb.append(" KB used. (");
         sb.append(df.format(percent));
         sb.append("%)");
         System.out.println(sb);
       }
     }
     if (showCacheUsage) {
       if ((cycle % showCacheCycle) == 0) {
         StringBuffer sb = new StringBuffer("cache: ");
         sb.append("raw tiles=");
         sb.append(df.format(cachedRawTiles));
         sb.append(" run sprites=");
         sb.append(df.format(cachedRunSprites));
         System.out.println(sb);                
       }
     }
     try {
       sleep(ticker);
     } catch (InterruptedException e) {}
   }
 }         
   
 void flushCache() 
 {
  System.out.println("cache: flushing memory.");
  Runtime rt = Runtime.getRuntime();
  cellCache          = new Hashtable();
  //cellHistory        = new Vector();
  staticBlockCache   = new Hashtable();
  //staticBlockHistory = new Vector();
  mapBlockCache      = new Hashtable();
  //mapBlockHistory    = new Vector();
  rt.gc();              // run garbage collector
  rt.runFinalization(); // free memory.                
 }  
   
  /***
   *
   * Gets a raw tile, either from cache or from skin source.
   *
   * @param   id     Id of the tile to get.
   *
   * @return         The RawTile read.
   *
   ***/
   public RawTile getRawTile(int id) {
     if (rawTileCache[id] != null) // tile was in chache no need to load it
       return rawTileCache[id];
     // else get it im from file
     RawTile aTile = mulReader.readRawTile(id);
     cachedRawTiles++;
     rawTileCache[id] = aTile;
     return aTile;        
   }
   
   
 /***
  *
  * Gets a map block, either from cache or from skin source.
  *
  * @param   id        Id of the tile to get.
  * @param   prepare   Shall this block be prepared? <br>
  *                    Calculates stretch and tilt parameters if true.
  *
  * @return            The MapBlock read.
  *
  ***/
  public MapBlock getMapBlock(int id, boolean prepare) 
  {
    Cell cells[][]; 

    if ((id < 0) || (id >= 768*512)) 
      return null;
    Integer key = new Integer(id);      
    MapBlock cBlock = (MapBlock) mapBlockCache.get(key);

    if (cBlock == null) {  // was not in cache, so get it from skin source
      cBlock = mulReader.readMapBlock(id);
      mapBlockCache.put(key, cBlock);
    }
    if (prepare && !cBlock.prepared) {
      // prepare the block if asked so, and if not done already.
      MapBlock nBlock = getMapBlock(id -   1, false);  // north block
      MapBlock eBlock = getMapBlock(id + 512, false);  // east  block
      MapBlock sBlock = getMapBlock(id +   1, false);  // south block
      MapBlock wBlock = getMapBlock(id - 512, false);  // west  block
      MapBlock dBlock = getMapBlock(id + 513, false);  // down  block        
      cBlock.prepared = true;
      cells = cBlock.cells;
         
     // build stretch value for centered, east, and south tiles.
     for(int x = 0; x < 7; x++) {
       for(int y = 0; y < 7; y++) {
         cells[x][y].stl = Math.abs(cells[x][y].height - cells[x][y+1].height + 22); 
         cells[x][y].str = Math.abs(cells[x][y].height - cells[x+1][y].height + 22);         
       }
     }
     // build stretch values for south tiles
     for(int x = 0; x < 7; x++) {
       cells[x][7].stl = Math.abs(cells[x][7].height - sBlock.cells[x][0].height + 22);
       cells[x][7].str = Math.abs(cells[x][7].height - cells[x+1][7].height + 22);         
     }
     // build stretch values for east tiles
     for(int y = 0; y < 7; y++) {
       cells[7][y].stl = Math.abs(cells[7][y].height - cells[7][y+1].height + 22);
       cells[7][y].str = Math.abs(cells[7][y].height - eBlock.cells[0][y].height + 22);
     }
     // build stretch value for the south-east tile
     cells[7][7].stl = Math.abs(cells[7][7].height - sBlock.cells[7][0].height + 22);
     cells[7][7].str = Math.abs(cells[7][7].height - eBlock.cells[0][7].height + 22);
     
     
     // build height values for centered, north and east tiles     
     for(int x = 0; x < 7; x++) {
       for(int y = 0; y < 7; y++) {
         cells[x][y].hl = Math.abs(cells[x][y].stl + cells[x][y+1].str);
         cells[x][y].hr = Math.abs(cells[x][y].str + cells[x+1][y].stl);
       }       
     }     
     // build height values for south tiles     
     for(int x = 0; x < 7; x++) {
       cells[x][7].hl = Math.abs(cells[x][7].stl + Math.abs(sBlock.cells[x][0].height - sBlock.cells[x+1][0].height + 22));
       cells[x][7].hr = Math.abs(cells[x][7].str + cells[x+1][7].stl);
     }
     // build height values for east tiles     
     for(int y = 0; y < 7; y++) {
       cells[7][y].hl = Math.abs(cells[7][y].stl + cells[7][y+1].str);
       cells[7][y].hr = Math.abs(cells[7][y].str + Math.abs(eBlock.cells[0][y].height - eBlock.cells[0][y+1].height + 22));
     }
     // build height values for south east tile
     cells[7][7].hl = Math.abs(cells[7][7].stl + Math.abs(sBlock.cells[7][0].height - dBlock.cells[0][0].height + 22));
     cells[7][7].hr = Math.abs(cells[7][7].str + Math.abs(eBlock.cells[0][7].height - dBlock.cells[0][0].height + 22));  
    }     
    return cBlock;
 }
  
 public StaticBlock getStaticBlock(int id) 
 {
   Integer key = new Integer(id);
   StaticBlock sBlock = (StaticBlock) staticBlockCache.get(key);

   if (sBlock == null) {
     sBlock = mulReader.readStaticBlock(id);
     staticBlockCache.put(key, sBlock);
   }
   return sBlock;   	
 }
   
  public Sprite getRunSprite(int id, int bufWidth) 
  { 
     if (runSpriteCache[id] != null) // tile was in chache no need to load it
       return runSpriteCache[id]; 
     Sprite aSprite = mulReader.readRunSprite(id, bufWidth);
     // else get it im from file
     cachedRunSprites++;     
     runSpriteCache[id] = aSprite;
     return aSprite;   
  }   
  
/***
 *
 * Load a raw tile, stretch-o-tilt it, and save it as sprite
 *
 * @param   x          x-position of tile.
 * @param   y          y-position of tile.
 * @param   bufwidth   bufferwidth of sprite to create.
 * @param   getHeight  returns the height pos of the tile.
 * @pram    screenY    poistion on screen, so cacher can decide not
 *                     to load it if not necessary.
 *
 * @return The sprite cached/created
 *
 ***/ 
 //  streched tile:
 //
 //   stl ... stretch left side
 //    hl ... height left side
 //         
 //      -/-------/---------------- ** --------------/---------/-
 //       |       |                *|  *.            |         |
 //       |       |               * |    *.          | str     |
 //       |       |              *  |      *.        |         |
 //       |       |             *   |        * ------/         |         
 //       |   stl |            *    |        *                 |
 //       |       |           *     |       *                  |
 //    hl |       |          *      |      *                   | hr
 //       |       |         *       |     *                    |
 //       |       |        *        |    *                     | 
 //       |      -/------- *.       |   *                      |      str ... stretch right side
 //       |                  *.     |  *                       |      hr  ... height right 
 //       |                    *.   | *                        |
 //       |                      *. |*                         |
 //      -|----------------------- **--------------------------/-
 //                                 | 
 //                                 V 
 //                             middle line           
 //                                                       
 public Sprite getRawSprite(Cell cell, int bufwidth) 
 {      
   Sprite sprite = cell.sprite;   
   if (sprite != null) 
     return sprite; // in cache, not need to build it
     
   int id     = cell.id;
   int hl     = cell.hl;
   int hr     = cell.hr;
   int stl    = cell.stl;
   int str    = cell.str;
   RawTile tile   = getRawTile(cell.id);
   if (tile==null)
     return null;

   sprite = new Sprite();
   cell.sprite = sprite;
   //sprite.heightpos = cell.height;
   int len    = hr < hl ? hl : hr; // length of tile
   //if ((screenY + len - cell.height) < 0)       
   //  return null;

   int nextLineLen = bufwidth - 44;

   int run[]   = new int[len*2  + 2];   // the run array.
   int data[]  = new int[(hl + hr ) * 22];   // size of data array.

   sprite.width   = 44;
   sprite.height  = len;
   sprite.run     = run;
   sprite.data    = data;
   int rawdata[]  = tile.data;
   //int datapos = 0;  
   int rpos    = 0; // position in run array
   int dpos    = 0; // position in data array
   int runlen  = 0; // len of current runner
   boolean level = false; // true if foreground, false if background
        
   for (int iy = 0; iy < len; iy++) {
     for (int px=0; px < 44; px++) {
       int py;
       if (px >= 22) {
         if (hr > 0)
           py = (iy * 44 + (px - 22) * (hr - str * 2)) / hr;
         else
           py = -1;
       } else {
         if (hl > 0) {
           py = (iy * 44 + (px - 22) * (stl * 2 - hl)) / hl;
         } else 
           py = -1;
       }
       if ((py < 0) || (py >= 44)) {
         // this is a background hit.
         if (!level) {
           // was already in background.
           runlen++;
         } else {
           // moved to background.
           run[rpos++] = runlen;
           runlen = 1;
           level = false;
         }         
         continue;
       }   
       if ((px < rawoffs[py]) || (px >= (rawoffs[py] + rawlen[py]))) {
         // this is also a background hit.
         if (!level) {
           // was already in background.
           runlen++;
         } else {
           // moved to background.
           run[rpos++] = runlen;
           runlen = 1;
           level = false;
         }         
         continue;
       }              
       // this is a foreground hit.
       if (level) {
         // was already in foreground.
         runlen++;
       } else {
         // moved to foreground.
         /*
         if (runlen==0) {
           System.out.println("HIT");
           data[dpos++] = 0x0000FF;
           run[rpos++] = 1;
           runlen++;
         } else {*/
         run[rpos++] = runlen;
         runlen = 1;          
         //}
         level = true;
       }         
       //int rawdpos = -1;
       //if ((py >= 0) && (py < 44)) {
       int rawdpos;
       rawdpos = rawdataoffs[py] + px - rawoffs[py];
       //}
       if ((rawdpos >= 0) && (rawdpos < 1012))
         data[dpos++] = rawdata[rawdpos];
     }
     // move to background, on row-line-feed.
     if (level) {
       run[rpos++] = runlen;
       runlen = nextLineLen;
       level = false;
     } else {
       runlen += nextLineLen; 
     }
   } 
   run[rpos++] = 0;
   run[rpos++] = 0;
   sprite.dlen    = dpos;
   sprite.rlen    = rpos;
   return sprite;
 }

/***
 *
 * Locates the block of a raw tile  <br>
 * 
 * @param x        x-coordinate of the block
 * @param y        y-coordinate of the block
 * @param cords    the cordinates of the cell inside the block
 * @param prepare  shall the cells be prepared?
 *
 * @return MapBlock of raw tile
 *
 ***/
 public MapBlock getBlockOfRawTile(int x, int y, boolean prepare) 
 {
   int id =  ((int) x / 8) * 512 + ((int) (y / 8)); // don't try to simplify this equation, because rounding is important.
                                                    // took me a night to find this bug ;) - knoxos
   return getMapBlock(id, prepare);   
 }

/***
 *
 * Locates the block of a raw tile  <br>
 * 
 * @param x        x-coordinate of the block
 * @param y        y-coordinate of the block
 * @param cords    the cordinates of the cell inside the block
 * @param prepare  shall the cells be prepared?
 *
 * @return cell
 *
 ***/
 public Cell getCell(int x, int y, boolean prepare) 
 {
   Integer key = new Integer( x | (y << 16));
   Cell cell = (Cell) cellCache.get(key);
   if (cell == null) {
      MapBlock block = getBlockOfRawTile(x, y, prepare);
      cell = block.cells[x % 8][y % 8];
      cellCache.put(key,cell);
      //cellHistory.addElement(key);
   }

   int id =  ((int) x / 8) * 512 + ((int) (y / 8)); // don't try to simplify this equation, because rounding is important.
                                                    // took me a night to find this bug ;) - knoxos
   return getMapBlock(id, prepare).cells[x % 8][y % 8];   
 }
      
/*** 
 *
 * gets the radar colors from radarcol.mul
 *
 ***/
 public int[] getRadarColors() 
 { 
   if (radarColors==null)
     radarColors = mulReader.readRadarColors();   
   return radarColors;   
 }     
 
 
}


