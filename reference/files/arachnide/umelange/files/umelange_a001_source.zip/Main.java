//  Ultimate Melanange. Client for UO-Emulators
//  Copyright (C) 2000 Axel Kittenberger
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import java.io.*;
import java.net.*;
import java.awt.*;

/** 
 * The Main class 
 ***/  
 class Main {
   // please if leave the version string to "(unofficial)". A version chaos is the last thing that this
   // project needs.  
   public static final String version       = "(unofficial)";
   public static final String compileAuthor = "(specify)";
   public static final String contactAuthor = "(specify)";
   public static final String compileDate   = "(DD/MM/YYYY)"; // specify
        
   public static MulReader  mulReader;
   public static IniFile    iniFile;
   public static CacheDemon cacheDemon;

   public static void main(String[] args) {
     //Socket UOSocket = null;
     //DataOutputStream out = null;
     //DataInputStream in = null;

     /*
     try {
       UOSocket = new Socket("192.168.1.7", 2593);
       out = new DataOutputStream(UOSocket.getOutputStream());
       in  = new DataInputStream(UOSocket.getInputStream());
     } catch (UnknownHostException e) {
       System.err.println("Cannot find server.");
       System.exit(1);
     } catch (IOException e) {
       System.err.println("I/O Error while connecting to the server: ");
       System.err.println(e.getMessage());
       System.exit(1);
     }
     /*
     Crypt crypt = new Crypt();
     //crypt.init(3232235783);
     crypt.init( (192L << 24L) | (168L << 16L) | (1L << 8L) | 7L );
     int loginGreeting[] = {128, (int) 'a', (int) 'd', (int) 'm', (int) 'i', (int) 'n', 0};
     int answer[] = new int[loginGreeting.length];
     crypt.cryptLogin(loginGreeting, answer);
     System.out.println("Calculated 0 byte: " + (answer[0] & 0xFF));
     System.out.println("Calculated 1 byte: " + (answer[1] & 0xFF));
     System.out.println("Calculated 2 byte: " + (answer[2] & 0xFF));
     System.out.println("Calculated 3 byte: " + (answer[3] & 0xFF));
     System.out.println("Calculated 4 byte: " + (answer[4] & 0xFF));
     System.out.println("Calculated 5 byte: " + (answer[5] & 0xFF));
     System.out.println("Calculated 6 byte: " + (answer[6] & 0xFF));
     */

     //System.in.read();
     /*
     out.close();
     in.close();
     */
     //LoginWindow loginwindow = new LoginWindow();
   
     System.setErr(System.out);
     // +++ read umelange.ini +++
     System.out.print("Reading setup from umelange.ini ...");
     iniFile = new IniFile("umelange.ini");

     String uopath = iniFile.getParameter("UOPath");     
     if (uopath == null) {
       System.out.println("Paramater \"UOPath\" is missing in umelange.ini");
       System.exit(1);
     }
     if (uopath.charAt(uopath.length()-1) != File.separatorChar) {
       uopath = uopath + File.separatorChar;
     }

     int cacheDemonTicker     = iniFile.getInteger("cache demon ticker", 200);
     boolean showMemoryUsage  = iniFile.getBoolean("show memory usage" , false);
     int     showMemoryCycles = iniFile.getInteger("show memory cycles", 10);
     boolean clearScreen      = iniFile.getBoolean("clear screen"      , false);
     boolean showCacheUsage   = iniFile.getBoolean("show cache usage"  , false);
     int     showCacheCycles  = iniFile.getInteger("show cache cycles" , 10);
     int     megaMemory       = iniFile.getInteger("memory", 65);
     //int     percentGreedyCache = iniFile.getInteger("greedy cache", 10);
     //int     percentNormalCache = iniFile.getInteger("normal cache", 80);
     //int     percentPanicCache  = iniFile.getInteger("panic cache",  95);
     //int     blocks             = iniFile.getInteger("blocks",       10);
     boolean showBall           = iniFile.getBoolean("showball",     true);
     // +++ finished with umelange.ini +++
     try {
       System.out.println("Opening OSI data files ...");
       mulReader = new MulReader(uopath);
     } catch (IOException e) {
       System.out.println("Failure");
       System.exit(1);   	
     }
     System.out.println("Initializing cache ... ");          
     RawTile.initialize();
     cacheDemon = new CacheDemon(mulReader, cacheDemonTicker, 
                                 showMemoryUsage, showMemoryCycles, 
                                 showCacheUsage,  showCacheCycles,
                                 megaMemory);
     cacheDemon.setPriority(cacheDemon.MIN_PRIORITY);
     cacheDemon.setDaemon(true);
     if (cacheDemonTicker >= 0)
       cacheDemon.start();
     
     System.out.print("Loading map window ... ");
     MapWindow mapWindow = new MapWindow(cacheDemon, 0, 0);
     System.out.println("OK");
     System.out.println("Loading game window ... ");
     Point cords = new Point();
     Thread myThread = Thread.currentThread();
     System.out.println();
     
     System.out.println("Ultimate melange version " + version + ", Copyright (C) 2000 Axel Kittenberger");
     System.out.println("Compiled by " + compileAuthor + ". on " + compileDate);
     System.out.println("Contact: " + contactAuthor);
     System.out.println();     
     System.out.println("This program is free software; you can redistribute it and/or modify");
     System.out.println("it under the terms of the GNU General Public License as published by");
     System.out.println("the Free Software Foundation; either version 2 of the License, or");
     System.out.println("(at your option) any later version.");
     System.out.println();
     GameWindow gamewindow = new GameWindow(mulReader, cacheDemon, mapWindow, clearScreen, showBall);
     //gamewindow.setVisible(true);
     System.out.println("OK");

     System.out.println("\n-> IN GAME");
     //try {
     //  System.in.read();
     //} catch (IOException e) {}
     /*
     Runtime r = Runtime.getRuntime();
     try {
       while (true) {       	 
         System.out.println("Memory: " + r.freeMemory() + " bytes of " + r.totalMemory() + " free.");
         Thread.currentThread().sleep(3000);
       }
     } catch (InterruptedException e) { }
     */
 }

 /***
  * calles from GameWindow if user logget out
  ***/ 
 public static void logOut() 
 {
   System.out.println("\n-> CLIENT SHUTDOWN");
   System.out.println("Closing data files ...");  
   //artReader.close();
   System.out.println("Finished.");
   System.exit(0);
   // nothing	
 }
}